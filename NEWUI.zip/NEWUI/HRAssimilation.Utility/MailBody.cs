﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using System.Net.Mail;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using System.Configuration;
using System.Web;

namespace HRAssimilation.Utility
{
    public class MailDetails
    {
        public string Subject;
        public string ToAddress;
        public string FromAddress;
        public string CCAddress { get; set; }        
        public string szFirstName { get; set; }
    }
    public class MailBody
    {
        public static bool SendingMail(MailDetails objPurge, ListDictionary body)
        {
            bool _isSuccess;
            System.Net.Mail.MailMessage msg;

            string subject = objPurge.Subject;
            string MailTo = objPurge.ToAddress.Trim();
            string MailFrom = objPurge.FromAddress;
            Logger.Logger log = new Logger.Logger();
            try
            {
                string MailName = System.Configuration.ConfigurationManager.AppSettings["MailName"].ToString();
                string Port = System.Configuration.ConfigurationManager.AppSettings["Port"].ToString();
                string Host = System.Configuration.ConfigurationManager.AppSettings["Host"].ToString();
                string PATH = System.Configuration.ConfigurationManager.AppSettings["ImagePath"].ToString();
                msg = new System.Net.Mail.MailMessage();


                MailDefinition message = new MailDefinition();
                message.From = MailFrom;
                /*Mailer body - Attaching Html to Mail body*/
                string RelativePath = HttpContext.Current.Server.MapPath(PATH);
                
                message.BodyFileName = RelativePath + "\\" + "SurveyMailer.html";
                message.IsBodyHtml = true;
                /*start->attach the images using in the template*/
                EmbeddedMailObject emo = new EmbeddedMailObject();
                emo.Path = RelativePath + "\\" + "greenarrow.png";
                emo.Name = "cogicon";
                EmbeddedMailObject emo1 = new EmbeddedMailObject();
                emo1.Path = RelativePath + "\\" + "CognizantLOGrey.png";
                emo1.Name = "cogfooterr";
                EmbeddedMailObject emo2 = new EmbeddedMailObject();
                emo2.Path = RelativePath + "\\" + "SurveyMailHeader.png";
                emo2.Name = "cogheader";
                message.EmbeddedObjects.Add(emo);
                message.EmbeddedObjects.Add(emo1);
                message.EmbeddedObjects.Add(emo2);

                msg = message.CreateMailMessage(MailTo, body, new Label());
                msg.To.Clear();
                msg.Bcc.Add(MailTo);
                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(msg.Body, null, "text/html");
                msg.AlternateViews.Add(htmlView);


                //string[] tos = MailTo.Split(',');
                //foreach (string to in tos)
                //{
                //    msg.To.Add(to);
                //}

                //if (cc != string.Empty)
                //{
                //    string[] ccs = cc.Split(';');
                //    foreach (string c in ccs)
                //    {
                //        msg.CC.Add(c);
                //    }
                //}
                msg.From = new MailAddress(MailFrom, MailName, System.Text.Encoding.UTF8);
                msg.Subject = subject;
                msg.SubjectEncoding = System.Text.Encoding.UTF8;

                msg.BodyEncoding = System.Text.Encoding.UTF8;
                msg.IsBodyHtml = true;
                msg.Priority = MailPriority.High;

                SmtpClient client = new SmtpClient();
                client.Port = Convert.ToInt32(Port);
                client.Host = Host;
                client.EnableSsl = false;
                log.logInfo("Mail Subject : "+subject);
                log.logInfo("initiating mail trigger to ." + MailTo);
                client.Send(msg);
                log.logInfo("mail trigger initiated successfully.");
                _isSuccess = true;
            }
            catch (SmtpException smtpException)
            {
                log.logError(smtpException.Message.ToString());
                HandleError(MailFrom, smtpException, "SendingMail()");
                _isSuccess = false;
            }
            catch (Exception exception)
            {
                log.logError(exception.Message.ToString());
                HandleError(MailFrom, exception, "SendingMail()");
                //SendMail(MailFrom, exception);
                _isSuccess = false;
            }
            finally
            {
                msg = null;
            }
            return _isSuccess;
        }
        static string GenerateBody(string mailboxAddress, Exception ex)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("*********************************** Error Date and Time - " + System.DateTime.Now + "   **************************************************<br/>");
                sb.Append("Mailbox email address: " + mailboxAddress + " <br/>");
                sb.Append("---------------------------------------------------------------------------------------------------------------------------<br/>");
                sb.Append("Error Source        :	" + ex.Source);
                sb.Append("<br/>Target Site         :	" + ex.TargetSite);
                sb.Append("<br/>System Message      :	" + ex.Message);
                sb.Append("<br/>Stack Trace         :	" + ex.StackTrace);
                sb.Append("<br/>---------------------------------------------------------------------------------------------------------------------------");

                sb.Append("<br/>************************************************** End of Error Message  **************************************************");

                return sb.ToString();
            }
            catch (Exception ex1) { throw ex1; }
            finally
            {
                sb = null;
            }
        }

        public static void HandleMailLog(string messgae)
        {
            try
            {
                string ErrorLogPath = System.Configuration.ConfigurationManager.AppSettings["LogPath"].ToString();
                string FileName = string.Format("{0}MailLog_{1}.txt", ErrorLogPath, System.DateTime.Now.Date.ToString("MM-dd-yyyy"));
                System.IO.StreamWriter maillog = new System.IO.StreamWriter(FileName, true);
                maillog.AutoFlush = true;
                maillog.WriteLine("++++++++++++++++++++++++++++++++++++ Remainder Mail Date and Time - " + System.DateTime.Now + "   +++++++++++++++++++++++++++++++++++++++");
                maillog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                maillog.WriteLine(messgae);
                maillog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                maillog.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++ End of Remainder Mail Message  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                maillog.WriteLine("");
                maillog.WriteLine("");
                maillog.Close();
            }
            catch
            {

            }
        }


        public static void HandleError(string mailboxAddress, Exception ex, string otherDesc)
        {
            System.IO.StreamWriter errlog;
            string LogFilePath, LogFileName, FileName, path, sInnerTab = string.Empty;
            try
            {
                //Log Exceptions
                LogFilePath = System.Configuration.ConfigurationManager.AppSettings["LogPath"].ToString();
                LogFileName = System.Configuration.ConfigurationManager.AppSettings["LogFileName"].ToString();
                FileName = string.Format("{0}{1}_{2}.txt", LogFilePath, LogFileName, System.DateTime.Now.Date.ToString("MM-dd-yyyy"));
                path = LogFileName + "_" + System.DateTime.Now.Date.ToString("MM-dd-yyyy") + ".txt";
                if (!File.Exists(LogFilePath + path))
                {
                    File.Create(LogFilePath + path).Close();
                }


                errlog = new System.IO.StreamWriter(LogFilePath + path, true);
                errlog.AutoFlush = true;
                errlog.WriteLine("*********************************** Error Date and Time - " + System.DateTime.Now + "   *********************************************");
                //errlog.WriteLine("");                
                errlog.WriteLine("Mailbox email address: " + mailboxAddress);
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                errlog.WriteLine("Source        :	" + otherDesc);
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                errlog.WriteLine("Error Source        :	" + ex.Source);
                errlog.WriteLine("Target Site         :	" + ex.TargetSite);
                errlog.WriteLine("System Message      :	" + ex.Message);
                errlog.WriteLine("Stack Trace         :	" + ex.StackTrace);
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                Exception objExec = ex.InnerException;
                while (objExec != null)
                {
                    sInnerTab += "        ";
                    errlog.WriteLine("");
                    errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                    errlog.WriteLine(sInnerTab + "Inner Exception:");
                    errlog.WriteLine(sInnerTab + "Error Source        :	" + objExec.Source);
                    errlog.WriteLine(sInnerTab + "Target Site         :	" + objExec.TargetSite);
                    errlog.WriteLine(sInnerTab + "System Message      :	" + objExec.Message);
                    errlog.WriteLine(sInnerTab + "Stack Trace         :	" + objExec.StackTrace);
                    errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                    objExec = objExec.InnerException;
                }

                errlog.WriteLine("*********************************** End of Error Message  **********************************************************************");
                errlog.WriteLine("");
                errlog.WriteLine("");

                errlog.Close();
            }
            catch
            {
                //DatabaseConnection connection = new DatabaseConnection();
                //using (SqlConnection con = connection.CreateConnection())
                //{
                //    string sql = "Insert into Error_Log Values('" + otherDesc + "','" + exp.Source.Replace("'", "") + "-" + exp.Message.Replace("'", "") + "\\" + ex.Message.Replace("'", "") + "','" + exp.TargetSite + "-" + exp.StackTrace.Replace("'", "") + "',getdate())";
                //    SqlCommand cmd = new SqlCommand(sql);
                //    con.Open();
                //    cmd.Connection = con;
                //    cmd.ExecuteNonQuery();
                //}
            }
            finally
            {
                errlog = null;
                LogFilePath = string.Empty; FileName = string.Empty; path = string.Empty; sInnerTab = string.Empty;
            }
        }
    }
}
