﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HRAssimilation.Utility
{
    public class Constants
    {
        #region "SP_NAME"
        
        public const string SP_PURGE_AND_ARCHIVE_DATA = "USP_SP_PURGE_AND_ARCHIVE_DATA";
        public const string SP_GET_PURGE_DETAILS = "USP_GET_PURGE_DETAILS";

        #endregion "SP_NAME"

        #region "COMMON"

        public const string CONNECTION_STRING = "SQLConnection";
        public const string ENABLELOG = "EnableLog";
        public const string DATEFORMAT = "Dateformat";       


        #endregion COMMON
    }
}
