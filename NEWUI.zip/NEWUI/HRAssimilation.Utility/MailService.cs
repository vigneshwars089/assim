﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Text;
using HRAssimilation.Entity;

namespace HRAssimilation.Utility
{
    public class MailService 
    {
        private static MailService pgm = new MailService();
        private static string EnableLog = "N";
        private static StringBuilder strTrace = new StringBuilder();
        private static string TraceStartTime = string.Empty;
        Logger.Logger log = new Logger.Logger();
        string SurveyLink = ConfigurationManager.AppSettings["SurveyLink"].ToString();
        private string getSurveyHTML()
        {
            StringBuilder myBuilder = new StringBuilder();
            myBuilder.Append("Dear Associate,");
            myBuilder.Append("<br>");
            myBuilder.Append("<br>");
            myBuilder.Append("Please find below survery link for day 2 connect. Appreciate your feedback.");
            myBuilder.Append("<br>");
            myBuilder.Append("<br>");
            myBuilder.Append("<a href='" + SurveyLink + "'>");
            myBuilder.Append("Click here to submit survey</a>");
            return myBuilder.ToString();
        }
        public bool SendSurveyMail(string toMail)
        {
            try
            {
                pgm.SendMail(toMail);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool SendMail(string toMail)
        {
            try
            {
                if (!string.IsNullOrEmpty(toMail))
                {
                    string _subject = string.Empty;
                    DateTime dtMailStartTime = DateTime.Now;                   
                    MailDetails mDetails = new MailDetails();
                    try
                    {
                        mDetails.FromAddress = "";
                        if (EnableLog.Equals("Y", StringComparison.OrdinalIgnoreCase))
                            MailBody.HandleMailLog("Calling SendMail Method ::");
                        var lastMonth = DateTime.Now.AddMonths(-1).ToString("Y");
                        _subject = "Day 2 Connect Survey on : " + DateTime.Now.ToString("MM/dd/yyyy");
                        mDetails.Subject = _subject;
                        mDetails.ToAddress = toMail.Trim();                         
                        mDetails.FromAddress = System.Configuration.ConfigurationManager.AppSettings["MailFrom"].ToString();
                        ListDictionary _messageBody = pgm.GetMailMessage(mDetails);
                        if (MailBody.SendingMail(mDetails, _messageBody))                        
                        return true;
                        else
                        return false;
                    }
                    catch (Exception ex)
                    {
                        MailBody.HandleError(mDetails.FromAddress, ex, "SendMail()");
                        return false;
                    }                        
                }
                return true;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return false;
            }
        }
        public ListDictionary GetMailMessage(MailDetails _objPurge)
        {
            if (EnableLog.Equals("Y", StringComparison.OrdinalIgnoreCase))
                MailBody.HandleMailLog("Calling Main Method :: GetPurgeMessage Starts ");
            ListDictionary _MsgBody = new ListDictionary();
            DataSet _ds = new DataSet();
            try
            {
                string _htmlBody = getSurveyHTML();
                _MsgBody = SetMailMessage(_htmlBody);
            }
            catch (Exception ex)
            {
                MailBody.HandleError("", ex, "GetPurgeMessage()");
            }
            finally
            {

            }
            if (EnableLog.Equals("Y", StringComparison.OrdinalIgnoreCase))
                MailBody.HandleMailLog("Calling Main Method :: GetPurgeMessage Ends ");
            return _MsgBody;
        }
        public ListDictionary SetMailMessage(string _subject)
        {
            string emailTemplatePath = ConfigurationManager.AppSettings["SurveyEmailTemplatePath"];
            ListDictionary replacements = new ListDictionary();
            string strContent = string.Empty;
            strContent = _subject;
            replacements.Add("<% BindContent %>", strContent);
            return replacements;
        }
    }
}
