﻿using System;
namespace HRAssimilation
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            log4net.Config.XmlConfigurator.Configure();
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            //Response.Redirect("~/ErrorPages/Oops.aspx");
        }        
    }
}