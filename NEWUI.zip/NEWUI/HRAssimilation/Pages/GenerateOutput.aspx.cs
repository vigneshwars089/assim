﻿using HRAssimilation.Data;
using System;
using System.Data;

namespace HRAssimilation.Pages
{
    public partial class GenerateOutput : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (null != Session["filename"] && null != Session["dtresult"])
            {
                string excel = Excel_Read.GenerateExcelReport("Processed_" + Session["filename"], Session["dtresult"] as DataTable);
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=" + "Processed_" + Session["filename"] + ".xls");
                Response.Charset = "";
                Response.Write(excel.ToString());
                Response.Flush();
                Response.End();
            }
        }
    }
}