﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Business;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Collections;
using HRAssimilation.Data;
using HRAssimilation.Entity;
using HRAssimilation.Utility;
namespace HRAssimilation.Pages
{
    public partial class TMPOCMapping : System.Web.UI.Page
    {
        UserConfigurationBAL objUC = new UserConfigurationBAL();
        UserConfigurationBAL usrconfigBAL = new UserConfigurationBAL();
        SearchAndEditBAL objLoc = new SearchAndEditBAL();
        MasterSettingConfigBAL masterconfigBAL = new MasterSettingConfigBAL();
        TMPOCDetails TMPOCDetails = new TMPOCDetails();
        DatabaseConnection db = new DatabaseConnection();
        string constr, Query, sqlconn;
        OleDbConnection Econ;
        Logger.Logger log = new Logger.Logger();
        GridOperationsBAL gridOp = new GridOperationsBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ValidateUserSession();
                if (!Page.IsPostBack)
                {
                    BindTMPOCDetails();
                    BindAccountMappingDetails();
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }
        public void ValidateUserSession()
        {
            try
            {
                if (Session["loggedinUserid"] == null)
                {
                    Response.Redirect("Login.aspx", true);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void btn_upload_Click(object sender, EventArgs e) {
            string bulkuploadPath = ConfigurationManager.AppSettings["BulkuploadPath"];
               try
            {
                string result = null;
                log.logInfo("Trying to upload file");
                if (FileUpload_Bulkupload1.HasFile)
                {
                    string extension = System.IO.Path.GetExtension(FileUpload_Bulkupload1.FileName);
                    string sheet = "Sheet1";
                    string filePath = null;
                    string UserID = Convert.ToString(Session["loggedinuserID"]);
                    System.Data.DataSet dtresult = new System.Data.DataSet();
                    if (extension.ToUpper() == ".XLSX")
                    {
                        string oldfilename = FileUpload_Bulkupload1.FileName;
                        string newfilename = DateTime.Now.ToString("ddMMyyyy_hhmmss") + oldfilename;
                        FileUpload_Bulkupload1.SaveAs(bulkuploadPath + newfilename);
                        System.Data.DataTable dtexcel = new System.Data.DataTable();
                        FileUpload_Bulkupload1 = new FileUpload();

                        filePath = bulkuploadPath + newfilename;
                        dtexcel = GetExcelRecords(filePath, sheet);
                        if (validateSheetName(sheet, filePath) == false)
                        {
                            result = "error;Invalid Sheet Name, please use valid template";
                        }
                        else
                        {
                            if (ValidateColumns(dtexcel, "TMPOCColumns"))
                            {
                                int colcount = 13;
                                dtexcel = ValidateNulls(dtexcel, colcount);
                                DataRow[] dr = dtexcel.Select();
                                if (dr.Length == 0)
                                {
                                    result = "warning;No records for the required selection criteria";
                                }
                                else
                                {
                                    dtexcel = dr.CopyToDataTable();
                                    if (dtexcel.Rows.Count > 300)
                                    {
                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                    }
                                    else
                                    {
                                        System.Data.DataTable dtCloned = dtexcel.Clone();
                                        //change data type of column
                                        dtCloned.Columns["Facility ID"].DataType = typeof(String);
                                        dtCloned.Columns["Department ID"].DataType = typeof(String);
                                        dtCloned.Columns["Vertical ID"].DataType = typeof(String);
                                        dtCloned.Columns["Account Id"].DataType = typeof(String);
                                        dtCloned.Columns["Project Id"].DataType = typeof(String);
                                        dtCloned.Columns["TMPOC(ID)"].DataType = typeof(String);
                                        //import row to cloned datatable
                                        foreach (DataRow row in dtexcel.Rows)
                                        {
                                           // if (!String.IsNullOrEmpty(Convert.ToString(row["Connect Date"])))
                                          //      row["Connect Date"] = Convert.ToDateTime(row["Connect Date"]).ToShortDateString();
                                            dtCloned.ImportRow(row);
                                        }
                                        BulkUploadBAL BUbal = new BulkUploadBAL();
                                        dtresult = BUbal.TMPOCMappingUpload(dtCloned, UserID);
                                        //ResetControls();
                                        string emailIDs = dtresult.Tables[1].Rows[0][0].ToString();

                                        if (emailIDs != null && emailIDs.Length > 0)
                                        {
                                            log.logInfo("Sending survey mail");
                                            if (!SendSurveyMail(emailIDs))
                                            {
                                                log.logInfo("Failed to send. Trying second attempt");
                                                if (!SendSurveyMail(emailIDs))
                                                {
                                                    log.logInfo("Failed to send in second attempt. Trying final third attempt");
                                                    bool finalStatus = SendSurveyMail(emailIDs);
                                                    if (!finalStatus)
                                                    {
                                                        log.logInfo("Unable to send Survey Trigger mails - Bulk Upload");
                                                    }
                                                }
                                            }
                                        }
                                        GenerateExcel(oldfilename.Split('.')[0], dtresult.Tables[0]);
                                    }
                                }
                            }
                            else
                            {
                                result = "error;Invalid Column Names, please use valid template";
                            }
                        }
                    }
                    else
                    {
                        result = "error;Please upload valid file.";
                    }
                }
                else
                {
                    ShowUserMessage("information", "Please select file and try.");
                }

                if (!string.IsNullOrEmpty(result) && result.Contains(';'))
                {
                    string msgtype = result.Split(';')[0];
                    string message = result.Split(';')[1];
                    ShowUserMessage(msgtype, message);
                }

            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            finally
            {

            }

        

        }
        private bool validateSheetName(string sheetName, string filepath)
        {
            try
            {
                ExcelConn(filepath);
                Econ.Open();
                sheetName = "" + sheetName + "$";
                System.Data.DataTable dt = Econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                Econ.Close();
                if (dt == null)
                {
                    return false;
                }
                else
                {
                    String excelSheets;

                    // Add the sheet name to the string array.
                    foreach (DataRow row in dt.Rows)
                    {
                        excelSheets = row["TABLE_NAME"].ToString();
                        if (excelSheets.Contains(sheetName))
                        {
                            return true;
                        }
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }

        }

          protected bool ValidateColumns(System.Data.DataTable dtexcel, string key)
        {
            try
            {
                string[] columnNames = (from dc in dtexcel.Columns.Cast<DataColumn>() select dc.ColumnName.Trim()).ToArray();
                string[] ActualColumnNames = ConfigurationManager.AppSettings[key].Split(';');
                IStructuralEquatable structuralEquator1 = columnNames;
                bool areEqual = structuralEquator1.Equals(ActualColumnNames, StringComparer.InvariantCultureIgnoreCase);
                return areEqual;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }
        }
        protected System.Data.DataTable ValidateNulls(System.Data.DataTable dtexcel, int colcount)
        {
            try
            {
                for (int i = dtexcel.Columns.Count - 1; i > colcount; i--)
                {
                    dtexcel.Columns.RemoveAt(i);
                }
                dtexcel.AcceptChanges();
                int j;
                for (int i = 0; i < dtexcel.Rows.Count; i++)
                {

                    for (j = 0; j < dtexcel.Columns.Count; j++)
                    {
                        if (!dtexcel.Rows[i].IsNull(j))
                            break;
                    }

                    if (j == dtexcel.Columns.Count)
                    {
                        dtexcel.Rows[i].Delete();
                    }

                }
                dtexcel.AcceptChanges();
                return dtexcel;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }
 

        private bool SendSurveyMail(string toEmailIds)
        {
            log.logInfo("inside survey mail");
            MailService mailSvc = new MailService();
            return mailSvc.SendSurveyMail(toEmailIds);
        }

        protected void GenerateExcel(string filename, System.Data.DataTable dtresult)
        {
            try
            {
                Session["filename"] = filename;
                Session["dtresult"] = dtresult;
                ifr.Src = "GenerateOutput.aspx";
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }
        private void ExcelConn(string FilePath)
        {
            constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", FilePath);
            Econ = new OleDbConnection(constr);
        }

        private System.Data.DataTable GetExcelRecords(string FilePath, string sheet)
        {
            try
            {
                ExcelConn(FilePath);
                Query = string.Format("select * from [" + sheet + "$]");
                OleDbCommand Ecom = new OleDbCommand(Query, Econ);
                Econ.Open();
                DataSet ds = new DataSet();
                OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
                Econ.Close();
                oda.Fill(ds);
                System.Data.DataTable Exceldt = ds.Tables[0];
                log.logInfo("No. of rows inserted: " + Exceldt.Rows.Count);
                return Exceldt;
            }
            catch (Exception ex)
            {
                log.logError("Reading excel records from uploaded excel" + ex.Message + ex.StackTrace);
                return null;
            }
        }

        protected void BindAccountMappingDetails()
        {
            try
            {
                DataSet ds = new DataSet();
                ds = objUC.GetTMPPOCMappingDetails();
                gv_TMPOCAccountMapping.DataSource = ds.Tables[0];
                gv_TMPOCAccountMapping.DataBind();
                ViewState["TMPOCAccountMapping"] = ds.Tables[0];
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void BindTMPOCDetails()
        {
            try
            {
                ddl_tmpoc.DataSource = objUC.GetTMPOCDetails();
                ddl_tmpoc.DataTextField = "Name";
                ddl_tmpoc.DataValueField = "AssociateID";
                ddl_tmpoc.DataBind();
                ddl_tmpoc.Items.Insert(0, new ListItem("Please select TM POC", "0"));
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }
        protected void bindTMPOCLocations()
        {
            try
            {
                string tmpocid = ddl_tmpoc.SelectedValue;
                ddl_location.DataSource = objUC.GetTMPOCLocations(tmpocid);
                ddl_location.DataTextField = "Location";
                ddl_location.DataValueField = "LocationID";
                ddl_location.DataBind();
                ddl_location.Items.Insert(0, new ListItem("Please select location", "0"));
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }
        protected void bindFacilities()
        {
            try
            {
                string locationid = ddl_location.SelectedValue;
                ddl_facility.DataSource = objLoc.GetSubLocationDetails(locationid);
                ddl_facility.DataTextField = "FacilityName";
                ddl_facility.DataValueField = "Code";
                ddl_facility.DataBind();
                ddl_facility.Items.Insert(0, new ListItem("Please select facility", "0"));
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        protected void ddl_tmpoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_tmpoc.SelectedValue != "0")
            {
                bindTMPOCLocations();
                resetTMPOCFilters();
            }
            else
            {
                ddl_location.SelectedValue = "0";
                ddl_location.Items.Clear();
                resetTMPOCFilters();
            }
        }

        protected void ddl_location_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_location.SelectedValue != "0")
            {
                bindFacilities();
            }
            else
            {
                ddl_facility.SelectedValue = "0";
            }
        }
        protected void BindDepartment()
        {
            ddl_department.DataSource = masterconfigBAL.BindDepartment();
            ddl_department.DataTextField = "DepartmentName";
            ddl_department.DataValueField = "DepartmentID";
            ddl_department.DataBind();
            ddl_department.Items.Insert(0, new ListItem("Please select department", "0"));
        }

        protected void ddl_facility_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDepartment();
            BindVertical();
            BindAccount();
        }
        protected void BindVertical()
        {
            ddl_vertical.DataSource = masterconfigBAL.BindVertical();
            ddl_vertical.DataTextField = "VerticalName";
            ddl_vertical.DataValueField = "VerticalID";
            ddl_vertical.DataBind();
            ddl_vertical.Items.Insert(0, new ListItem("Please select vertical", "0"));
        }

        public DataSet GetAccountDetails(string DeptID, string VerticalID)
        {
            DataSet ds = new DataSet();
            try
            {
                using (SqlConnection con = db.CreateConnection())
                {
                    try
                    {
                        SqlParameter[] param = new SqlParameter[]{
                        new SqlParameter("@departmentID",DeptID),
                        new SqlParameter("@verticalID",VerticalID)
                        };

                        ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetAccountandProjectDetails", param);
                        //string command = "select AccountID,AccountName +' - '+AccountID [AccountName] from [tbl_HR_AccountMaster] where DepartmentID='" + DeptID + "' and VerticalID='" + VerticalID + "'";
                        //DataSet ds = HRAssimilation.Data.DBHelper.ExecuteDataTable(con, CommandType.Text, command, (SqlParameter[])null);
                        //return dt;
                    }
                    catch (Exception ex)
                    {
                        log.logError(ex.Message);
                        //return ds;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }            
            return ds;
        }
        protected void bindAccountDetails(string deptid, string vertid)
        {
            DataSet ds = GetAccountDetails(deptid, vertid);
            ddl_account.DataSource = ds.Tables[0];
            ddl_account.DataTextField = "AccountName";
            ddl_account.DataValueField = "AccountID";
            ddl_account.DataBind();
            ddl_account.Items.Insert(0, new ListItem("Please select account", "0"));
            ddl_Project.DataSource = ds.Tables[1];
            ddl_Project.DataTextField = "ProjectName";
            ddl_Project.DataValueField = "ProjectID";
            ddl_Project.DataBind();
            ddl_Project.Items.Insert(0, new ListItem("Please select Project", "0"));
        }
        protected void BindAccount()
        {
            string deptid = ddl_department.SelectedValue;
            string vertid = ddl_vertical.SelectedValue;
            if (deptid != "0" && vertid != "0")
            {
                bindAccountDetails(deptid, vertid);
            }
            else
            {
                ddl_account.Items.Clear();
                ddl_Project.Items.Clear();
            }
        }
        protected void ddl_department_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_department.SelectedValue != "0")
                BindAccount();
            else
                ddl_account.SelectedValue = "0";
        }

        protected void ddl_vertical_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_department.SelectedValue != "0")
                BindAccount();
            else
                ddl_account.SelectedValue = "0";
        }
        protected void resetFilters()
        {
            ddl_tmpoc.SelectedValue = "0";
            ddl_location.SelectedValue = "0";
            ddl_location.Items.Clear();
            ddl_facility.SelectedValue = "0";
            ddl_facility.Items.Clear();
            ddl_department.SelectedValue = "0";
            ddl_department.Items.Clear();
            ddl_vertical.SelectedValue = "0";
            ddl_vertical.Items.Clear();
            ddl_account.SelectedValue = "0";
            ddl_account.Items.Clear();
            ddl_Project.Items.Clear();
        }
        protected void resetTMPOCFilters()
        {
            ddl_facility.Items.Clear();
            ddl_department.SelectedValue = "0";
            ddl_department.Items.Clear();
            ddl_vertical.SelectedValue = "0";
            ddl_vertical.Items.Clear();
            ddl_account.SelectedValue = "0";
            ddl_account.Items.Clear();
            ddl_Project.Items.Clear();
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            SaveTMPOCAccountMappping();
        }

        protected void SaveTMPOCAccountMappping()
        {
            try
            {
                TMPOCAccount objTmpocAccount = new TMPOCAccount();
                objTmpocAccount.AssociateID = ddl_tmpoc.SelectedValue;
                objTmpocAccount.LocationCode = ddl_facility.SelectedValue;
                objTmpocAccount.VerticalID = ddl_vertical.SelectedValue;
                objTmpocAccount.AccountID = ddl_account.SelectedValue;
                objTmpocAccount.ProjectID = ddl_Project.SelectedValue;
                objTmpocAccount.CreatedBy = Convert.ToString(Session["loggedinUserid"]);
                objTmpocAccount.ModifiedBy = Convert.ToString(Session["loggedinUserid"]);
                objTmpocAccount.IsActive = "Y";
                string flag = "save";
                if (objTmpocAccount.AssociateID == "0" || objTmpocAccount.LocationCode == "0" || 
                    objTmpocAccount.AccountID == "0" || objTmpocAccount.AssociateID == "" || 
                    objTmpocAccount.LocationCode == "" || objTmpocAccount.AccountID == "" ||
                    objTmpocAccount.ProjectID =="" || objTmpocAccount.ProjectID == "0")
                {
                    ShowUserMessage("warning", "Please select details and submit.");
                }
                else
                {
                    string result = objUC.ManageTMPOCLocationMapping(objTmpocAccount, flag);
                    if (result.Contains(';') && result.Split(';')[0] == "success")
                    {
                        BindFilteredAccountMappingDetails();
                        resetFilters();
                    }
                    if (result.Contains(';'))
                        ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void gv_TMPOCAccountMapping_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = gv_TMPOCAccountMapping.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && gv_TMPOCAccountMapping.EditIndex == e.Row.RowIndex)
            {
                Label lbl_facility_Code = (Label)e.Row.FindControl("lbl_facility_Code");
                DropDownList ddl = (DropDownList)e.Row.FindControl("ddl_TMPoc_update");
                DataSet ds = new DataSet();
                ds = usrconfigBAL.GetTMPOC(Convert.ToString(Session["loggedinuserID"]), lbl_facility_Code.Text.Trim());
                ddl.DataSource = ds.Tables[0];
                ddl.DataValueField = "AssociateID";
                ddl.DataTextField = "TMPOCName";
                ddl.DataBind();
                HiddenField hdn_selectedpoc = (HiddenField)e.Row.FindControl("hdn_SelectdPOC");
                ddl.Items.FindByText(hdn_selectedpoc.Value).Selected = true;
            }

            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdn = (HiddenField)e.Row.FindControl("hdn_POCID");

                    if (!string.IsNullOrEmpty(hdn.Value) && hdn.Value == Convert.ToString(Session["loggedinuserID"]))
                    {
                        e.Row.Cells[9].Enabled = false;
                        e.Row.Cells[9].ToolTip = "Self Data cannot be edited";
                    }
                }
            }

        }

        protected void gv_TMPOCAccountMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_TMPOCAccountMapping.EditIndex = -1;
            gv_TMPOCAccountMapping.PageIndex = e.NewPageIndex;
            BindFilteredAccountMappingDetails();
        }

        protected void gv_TMPOCAccountMapping_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gv_TMPOCAccountMapping.EditIndex = e.NewEditIndex;
            BindFilteredAccountMappingDetails();
        }

        protected void gv_TMPOCAccountMapping_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gv_TMPOCAccountMapping.EditIndex = -1;
            BindFilteredAccountMappingDetails();
        }
        protected void ShowUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        protected void ShowUserMessage_lead(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }

        protected void gv_TMPOCAccountMapping_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string action = "update";
            GridViewRow grd = gv_TMPOCAccountMapping.Rows[e.RowIndex];
            DropDownList ddl_TMPoc_update = (DropDownList)grd.FindControl("ddl_TMPoc_update");
            Label lbl_location = (Label)grd.FindControl("lbl_location");
            Label lbl_account = (Label)grd.FindControl("lbl_account");
            Label lbl_account_code = (Label)grd.FindControl("lbl_account_code");
            Label lbl_facility_Code = (Label)grd.FindControl("lbl_facility_Code");
            HiddenField hdn_VerticalID = (HiddenField)grd.FindControl("hdn_VerticalID");
            TMPOCDetails.TMPOCs = ddl_TMPoc_update.SelectedValue;
            TMPOCDetails.Location = lbl_location.Text.ToString();
            TMPOCDetails.AccountCode = lbl_account.Text.ToString();
            TMPOCDetails.AccountId = lbl_account_code.Text.ToString();
            TMPOCDetails.FacilityCode = lbl_facility_Code.Text.ToString();
            TMPOCDetails.VerticalID = ((HiddenField)grd.FindControl("hdn_VerticalID")).Value;
            TMPOCDetails.ProjectID = ((HiddenField)grd.FindControl("hdn_ProjectID")).Value;
            TMPOCDetails.CreatedBy = Session["loggedinuserID"].ToString();
            TMPOCDetails.ModifiedBy = Session["loggedinuserID"].ToString();
            string result = usrconfigBAL.TMPOCDetailsUpdate(TMPOCDetails, action);
            if (result.Contains(';'))
            {
                ShowUserMessage_lead(result.Split(';')[0], result.Split(';')[1]);
            }
            gv_TMPOCAccountMapping.EditIndex = -1;
            BindFilteredAccountMappingDetails();
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            resetFilters();
        }
        protected void btnGridSearch_Click(object sender, ImageClickEventArgs e)
        {
            BindFilteredAccountMappingDetails();
            gv_TMPOCAccountMapping.SetPageIndex(0);
        }
        protected void btnGridReset_Click(object sender, ImageClickEventArgs e)
        {
            resetGridFilters();
            gv_TMPOCAccountMapping.EditIndex = -1;
            BindAccountMappingDetails();
        }
        protected void resetGridFilters()
        {
            txtGridSearch.Text = "";
            ddlSearchBy.SelectedValue = "1";
        }
        protected void BindFilteredAccountMappingDetails()
        {
            BindAccountMappingDetails();
            DataTable dt;
            dt = (DataTable)ViewState["TMPOCAccountMapping"];
            String searchType = "STRING";
            switch (ddlSearchBy.SelectedItem.Text.ToString().ToLower())
            {
                case "tm poc":
                    string searchkey = txtGridSearch.Text;
                    searchkey = searchkey.Replace("\n", String.Empty);
                    searchkey = searchkey.Replace("\r", String.Empty);
                    searchkey = searchkey.Replace("\t", String.Empty);
                    dt = gridOp.FilterGridRecords(dt, "TMPOCName", searchkey, searchType);
                    break;
                case "account":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "AccountName", txtGridSearch.Text, searchType);
                    break;
                case "project":
                    dt = gridOp.FilterGridRecords(dt, "Project", txtGridSearch.Text, searchType);
                    break;
                default: break;
            }            
            gv_TMPOCAccountMapping.DataSource = dt;
            gv_TMPOCAccountMapping.DataBind();            
            ViewState["TMPOCAccountMapping"] = dt;
        }        
    }
}