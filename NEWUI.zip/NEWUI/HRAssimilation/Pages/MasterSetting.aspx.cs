﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Entity;
using HRAssimilation.Business;
using System.Data;

namespace HRAssimilation.Pages
{
    public partial class MasterSetting : System.Web.UI.Page
    {
        AccountDetails objAccount = new AccountDetails();
        LocationDetails locdetails = new LocationDetails();
        ConnectDetails conndetails = new ConnectDetails();
        MasterSettingConfigBAL mastersettingBAL = new MasterSettingConfigBAL();
        Logger.Logger log = new Logger.Logger();
        GridOperationsBAL gridOp = new GridOperationsBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                    {
                        Response.Redirect("Login.aspx", true);
                    }
                    BindDepartment();
                    BindVertical();
                    BindLocations();
                    GV_AccountDetailsBind();
                    BindFacilityMapping();
                    BindProjectMapping();
                    BindConnectsMapping();
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                }
            }
            lbl_result_account.Visible = false;
            lbl_result_newdpt.Visible = false;
            lbl_result_newvrt.Visible = false;
            lbl_result_loc.Visible = false;
            lbl_result_Connect.Visible = false;
        }
        protected bool checkForVunerableChars(string value)
        {
            if (value.Contains('<') || value.Contains('>'))
                return true;
            else
                return false;
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                if ((ddl_department.Enabled == true && ddl_vertical.Enabled == true) && (ddl_department.SelectedValue != "0" && ddl_vertical.SelectedValue != "0"))
                {
                    objAccount.DepartmentID = ddl_department.SelectedValue;

                    objAccount.VerticalID = ddl_vertical.SelectedValue;
                    if (checkForVunerableChars(txt_NewAccountID.Text) || checkForVunerableChars(txt_NewAccount.Text))
                    {
                        Response.Redirect("~/ErrorPages/Oops.aspx", true);
                    }
                    objAccount.AccountID = txt_NewAccountID.Text;
                    objAccount.AccountName = txt_NewAccount.Text;
                    objAccount.CreatedBy = Session["loggedinuserID"].ToString();
                    string result = mastersettingBAL.AccountMapping(objAccount);
                    if (result.Contains(';'))
                        ShowAccountUserMessage(result.Split(';')[0], result.Split(';')[1]);
                    if (result.Split(';')[0] == "success")
                    {
                        txt_NewAccountID.Text = "";
                        txt_NewAccount.Text = "";
                        resetControls();
                        GV_AccountDetailsBind();
                    }
                }
                else
                {
                    ShowAccountUserMessage("warning", "Please select the Department and Vertical from DropDown List");
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        public void resetControls()
        {
            ddl_department.Enabled = true;
            tblnewreq.Visible = false;
            ddl_vertical.Enabled = true;
            tblNVertical.Visible = false;
            ddl_location.Enabled = true;
            trNewLocation.Visible = false;
            txt_NewAccount.Text = "";
            txt_NewAccountID.Text = "";
            txt_NewFacility.Text = "";
            txtNewFacilityID.Text = "";
            dvAccountMessage.Visible = false;
            dvUserMessage.Visible = false;
            BindDepartment();
            BindVertical();
            BindLocations();
        }

        protected void btnAddnewDepartment_Click(object sender, EventArgs e)
        {
            ddl_department.Enabled = false;
            tblnewreq.Visible = true;
            txt_NewDepartmentID.Text = "";
            txt_newDepartment.Text = "";
        }

        protected void btnAddNewVertical_Click(object sender, EventArgs e)
        {
            ddl_vertical.Enabled = false;
            tblNVertical.Visible = true;
            txt_newVertical.Text = "";
            txt_newVerticalID.Text = "";
        }
        protected void btnNewLocation_Click(object sender, EventArgs e)
        {
            ddl_location.Enabled = false;
            trNewLocation.Visible = true;
            txtNewLocation.Text = "";
        }

        protected void btnNewFacility_Click(object sender, EventArgs e)
        {
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            resetControls();
        }

        protected void btn_submit_loc_Click(object sender, EventArgs e)
        {
            string result = null;
            if (ddl_location.Enabled == true && ddl_location.SelectedValue != "0")
            {
                locdetails.Location = ddl_location.SelectedValue;
                locdetails.CreatedBy = Session["loggedinuserID"].ToString();
                locdetails.Description = txt_NewFacility.Text;
                locdetails.LocationCode = txtNewFacilityID.Text;
                result = mastersettingBAL.InsertNewFacilityMapping(locdetails);

            }
            else
            {
                result = "warning;Please select location from dropdown list";
            }
            if (result.Contains(';'))
            {
                ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
                if (result.Split(';')[0] == "success")
                {
                    txt_NewFacility.Text = "";
                    txtNewFacilityID.Text = "";
                }
            }
            BindFacilityMapping();
        }

        protected void btn_adddept_Click(object sender, EventArgs e)
        {
            string result = null;
            if (txt_NewDepartmentID.Text.Trim() == "" || txt_newDepartment.Text.Trim() == "")
            {
                ShowAccountUserMessage("error", "Please fill mandatory fields");
            }
            else
            {
                objAccount.DepartmentID = txt_NewDepartmentID.Text;
                objAccount.DepartmentName = txt_newDepartment.Text;
                objAccount.CreatedBy = Session["loggedinuserID"].ToString();
                result = mastersettingBAL.DepartmentAddition(objAccount);
                if (result.Contains(';'))
                    ShowAccountUserMessage(result.Split(';')[0], result.Split(';')[1]);
                BindDepartment();
                ddl_department.Enabled = true;
                tblnewreq.Visible = false;
            }
        }

        protected void BindDepartment()
        {
            DataSet ds = new DataSet();
            ds = mastersettingBAL.BindDepartment();
            ddl_department.DataSource = ds.Tables[0];
            ddl_department.DataValueField = "DepartmentID";
            ddl_department.DataTextField = "DepartmentName";
            ddl_department.DataBind();
            ddl_department.Items.Insert(0, new ListItem("Please select Department", "0"));
        }

        protected void BindVertical()
        {
            DataSet ds = new DataSet();
            ds = mastersettingBAL.BindVertical();
            ddl_vertical.DataSource = ds.Tables[0];
            ddl_vertical.DataValueField = "VerticalID";
            ddl_vertical.DataTextField = "VerticalName";
            ddl_vertical.DataBind();
            ddl_vertical.Items.Insert(0, new ListItem("Please select Vertical", "0"));
            ddl_Vertical_Project.DataSource = ds.Tables[0];
            ddl_Vertical_Project.DataValueField = "VerticalID";
            ddl_Vertical_Project.DataTextField = "VerticalName";
            ddl_Vertical_Project.DataBind();
            ddl_Vertical_Project.Items.Insert(0, new ListItem("Please select Vertical", "0"));
        }

        protected void btn_addvertical_Click(object sender, EventArgs e)
        {
            if (txt_newVerticalID.Text.Trim() == "" || txt_newVertical.Text.Trim() == "")
            {
                ShowAccountUserMessage("error", "Please fill mandatory fields");
            }
            else
            {
                objAccount.VerticalID = txt_newVerticalID.Text;
                objAccount.VerticalName = txt_newVertical.Text;
                objAccount.CreatedBy = Session["loggedinuserID"].ToString();
                string result = mastersettingBAL.VerticalAddition(objAccount);
                if (result.Contains(';'))
                    ShowAccountUserMessage(result.Split(';')[0], result.Split(';')[1]);
                BindVertical();
                ddl_vertical.Enabled = true;
                tblNVertical.Visible = false;
            }
        }

        protected void GV_AccountDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GV_AccountDetails.PageIndex = e.NewPageIndex;
            GV_AccountDetails.EditIndex = -1;
            BindFilteredAccountMappingDetails();
        }

        protected void GV_AccountDetailsBind()
        {
            DataSet ds = mastersettingBAL.BindAccountDetails();
            GV_AccountDetails.DataSource = ds.Tables[0];
            Session["dsAccounttbl"] = ds.Tables[0];
            ViewState["dsAccountMapping"] = ds.Tables[0];
            GV_AccountDetails.DataBind();
        }

        protected void BindFacilityMapping()
        {
            DataSet dsFacility = mastersettingBAL.GetFacilityMapping();
            gv_FacilityMapping.DataSource = dsFacility;
            Session["dsFacility"] = dsFacility.Tables[0];
            gv_FacilityMapping.DataBind();
        }
        protected void BindProjectMapping()
        {
            DataSet dsProjects = mastersettingBAL.GetProjectDetails();
            gv_ProjectMapping.DataSource = dsProjects;
            Session["dsProjects"] = dsProjects.Tables[0];
            ViewState["dsProjectMapping"] = dsProjects.Tables[0];
            gv_ProjectMapping.DataBind();
        }
        protected void BindLocations()
        {
            DataTable dt = mastersettingBAL.BindLocations();
            ddl_location.DataSource = dt;
            ddl_location.DataValueField = "ID";
            ddl_location.DataTextField = "Location";
            ddl_location.DataBind();
            ddl_location.Items.Insert(0, new ListItem("Please select location", "0"));
        }

        protected void btn_AddLocation_Click(object sender, EventArgs e)
        {
            string result = null;
            locdetails.Location = txtNewLocation.Text;
            locdetails.CreatedBy = Session["loggedinuserID"].ToString();
            result = mastersettingBAL.InsertNewLocation(locdetails);
            if (result.Contains(';'))
            {
                ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
            }
            ddl_location.Enabled = true;
            trNewLocation.Visible = false;
            txtNewLocation.Text = "";
            BindLocations();

        }

        protected void ShowUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        protected void ShowAccountUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        protected void GVAccountDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditAccount")
            {
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                GV_AccountDetails.EditIndex = RowIndex;
                BindFilteredAccountMappingDetails();
            }

            if (e.CommandName == "UpdateAccount")
            {
                AccountDetails objAccount = new AccountDetails();
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                if (true)
                {
                    string sPrevAccountid = "";
                    TextBox txt_AccountID = (TextBox)GV_AccountDetails.Rows[RowIndex].FindControl("txt_AccountID");
                    TextBox txt_Account = (TextBox)GV_AccountDetails.Rows[RowIndex].FindControl("txt_Account");
                    Label lbl_DeptID = (Label)GV_AccountDetails.Rows[RowIndex].FindControl("lbl_DeptID");
                    Label lbl_VertID = (Label)GV_AccountDetails.Rows[RowIndex].FindControl("lbl_VertID");
                    Label lbl_AccID = (Label)GV_AccountDetails.Rows[RowIndex].FindControl("lbl_AccID");

                    if (!string.IsNullOrEmpty(txt_AccountID.Text.ToString()) && !string.IsNullOrEmpty(txt_Account.Text.ToString()))
                    {
                        int resultn;
                        if (!Int32.TryParse(txt_AccountID.Text, out resultn))
                        {
                            ShowAccountUserMessage("information", "Account ID should be numeric");
                            return;
                        }
                        //fill object
                        objAccount.AccountID = txt_AccountID.Text.ToString();
                        objAccount.AccountName = txt_Account.Text.ToString();
                        objAccount.DepartmentID = lbl_DeptID.Text.ToString();
                        objAccount.VerticalID = lbl_VertID.Text.ToString();
                        objAccount.ID = lbl_AccID.Text.ToString();
                        objAccount.CreatedBy = Session["loggedinuserID"].ToString();
                        DataTable dtAccount = new DataTable();
                        dtAccount = ((DataTable)Session["dsAccounttbl"]);
                        DataRow[] dr = dtAccount.Select("ID = '" + lbl_AccID.Text.ToString() + "'");
                        if (dr.Count() > 0)
                        {
                            sPrevAccountid = dr[0].ItemArray[5].ToString();
                        }
                        objAccount.PrevAccountID = sPrevAccountid;
                        string result = UpdateinAccount(objAccount);
                        GV_AccountDetails.EditIndex = -1;
                        BindFilteredAccountMappingDetails();
                        if (result.Contains(';'))
                        {
                            ShowAccountUserMessage(result.Split(';')[0], result.Split(';')[1]);
                        }
                    }
                    else
                    {
                        string message = "error; AccountID and Account Name are Mandatory";
                        if (message.Contains(';'))
                        {
                            ShowAccountUserMessage(message.Split(';')[0], message.Split(';')[1]);
                        }
                    }
                }
            }
            if (e.CommandName.ToString().ToLower() == "CancelAccount".ToLower())
            {
                GV_AccountDetails.EditIndex = -1;
                BindFilteredAccountMappingDetails();
                dvAccountMessage.Visible = false;
                dvUserMessage.Visible = false;
            }
        }

        protected void gvFacilityMapping_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditLocation")
            {
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                gv_FacilityMapping.EditIndex = RowIndex;
                BindFacilityMapping();
            }

            if (e.CommandName == "UpdateLocation")
            {
                string sPrevFacilityID = "";
                FacilityDtls objFacilitydtl = new FacilityDtls();
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                bool bExec = txtFacilityCodeChange(RowIndex);
                if (bExec)
                {
                    TextBox txt_FACILITY = (TextBox)gv_FacilityMapping.Rows[RowIndex].FindControl("txt_FACILITY");
                    Label lbl_LOCATION = (Label)gv_FacilityMapping.Rows[RowIndex].FindControl("lbl_LOCATION");
                    TextBox txt_FACILITYCODE = (TextBox)gv_FacilityMapping.Rows[RowIndex].FindControl("txt_FACILITYCODE");
                    Label lbl_FacilityID = (Label)gv_FacilityMapping.Rows[RowIndex].FindControl("lbl_FacilityID");

                    if (!string.IsNullOrEmpty(txt_FACILITYCODE.Text.ToString()) && !string.IsNullOrEmpty(txt_FACILITY.Text.ToString()))
                    {
                        //fill object
                        objFacilitydtl.FacilityCode = txt_FACILITYCODE.Text.ToString();
                        objFacilitydtl.FacilityName = txt_FACILITY.Text.ToString();
                        objFacilitydtl.FacilityID = lbl_FacilityID.Text.ToString();

                        //Get previous value
                        DataTable dsFacility = new DataTable();
                        dsFacility = ((DataTable)Session["dsFacility"]);
                        DataRow[] dr = dsFacility.Select("ID = '" + lbl_FacilityID.Text.ToString() + "'");
                        if (dr.Count() > 0)
                        {
                            sPrevFacilityID = dr[0].ItemArray[1].ToString();
                        }
                        objFacilitydtl.PrevFacilityCode = sPrevFacilityID.ToString().Trim();
                        string result = UpdateinFacilitydtls(objFacilitydtl);
                        gv_FacilityMapping.EditIndex = -1;
                        BindFacilityMapping();
                        if (result.Contains(';'))
                        {
                            ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
                        }
                    }
                    else
                    {
                        string message = "error; FaacilityCode and Facility are Mandatory";
                        if (message.Contains(';'))
                        {
                            ShowUserMessage(message.Split(';')[0], message.Split(';')[1]);
                        }
                    }
                }
            }

            if (e.CommandName.ToString().ToLower() == "CancelLocation".ToLower())
            {
                gv_FacilityMapping.EditIndex = -1;
                dvAccountMessage.Visible = false;
                dvUserMessage.Visible = false;
                BindFacilityMapping();
            }
        }


        protected string UpdateinAccount(AccountDetails objAccount)
        {
            string rslt = mastersettingBAL.UpdateAccountdtls(objAccount);
            return rslt;

        }
        protected string UpdateinFacilitydtls(FacilityDtls objFacilitydtl)
        {
            string rslt = mastersettingBAL.UpdateFacilitydtls(objFacilitydtl);
            return rslt;
        }

        protected bool txtFacilityCodeChange(int Rowindex)
        {
            bool bexec = true;

            TextBox txt_FacilityCodedt = (TextBox)gv_FacilityMapping.Rows[Rowindex].FindControl("txt_FACILITYCODE");
            string stxt = txt_FacilityCodedt.Text.ToString().Trim();
            for (int i = 0; i < gv_FacilityMapping.Rows.Count; i++)
            {
                if (Rowindex != i)
                {
                    Label lbl_facilitycode = (Label)gv_FacilityMapping.Rows[i].FindControl("lbl_FACILITYCODE");
                    if (stxt.ToLower() == lbl_facilitycode.Text.ToString().ToLower().Trim())
                    {
                        bexec = false;
                        ShowUserMessage("error", "Duplicate FacilityCode not allowed.");
                        return bexec;
                    }
                }
            }
            return bexec;
        }

        protected bool txtAccountChange(int index)
        {
            bool bexec = true;
            TextBox txt_AccountIDdt = (TextBox)GV_AccountDetails.Rows[index].FindControl("txt_AccountID");
            string stxt = txt_AccountIDdt.Text.ToString().Trim();
            for (int i = 0; i < GV_AccountDetails.Rows.Count; i++)
            {
                if (index != i)
                {
                    Label lbl_account = (Label)GV_AccountDetails.Rows[i].FindControl("lbl_AccountID");
                    if (stxt.ToLower() == lbl_account.Text.ToString().ToLower().Trim())
                    {
                        bexec = false;
                        ShowAccountUserMessage("error", "Duplicate AccountID Not allowed.");
                        return bexec;
                    }
                }
            }
            return bexec;
        }

        protected void HidedivMessage()
        {
            dvAccountMessage.Visible = false;
            dvUserMessage.Visible = false;
        }

        protected void gv_FacilityMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_FacilityMapping.PageIndex = e.NewPageIndex;
            gv_FacilityMapping.EditIndex = -1;
            BindFacilityMapping();
        }
        protected void btnGridSearch_Click(object sender, ImageClickEventArgs e)
        {
            BindFilteredAccountMappingDetails();
            GV_AccountDetails.SetPageIndex(0);
        }
        protected void btnGridReset_Click(object sender, ImageClickEventArgs e)
        {
            resetGridFilters();
            GV_AccountDetails.EditIndex = -1;
            GV_AccountDetails.PageIndex = 0;
            GV_AccountDetailsBind();
        }
        protected void BindFilteredAccountMappingDetails()
        {

            GV_AccountDetailsBind();
            DataTable dt;
            dt = (DataTable)ViewState["dsAccountMapping"];
            String searchType = "STRING";
            switch (ddlSearchBy.SelectedItem.Text.ToString().ToLower())
            {
                case "vertical":
                    string searchkey = txtGridSearch.Text;
                    searchkey = searchkey.Replace("\n", String.Empty);
                    searchkey = searchkey.Replace("\r", String.Empty);
                    searchkey = searchkey.Replace("\t", String.Empty);
                    dt = gridOp.FilterGridRecords(dt, "VERTICALNAME", searchkey, searchType);
                    break;
                case "account":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "ACCOUNTNAME", txtGridSearch.Text, searchType);
                    break;
                case "account id":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "ACCOUNTID", txtGridSearch.Text, searchType);
                    break;
                case "department":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "DEPARTMENTNAME", txtGridSearch.Text, searchType);
                    break;
                default: break;
            }
            GV_AccountDetails.DataSource = dt;
            GV_AccountDetails.DataBind();
            ViewState["dsAccountMapping"] = dt;
        }
        protected void resetGridFilters()
        {
            txtGridSearch.Text = "";
            ddlSearchBy.SelectedValue = "1";
        }

        protected void btn_Submit_Project_Click(object sender, EventArgs e)
        {
            string result = null;
            ProjectDetails objProjDetails = new ProjectDetails();
            objProjDetails.ProjectID = txt_ProjectID.Text.Trim();
            objProjDetails.ProjectName = txt_ProjectName.Text.Trim();
            objProjDetails.VerticalID = ddl_Vertical_Project.SelectedValue;
            objProjDetails.Action = "save";
            objProjDetails.UserID = Convert.ToString(Session["loggedinUserID"]);
            result = ManageProjectDetails(objProjDetails);
            if (result.ToLower().Contains("success"))
            {
                ShowUserMessage("info", "Project added succesfully");
                txt_ProjectID.Text = "";
                txt_ProjectName.Text = "";
                ddl_Vertical_Project.ClearSelection();
                BindProjectMapping();
            }
            else
            {
                ShowUserMessage("info", result.Split(',')[1]);
            }
        }

        private string ManageProjectDetails(ProjectDetails objProjDetails)
        {
            return mastersettingBAL.ManageProjectDetails(objProjDetails);
        }

        protected void btn_Reset_Project_Click(object sender, EventArgs e)
        {
            txt_ProjectID.Text = "";
            txt_ProjectName.Text = "";
            ddl_Vertical_Project.SelectedIndex = 0;
        }

        protected void gv_ProjectMapping_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //int RowIndex = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "editD")
            {
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                gv_ProjectMapping.EditIndex = RowIndex;

            }
            else if (e.CommandName == "updateD" || e.CommandName == "deleteD")
            {
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                ProjectDetails objProjDetails = new ProjectDetails();
                objProjDetails.ProjectID = e.CommandName == "updateD" ? ((Label)gv_ProjectMapping.Rows[RowIndex].FindControl("lbl_ProjectID")).Text : null;
                objProjDetails.ProjectName = e.CommandName == "updateD" ? ((TextBox)gv_ProjectMapping.Rows[RowIndex].FindControl("txt_Projectname")).Text : null;
                objProjDetails.RowID = ((HiddenField)gv_ProjectMapping.Rows[RowIndex].FindControl("hdn_RowID")).Value;
                objProjDetails.Action = e.CommandName == "updateD" ? "update" : "delete";
                objProjDetails.VerticalID = e.CommandName == "updateD" ? ((DropDownList)gv_ProjectMapping.Rows[RowIndex].FindControl("ddl_Vertical_grid")).SelectedValue : null;
                objProjDetails.UserID = Convert.ToString(Session["loggedinUserID"]);
                string result = ManageProjectDetails(objProjDetails);
                if (result.ToLower().Contains("success"))
                    ShowUserMessage("info", result.Split(',')[1]);
                else
                    ShowUserMessage("info", result.Split(',')[1]);
                gv_ProjectMapping.EditIndex = -1;
            }
            else if (e.CommandName.ToString().ToLower() == "cancelD".ToLower())
            {
                gv_ProjectMapping.EditIndex = -1;
            }
            BindFilteredProjectMappingDetails();
        }

        protected void gv_ProjectMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_ProjectMapping.PageIndex = e.NewPageIndex;
            gv_ProjectMapping.EditIndex = -1;
            BindFilteredProjectMappingDetails();
        }

        protected void gv_ProjectMapping_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = gv_ProjectMapping.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && gv_ProjectMapping.EditIndex == e.Row.RowIndex)
            {
                HiddenField hdn_Vertical = (HiddenField)e.Row.FindControl("hdn_VerticalName");
                DropDownList ddl_verticals = (DropDownList)e.Row.FindControl("ddl_Vertical_grid");
                foreach (ListItem item in ddl_Vertical_Project.Items)
                {
                    ddl_verticals.Items.Add(new ListItem(item.Text, item.Value));
                }
                ddl_verticals.Items.RemoveAt(0);
                ddl_verticals.Items.FindByText(Convert.ToString(hdn_Vertical.Value)).Selected = true;
                ((ImageButton)e.Row.FindControl("imgDelete")).Enabled = false;
            }
            else if (e.Row.RowType == DataControlRowType.DataRow)
            {
                HiddenField hdn_Associates = (HiddenField)e.Row.FindControl("hdn_AssociatesCount");
                if (Convert.ToInt32(hdn_Associates.Value) > 0)
                {
                    ((ImageButton)e.Row.FindControl("imgDelete")).Enabled = false;
                    ((ImageButton)e.Row.FindControl("imgDelete")).ToolTip = "Cannot be deleted, Associates are tagged under this project";
                    ((ImageButton)e.Row.FindControl("imgDelete")).Style.Add(HtmlTextWriterStyle.Cursor, "default");
                }
            }
        }

        protected void btnProjectGridFilter_Click(object sender, ImageClickEventArgs e)
        {
            BindFilteredProjectMappingDetails();
            GV_AccountDetails.SetPageIndex(0);
        }
        protected void BindFilteredProjectMappingDetails()
        {
            BindProjectMapping();
            DataTable dt;
            dt = (DataTable)ViewState["dsProjectMapping"];
            String searchType = "STRING";
            switch (ddlProjectFilters.SelectedItem.Text.ToString().ToLower())
            {
                case "project id":
                    string searchkey = txtProjectFilter.Text;
                    searchkey = searchkey.Replace("\n", String.Empty);
                    searchkey = searchkey.Replace("\r", String.Empty);
                    searchkey = searchkey.Replace("\t", String.Empty);
                    dt = gridOp.FilterGridRecords(dt, "ProjectID", searchkey, searchType);
                    break;
                case "project name":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "ProjectName", txtProjectFilter.Text, searchType);
                    break;
                case "vertical":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, "VerticalName", txtProjectFilter.Text, searchType);
                    break;
                default: break;
            }
            gv_ProjectMapping.DataSource = dt;
            gv_ProjectMapping.DataBind();
            ViewState["dsProjectMapping"] = dt;
        }
        protected void btnProjectGridReset_Click(object sender, ImageClickEventArgs e)
        {
            txtProjectFilter.Text = "";
            gv_ProjectMapping.EditIndex = -1;
            BindProjectMapping();
        }

        protected void BindConnectsMapping()
        {
            DataSet dsConnects = mastersettingBAL.GetConnectDetails();
            GrdConnectType.DataSource = dsConnects;
            Session["dsConnects"] = dsConnects.Tables[0];
            ViewState["dsConnectsMapping"] = dsConnects.Tables[0];
            GrdConnectType.DataBind();
        }

        protected void btn_Submit_Connects_Type_Click(object sender, EventArgs e)
        {
            string result = null;
            ConnectDetails objConnectDetails = new ConnectDetails();

            objConnectDetails.ConnectName = txt_ConnectsName.Text.Trim();
            objConnectDetails.Action = "save";
            result = ManageConnectDetails(objConnectDetails);
            if (result.ToLower().Contains("success"))
            {
                ShowUserMessage("info", "Connect Type added succesfully");

                txt_ConnectsName.Text = "";
                BindConnectsMapping();
            }
            else
            {
                ShowUserMessage("info", result.Split(',')[1]);
            }
        }

        protected bool txtConnectTypeChange(int Rowindex)
        {
            bool bexec = true;

            TextBox txt_ConnectType = (TextBox)GrdConnectType.Rows[Rowindex].FindControl("txt_ConnectType");
            string stxt = txt_ConnectType.Text.ToString().Trim();
            for (int i = 0; i < GrdConnectType.Rows.Count; i++)
            {
                if (Rowindex != i)
                {
                    Label lbl_ConnectType = (Label)gv_FacilityMapping.Rows[i].FindControl("lbl_ConnectType");
                    if (stxt.ToLower() == lbl_ConnectType.Text.ToString().ToLower().Trim())
                    {
                        bexec = false;
                        ShowUserMessage("error", "Duplicate FacilityCode not allowed.");
                        return bexec;
                    }
                }
            }
            return bexec;
        }

        protected void GrdConnectType_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "Edit")
            {
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                GrdConnectType.EditIndex = RowIndex;
                BindConnectsMapping();

            }
            else if (e.CommandName == "Update" || e.CommandName == "Delete")
            {
                //string sPrevFacilityID = "";
                int RowIndex = Convert.ToInt32(e.CommandArgument);
                //bool bExec = txtFacilityCodeChange(RowIndex);
                //if (bExec)
                //{
                //    Label lbl_ConnectType = (Label)gv_FacilityMapping.Rows[RowIndex].FindControl("lbl_ConnectType");
                //    TextBox txt_ConnectType = (TextBox)gv_FacilityMapping.Rows[RowIndex].FindControl("txt_ConnectType");

                //    if (!string.IsNullOrEmpty(txt_ConnectType.Text.ToString()))
                //    {
                //        //fill object
                //        conndetails.ConnectName = lbl_ConnectType.Text.ToString();


                //        //Get previous value
                //        DataTable dsFacility = new DataTable();
                //        dsFacility = ((DataTable)Session["dsFacility"]);
                //        DataRow[] dr = dsFacility.Select("ID = '" + lbl_ConnectType.Text.ToString() + "'");
                //        if (dr.Count() > 0)
                //        {
                //            sPrevFacilityID = dr[0].ItemArray[1].ToString();
                //        }
                //        conndetails.ConnectName = sPrevFacilityID.ToString().Trim();
                //        string result = ManageConnectDetails(conndetails);
                //        gv_FacilityMapping.EditIndex = -1;
                //        BindFacilityMapping();
                //        if (result.Contains(';'))
                //        {
                //            ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
                //        }
                //    }
                //    else
                //    {
                //        string message = "error; FaacilityCode and Facility are Mandatory";
                //        if (message.Contains(';'))
                //        {
                //            ShowUserMessage(message.Split(';')[0], message.Split(';')[1]);
                //        }
                //    }
                //}






                conndetails.ConnectName = e.CommandName == "update" ? ((TextBox)GrdConnectType.Rows[RowIndex].FindControl("txt_ConnectType")).Text : ((Label)GrdConnectType.Rows[RowIndex].FindControl("lbl_ConnectType")).Text;
                conndetails.Action = e.CommandName == "update" ? "update" : "delete";
                string result = ManageConnectDetails(conndetails);
                if (result.ToLower().Contains("success"))
                    ShowUserMessage("info", result.Split(',')[1]);
                else
                    ShowUserMessage("info", result.Split(',')[1]);
                GrdConnectType.EditIndex = -1;
            }
            else if (e.CommandName.ToString().ToLower() == "cancelD".ToLower())
            {
                GrdConnectType.EditIndex = -1;
            }
        }

        private string ManageConnectDetails(ConnectDetails objConnectDetails)
        {
            return mastersettingBAL.ManageConnectDetails(objConnectDetails);
        }
        protected void btn_Reset_Connects_Type_Click(object sender, EventArgs e)
        {
            txt_ConnectsName.Text = "";
        }

        protected void GrdConnectType_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdConnectType.PageIndex = e.NewPageIndex;
            GrdConnectType.EditIndex = -1;
            BindConnectsMapping();
        }

        protected void GrdConnectType_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = GrdConnectType.EditIndex;

            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && GrdConnectType.EditIndex == e.Row.RowIndex)
            {
                HiddenField hdn_IsEditable = (HiddenField)e.Row.FindControl("hdn_Editable");
                TextBox CommenntType = (TextBox)e.Row.FindControl("hdn_AssociatesCount");
                if (Convert.ToString(hdn_IsEditable.Value) == "N")
                {
                    ((ImageButton)e.Row.FindControl("imgDelete")).Enabled = false;
                    //((ImageButton)e.Row.FindControl("imgEdit")).Enabled = false;
                    ((ImageButton)e.Row.FindControl("imgDelete")).Style.Add(HtmlTextWriterStyle.Cursor, "default");
                }
                else
                {
                    ((ImageButton)e.Row.FindControl("imgDelete")).Enabled = true;
                    //((ImageButton)e.Row.FindControl("imgEdit")).Enabled = true;
                }
            }
        }

    }

}

