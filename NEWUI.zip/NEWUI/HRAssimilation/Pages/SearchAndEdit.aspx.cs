﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using HRAssimilation.Entity;
using HRAssimilation.Business;

namespace HRAssimilation.Pages
{
    /// <summary>
    /// SearchAndEdit is used to search and edit the details of users
    /// </summary>
    public partial class SearchAndEdit : System.Web.UI.Page
    {
        SearchAndEditAssociateDetails SearchAssociateDetails = new SearchAndEditAssociateDetails();
        SearchAndEditBAL SearchBAL = new SearchAndEditBAL();
        MasterSettingConfigBAL mastercongigBAL = new MasterSettingConfigBAL();
        AssociateDetails objAssociateDetails = new AssociateDetails();
        UserConfigurationBAL objUserOp = new UserConfigurationBAL();
        UserOperationsBAL objUOP = new UserOperationsBAL();
        Logger.Logger log = new Logger.Logger();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                {
                    Response.Redirect("Login.aspx", true);
                }

                if (Convert.ToString(Session["role"]) == "3" || Convert.ToString(Session["role"]) == "2")
                {
                    dvDetailsMain.Visible = false;
                    dvSearchFilters.Visible = true;
                    dvUserFilterMessage.Visible = false;
                }
                else
                {
                    Response.Redirect("Dashboard.aspx", false);
                }                
            }

            lbl_save.Visible = false;
            hideMessageControl();
        }
        /// <summary>
        /// hideMessageControl
        /// </summary>
        protected void hideMessageControl()
        {
            dvUserMessage.Visible = false;
            dvUserFilterMessage.Visible = false;
        }
        /// <summary>
        /// validateAssociateAndLeadLocations 
        /// </summary>
        /// <returns></returns>
        public bool validateAssociateAndLeadLocations()
        {
            try
            {
                string loggedinuserid = Convert.ToString(Session["loggedinuserid"]);
                return SearchBAL.ValidateloggedinuserLocation(loggedinuserid, txt_assoid.Text);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// btn_search_Click is used to search the user details on button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_search_Click(object sender, EventArgs e)
        {
            hideMessageControl();
            GV_SearchUsrDetails.Visible = false;            
            try
            { 
                if (string.IsNullOrEmpty(txtbox_searchuid.Text.Trim()) && string.IsNullOrEmpty(txt_doj.Text.Trim()))
                {
                    showUserFilterMessage("error", "Please provide input to proceed.");
                }

                if (!string.IsNullOrEmpty(txtbox_searchuid.Text.Trim()) && txt_doj.Text.Trim() != "")
                {
                    //get user details based on both userid & doj
                    ShowDetails(txtbox_searchuid.Text.Trim(), txt_doj.Text.Trim());  
                }
                else
                    if (!string.IsNullOrEmpty(txtbox_searchuid.Text.Trim()) && txt_doj.Text.Trim() == "")
                    {
                        string userid = txtbox_searchuid.Text.Trim();
                        ShowDetails(userid);
                        
                    }
                    else
                        if (txt_doj.Text.Trim() != "")
                        {
                            string selecteddate = txt_doj.Text;
                            DateTime objSelecteddate = DateTime.Parse(selecteddate, System.Globalization.CultureInfo.InvariantCulture);
                            selecteddate = objSelecteddate.ToString("yyyy-MM-dd");
                            GV_SearchUsrDetails.DataSource = GetUsersDetails(selecteddate, Convert.ToInt32(Session["Role"]), Convert.ToString(Session["loggedinUserid"]));
                            GV_SearchUsrDetails.DataBind();
                            GV_SearchUsrDetails.Visible = true;
                        }
                
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        /// <summary>
        /// ShowDetails is used to show details of user
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="doj"></param>
        protected void ShowDetails(string userid, string doj)
        {
            DataSet userDetails = objUOP.CheckIfUserExists(userid, doj);

            if (userDetails != null & userDetails.Tables.Count > 0)
            {
                if (userDetails != null && userDetails.Tables[0].Rows.Count > 0)
                    ShowDetails(userid);
            }
            else
            {
                showUserFilterMessage("error", "No Associate details available for given combination.");
            }
        }
        /// <summary>
        /// ShowDetails is used to show details of user
        /// </summary>
        /// <param name="userid"></param>
        protected void ShowDetails(string userid)
        {
            hideMessageControl();
            Session["associateID"] = userid;
            objAssociateDetails = GetAssociateDetails(userid);
            if (objAssociateDetails==null || objAssociateDetails.AssociateID == null)
            {
               showUserFilterMessage("error", "Please provide valid user id");
            }
            else
            {                
                if (Session["role"].ToString() == "3")
                {
                    BindDepartment();
                    BindVertical();
                    bindUserDetails(objAssociateDetails);
                    tbl_ResignationDetails.Visible = false;
                    if (validateAssociateAndLeadLocations())
                    {
                        if (objAssociateDetails.status == "Terminated" || Convert.ToInt32(objAssociateDetails.Tenure)> 180)
                        {
                            disableControls();                           
                        }
                        else
                        enableControls();                        
                    }
                    else
                    {
                        disableControls();                        
                    }
                    dvSearchFilters.Visible = false;
                    dvDetailsMain.Visible = true;
                }
                else
                    if (Session["role"].ToString() == "2")
                    {
                        if (Session["loggedinUserid"].ToString().Equals(objAssociateDetails.TMPOC))
                        {
                            dvSearchFilters.Visible = false;
                            dvDetailsMain.Visible = true;
                            BindDepartment();
                            BindVertical();
                            bindUserDetails(objAssociateDetails);
                        }
                        else
                        {
                            dvDetailsMain.Visible = false;
                            dvSearchFilters.Visible = true;
                            showUserFilterMessage("warning", "Unauthorized to view details");
                        }
                    }

            }
        }
        /// <summary>
        /// GetUsersDetails is used to retrieve user details from DB
        /// </summary>
        /// <param name="joiningdate"></param>
        /// <returns></returns>
        protected DataSet GetUsersDetails(string joiningdate,int role,string loggedinUserID)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = SearchBAL.GetUsersDetails(joiningdate, role, loggedinUserID);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }
        /// <summary>
        /// GV_SearchUsrDetails_RowEditing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GV_SearchUsrDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {



        }
        /// <summary>
        /// GV_SearchUsrDetails_SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GV_SearchUsrDetails_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// disableControls
        /// </summary>
        protected void disableControls()
        {
            td_override.Visible = false;
            td_save.Visible = false;
            td_reset.Visible = false;
            txt_rsnforrsgn.Disabled = true;
            txt_dtldrsnforja.Disabled = true;
            ddl_location.Enabled = false;
            ddl_sublocation.Enabled = false;
            ddl_department.Enabled = false;
            ddl_vertical.Enabled = false;
            ddl_account.Enabled = false;
            txt_supervisorid.Enabled = false;
            ddl_account.Enabled = false;
            ddl_Project.Enabled = false;
        }
        /// <summary>
        /// enableControls
        /// </summary>
        protected void enableControls()
        {
            td_override.Visible = true;
            td_save.Visible = true;
            td_reset.Visible = true;
            txt_dtldrsnforja.Disabled = true;
            txt_rsnforrsgn.Disabled = true;
            ddl_location.Enabled = true;
            ddl_sublocation.Enabled = true;
            ddl_department.Enabled = true;
            ddl_vertical.Enabled = true;
            ddl_account.Enabled = true;
            txt_supervisorid.Enabled = true;
            ddl_account.Enabled = true;
            ddl_Project.Enabled = true;
        }
        /// <summary>
        /// bindUserDetails is used to bind user details
        /// </summary>
        /// <param name="objAssociateDetails"></param>
        protected void bindUserDetails(AssociateDetails objAssociateDetails)
        {
            try
            {

                ddl_location_bind();
                txt_assoid.Text = objAssociateDetails.AssociateID;
                txt_assoname.Text = objAssociateDetails.AssociateName;
                txt_designation.Text = objAssociateDetails.Designation;
                txt_gender.Text = objAssociateDetails.Gender;
                if (!string.IsNullOrEmpty(objAssociateDetails.DateOfBirth))
                {
                    DateTime dt = Convert.ToDateTime(objAssociateDetails.DateOfBirth);
                    txt_dob.Text = String.Format("{0:dd-MMM}", dt);
                }
                else
                txt_dob.Text = objAssociateDetails.DateOfBirth;
                txt_status.Text = objAssociateDetails.status;
                if (objAssociateDetails.status == "Terminated" || objAssociateDetails.status == "Out of Assimilation Scope")
                {
                    disableControls();
                }
                else
                {
                    enableControls();
                }
                
                ddl_location.ClearSelection();
                ddl_location.Items.FindByText(objAssociateDetails.Location).Selected = true;
                LoadSublocations();
                ddl_sublocation.ClearSelection();
                ddl_sublocation.Items.FindByValue(objAssociateDetails.SubLocationCode).Selected = true;
                ddl_department.ClearSelection();
                ddl_department.Items.FindByValue(objAssociateDetails.DepartmentID).Selected = true;
                ddl_vertical.ClearSelection();
                ddl_vertical.Items.FindByValue(objAssociateDetails.VerticalID).Selected = true;
                BindAccount();                
                ddl_account.Items.FindByValue(objAssociateDetails.AccountID).Selected = true;
                ddl_Project.Items.FindByValue(objAssociateDetails.ProjectID).Selected = true;
                txt_supervisorid.Text = objAssociateDetails.SupervisorID;
                txt_supervisorname.Text = objAssociateDetails.SupervisorName;
                txt_dateofjoining.Text = objAssociateDetails.HireDate;
                txt_tenure.Text = objAssociateDetails.Tenure;
                txt_lastresgdt.Text = objAssociateDetails.LastResignationDate;
                txt_lstresgwithdrwdt.Text = objAssociateDetails.LastResignationWithdrawlDate;
                txt_lstjaraised.Text = objAssociateDetails.LastJARaisedDate;
                txt_lstresgrsn.Text = objAssociateDetails.LastResignationReason;
                txt_lstresgwdrsn.Text = objAssociateDetails.LastResignationReason;
                txt_lstjarsn.Text = objAssociateDetails.LastJAReason;
                txt_rsnforrsgn.InnerText = objAssociateDetails.DetailedReasonforResignation;
                if (objAssociateDetails.LastWorkingDate != null && objAssociateDetails.LastWorkingDate.Contains("1900")) txt_lwd.Text = "";
                else
                txt_lwd.Text = objAssociateDetails.LastWorkingDate;
                if (objAssociateDetails.JARevokedDate!=null && objAssociateDetails.JARevokedDate.Contains("1900")) txt_jarvkddt.Text = "";
                else
                txt_jarvkddt.Text = objAssociateDetails.JARevokedDate;
                txt_dtldrsnforja.InnerText = objAssociateDetails.DetailedReasonforJA;

                if (objAssociateDetails.DiscussionwithManager == "Yes")
                    rb_dscnmngr_yes.Checked = true;
                else
                    if (objAssociateDetails.DiscussionwithManager == "No")
                        rb_dscnmngr_no.Checked = true;
                    else
                    {
                        rb_dscnmngr_yes.Checked = false;
                        rb_dscnmngr_no.Checked = false;
                    }

                if (objAssociateDetails.RetentionDiscussionwithAssociate == "Yes")
                    rb_rtndsnasso_yes.Checked = true;
                else
                    if (objAssociateDetails.RetentionDiscussionwithAssociate == "No")
                        rb_rtndsnasso_no.Checked = true;
                    else
                    {
                        rb_rtndsnasso_yes.Checked = false;
                        rb_rtndsnasso_no.Checked = false;
                    }

                if (objAssociateDetails.LastWorkingDayUpdatedinSystem == "Yes")
                    rb_lwduptdsys_yes.Checked = true;
                else
                    if (objAssociateDetails.LastWorkingDayUpdatedinSystem == "Yes")
                        rb_lwduptdsys_no.Checked = true;
                    else
                    {
                        rb_lwduptdsys_yes.Checked = false;
                        rb_lwduptdsys_no.Checked = false;
                    }

                if (objAssociateDetails.JARevoked == "Yes")
                    rb_jarvkd_yes.Checked = true;
                else
                    if (objAssociateDetails.JARevoked == "No")
                        rb_jarvkd_no.Checked = true;
                    else
                    {
                        rb_jarvkd_yes.Checked = false;
                        rb_jarvkd_no.Checked = false;
                    }
                DataSet ds = SearchBAL.GetEWSData(objAssociateDetails.AssociateID);

                GV_grpcnts.DataSource = ds.Tables[0];
                GV_grpcnts.DataBind();

                grdView_indvcnts.DataSource = ds.Tables[1];
                grdView_indvcnts.DataBind();

                cb_overide.Checked = objAssociateDetails.OverrideHCM == "1" ? true : false;
                ConnectEWSDetails objConnectewsdtls = GetConnectdtls(objAssociateDetails.AssociateID);
                BindConnectAndEWSDtls(objConnectewsdtls);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }
        /// <summary>
        /// BindConnectAndEWSDtls is used to Connect and EWS details
        /// </summary>
        /// <param name="objConnectdtls"></param>
        protected void BindConnectAndEWSDtls(ConnectEWSDetails objConnectdtls)
        {
            
            txt_ewsm1.BackColor = (objConnectdtls.EWSStatus1 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus1.ToString())) : System.Drawing.Color.FromName("White");
            txt_ews2.BackColor = (objConnectdtls.EWSStatus2 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus2.ToString())) : System.Drawing.Color.FromName("White");
            txt_ews3.BackColor = (objConnectdtls.EWSStatus3 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus3.ToString())) : System.Drawing.Color.FromName("White");
            
            txt_recentcomts.InnerText = (objConnectdtls.Comments != null) ? objConnectdtls.Comments.ToString() : "";

            string lastConnectDate = (objConnectdtls.RecentDate != null) ? objConnectdtls.RecentDate.ToString() : "";
            if (!(String.IsNullOrEmpty(lastConnectDate)))
            {
                DateTime objRecentDate = DateTime.Parse(lastConnectDate, System.Globalization.CultureInfo.InvariantCulture);
                lastConnectDate = objRecentDate.ToString("MM/dd/yyyy");
            }
            txt_dolastconnec.Text = lastConnectDate.Contains("0001") ? "" : lastConnectDate;
            txt_typeoflasconct.Text = (objConnectdtls.ConnectType != null) ? objConnectdtls.ConnectType.ToString() : "";
            txt_latestsysews.BackColor = (objConnectdtls.sEwsstatus != null) ? (System.Drawing.Color.FromName(objConnectdtls.sEwsstatus.ToString())) : System.Drawing.Color.FromName("White");
            txt_tmpocews.BackColor = (objConnectdtls.TLEWSStatus != null) ? (System.Drawing.Color.FromName(objConnectdtls.TLEWSStatus.ToString())) : System.Drawing.Color.FromName("White");
        }
        /// <summary>
        /// GetConnectdtls
        /// </summary>
        /// <param name="associateid"></param>
        /// <returns></returns>
        protected ConnectEWSDetails GetConnectdtls(string associateid)
        {
            Constant objCons = new Constant();
            string ConnectType = string.Empty;
            DateTime RecentConnectDate = new DateTime();
            ConnectEWSDetails objConnectdtls = new ConnectEWSDetails();
            DataSet ds = new DataSet();
            try
            {
                ds = objUserOp.GetPOCconnectdtls(associateid, objCons.POCConnectSP);
                DataTable dtEWS = new DataTable();
                DataTable dtConnect = new DataTable();
                DataTable dtComment = new DataTable();
                dtEWS = ds.Tables[0];
                dtConnect = ds.Tables[1];
                dtComment = ds.Tables[2];                
                if (dtConnect != null && dtConnect.Rows.Count == 1)
                {
                    ConnectType = Convert.ToString(dtConnect.Rows[0]["ConnectType"]);
                    RecentConnectDate = Convert.ToDateTime(dtConnect.Rows[0]["RecentDate"]);
                    objConnectdtls.RecentDate = RecentConnectDate.ToString();
                    objConnectdtls.ConnectType = ConnectType.ToString();
                }
                if (dtComment != null && dtComment.Rows.Count == 1)
                {
                    objConnectdtls.Comments = (dtComment.Rows[0]["TMPOCComment"] != null) ? dtComment.Rows[0]["TMPOCComment"].ToString() : "";
                }
                if (dtEWS != null && dtEWS.Rows.Count > 0)
                {
                    objConnectdtls.AssociateID = (dtEWS.Rows[0]["AssociateId"] != null) ? dtEWS.Rows[0]["AssociateId"].ToString() : "";                    
                    
                    objConnectdtls.sEwsstatus = (dtEWS.Rows[0]["EWSStatus"] != null) ? dtEWS.Rows[0]["EWSStatus"].ToString() : "";
                    objConnectdtls.TLEWSStatus = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";                    
                    if (dtEWS.Rows.Count == 1)
                    {
                        objConnectdtls.EWSStatus1 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                    }
                    else
                        if (dtEWS.Rows.Count == 2)
                        {
                            objConnectdtls.EWSStatus2 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                            objConnectdtls.EWSStatus1 = (dtEWS.Rows[1]["TLEWS"] != null) ? dtEWS.Rows[1]["TLEWS"].ToString() : "";
                        }
                        else
                        {
                            objConnectdtls.EWSStatus3 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                            if (dtEWS.Rows.Count > 1)
                            {
                                objConnectdtls.EWSStatus2 = (dtEWS.Rows[1]["TLEWS"] != null) ? dtEWS.Rows[1]["TLEWS"].ToString() : "";
                                if (dtEWS.Rows.Count > 2)
                                    objConnectdtls.EWSStatus1 = (dtEWS.Rows[2]["TLEWS"] != null) ? dtEWS.Rows[2]["TLEWS"].ToString() : "";
                            }
                        }
                }
                return objConnectdtls;
            }
            catch (Exception e)
            {
                log.logError(e.Message + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// ShowAndEditDetails is used to retrieve and edit the details of user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ShowAndEditDetails(object sender, EventArgs e)
        {
             ImageButton ibtn1 = sender as ImageButton;
             int rowIndex = Convert.ToInt32(ibtn1.Attributes["RowIndex"]);
             string associateID = ibtn1.CommandArgument.ToString();
             ShowDetails(associateID);
        }
        /// <summary>
        /// GetAssociateDetails
        /// </summary>
        /// <param name="associateID"></param>
        /// <returns></returns>
        public AssociateDetails GetAssociateDetails(string associateID)
        {
            AssociateDetails objAssociateDetails = new AssociateDetails();
            try
            {
                UserOperationsBAL objUOP = new UserOperationsBAL();
                objAssociateDetails = objUOP.GetUserDetails(associateID);
                return objAssociateDetails;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        /// <summary>
        /// ValidData is used to check for empty data fields
        /// </summary>
        /// <returns></returns>
        protected bool ValidData()
        {
            if (txt_supervisorid.Text.Trim() == "" || ddl_location.SelectedItem.Text.Trim() == "" || ddl_sublocation.SelectedValue.Trim() == "" || ddl_vertical.SelectedValue.Trim() == "" || ddl_account.SelectedValue.Trim() == "" || txt_supervisorname.Text.Trim() == "" || ddl_department.SelectedValue.Trim() == "")
                return false;
            else
                return true;
        }       
        /// <summary>
        /// btn_save_Click is used to save the Associate details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                SearchAssociateDetails.AssociateID = txt_assoid.Text;
                if (ValidData())
                {
                    SearchAssociateDetails.SupervisorID = txt_supervisorid.Text;
                    SearchAssociateDetails.Location = ddl_location.SelectedItem.Text;
                    SearchAssociateDetails.SubLocation = ddl_sublocation.SelectedValue;
                    SearchAssociateDetails.Facility = ddl_sublocation.SelectedItem.Text;
                    SearchAssociateDetails.Vertical = ddl_vertical.SelectedValue;
                    SearchAssociateDetails.Account = ddl_account.SelectedValue;
                    SearchAssociateDetails.AccountName = ddl_account.SelectedItem.Text;
                    SearchAssociateDetails.SupervisorName = txt_supervisorname.Text;
                    SearchAssociateDetails.DepartmentID = ddl_department.SelectedValue;
                    SearchAssociateDetails.ProjectID = ddl_Project.SelectedValue;
                    SearchAssociateDetails.ModifiedBy = Convert.ToString(Session["loggedinUserid"]);                   
                    if (cb_overide.Checked)
                        SearchAssociateDetails.OverrideHCM = "1";
                    else
                        SearchAssociateDetails.OverrideHCM = "0";
                    string result = SearchBAL.UpdateAssociateDetails(SearchAssociateDetails);
                    if (result.Contains(';'))
                    {
                        if (result == "success;TMPOC Changed")
                        {

                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('TMPOC changed successfuly.','information');", true);
                            ReturnToSearch();
                            GV_SearchUsrDetails.Visible = false;
                            txt_doj.Text = "";
                            txtbox_searchuid.Text = "";
                        }
                        else
                        {
                            showUserMessage(result.Split(';')[0], result.Split(';')[1]);
                        }
                    }

                }
                else
                {
                    showUserMessage("error", "Please fill mandatory fields.");
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        /// <summary>
        /// btn_reset_Click is used the reset the data fields on button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_reset_Click(object sender, EventArgs e)
        {
            ResetValues();
            AssociateDetails objAssociateDetails = GetAssociateDetails(Session["associateID"].ToString());
            bindUserDetails(objAssociateDetails);
        }
        /// <summary>
        /// ResetValues
        /// </summary>
        protected void ResetValues()
        {
            txt_supervisorid.Text = string.Empty;
            txt_rsnforrsgn.InnerText = string.Empty;
            rb_dscnmngr_yes.Checked = false;
            rb_dscnmngr_no.Checked = false;
            rb_rtndsnasso_yes.Checked = false;
            rb_rtndsnasso_no.Checked = false;
            txt_lwd.Text = string.Empty;
            rb_lwduptdsys_yes.Checked = false;
            rb_lwduptdsys_no.Checked = false;
            txt_dtldrsnforja.InnerText = string.Empty;
            rb_jarvkd_yes.Checked = false;
            rb_jarvkd_no.Checked = false;
            txt_jarvkddt.Text = string.Empty;

        }
        /// <summary>
        /// btn_return_Click is used to redirect to Search page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_return_Click(object sender, EventArgs e)
        {
            ReturnToSearch();
        }
        /// <summary>
        /// txt_supervisorid_TextChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txt_supervisorid_TextChanged(object sender, EventArgs e)
        {
            ActiveDirectoryOperationsBAL objUserDetails = new ActiveDirectoryOperationsBAL();
            string userid = txt_supervisorid.Text;
            UserDetails ud = objUserDetails.getuserdetails(userid);

            if (userid == txt_assoid.Text)
            {
                lbl_save.Text = "Give Valid UserID";
                lbl_save.Visible = true;
            }

            else if ((Convert.ToString(ud.LastName) != null && Convert.ToString(ud.FirstName) != null))
            {
                txt_supervisorname.Text = ud.LastName + ',' + ud.FirstName;

            }
            else
            {
                txt_supervisorname.Text = "";
            }


        }
        /// <summary>
        /// ddl_location_bind binds the locations to dropdown
        /// </summary>
        protected void ddl_location_bind()
        {
            DataTable dt = new DataTable();
            dt = mastercongigBAL.BindLocations();
            ddl_location.DataSource = dt;
            ddl_location.DataTextField = "Location";
            ddl_location.DataValueField = "ID";
            ddl_location.DataBind();

            LoadSublocations();
        }
        /// <summary>
        /// LoadSublocations is used to load sublocations for location selected
        /// </summary>
        protected void LoadSublocations()
        {
            string LocationID = ddl_location.SelectedValue;
            DataTable dt = new DataTable();
            dt = SearchBAL.GetSubLocationDetails(LocationID);
            ddl_sublocation.DataSource = dt;
            ddl_sublocation.DataTextField = "FacilityName";
            ddl_sublocation.DataValueField = "Code";
            ddl_sublocation.DataBind();
        }
        /// <summary>
        /// ddl_location_SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_location_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSublocations();
        }
        /// <summary>
        /// BindDepartment is used to bind the department details
        /// </summary>
        protected void BindDepartment()
        {
            DataSet ds = new DataSet();
            ds = mastercongigBAL.BindDepartment();
            ddl_department.DataSource = ds.Tables[0];
            ddl_department.DataTextField = "DepartmentName";
            ddl_department.DataValueField = "DepartmentID";
            ddl_department.DataBind();
        }
        /// <summary>
        /// BindVertical is used to bind verticals
        /// </summary>
        protected void BindVertical()
        {
            DataSet ds = new DataSet();
            ds = mastercongigBAL.BindVertical();
            ddl_vertical.DataSource = ds.Tables[0];
            ddl_vertical.DataTextField = "VerticalName";
            ddl_vertical.DataValueField = "VerticalID";
            ddl_vertical.DataBind();
        }
        /// <summary>
        /// BindAccount is used to bind account details
        /// </summary>
        protected void BindAccount()
        {
            string DeptID = ddl_department.SelectedValue;
            string VerticalID = ddl_vertical.SelectedValue;
            DataSet ds = new DataSet();
            ds = SearchBAL.BindAccount(DeptID, VerticalID);
            ddl_account.DataSource = ds.Tables[0];
            ddl_account.DataTextField = "AccountName";
            ddl_account.DataValueField = "AccountID";
            ddl_account.DataBind();
            ddl_Project.DataSource = ds.Tables[1];
            ddl_Project.DataTextField = "ProjectName";
            ddl_Project.DataValueField = "ProjectID";
            ddl_Project.DataBind();
        }
        /// <summary>
        /// ddl_vertical_SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_vertical_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindAccount();
        }
        /// <summary>
        /// showUserMessage
        /// </summary>
        /// <param name="msgType"></param>
        /// <param name="message"></param>
        protected void showUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);            
        }
        /// <summary>
        /// showUserFilterMessage
        /// </summary>
        /// <param name="msgType"></param>
        /// <param name="message"></param>
        protected void showUserFilterMessage(string msgType, string message)
        {            
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);            
        }
        /// <summary>
        /// ReturnToSearch
        /// </summary>
        protected void ReturnToSearch()
        {
            hideMessageControl();
            dvDetailsMain.Visible = false;
            dvSearchFilters.Visible = true;
        }
        /// <summary>
        /// GV_SearchUsrDetails_PageIndexChanging
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GV_SearchUsrDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GV_SearchUsrDetails.PageIndex = e.NewPageIndex;
            if (txt_doj.Text.Trim() != "")
            {
                string selecteddate = txt_doj.Text;
                DateTime objSelecteddate = DateTime.Parse(selecteddate, System.Globalization.CultureInfo.InvariantCulture);
                selecteddate = objSelecteddate.ToString("yyyy-MM-dd");
                GV_SearchUsrDetails.DataSource = GetUsersDetails(selecteddate, Convert.ToInt32(Session["Role"]), Convert.ToString(Session["loggedinUserid"]));
                GV_SearchUsrDetails.DataBind();
                GV_SearchUsrDetails.Visible = true;
            }
        }

        protected void ddl_department_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindVertical();
            BindAccount();
        }
    }
}

