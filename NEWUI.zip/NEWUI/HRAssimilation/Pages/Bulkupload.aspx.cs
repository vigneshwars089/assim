﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Business;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.IO;
using Microsoft.Office.Interop.Excel;
namespace HRAssimilation.Pages
{
    public partial class Bulkupload : System.Web.UI.Page
    {
        BulkUploadBAL BUbal = new BulkUploadBAL();
        string bulkuploadPath = ConfigurationManager.AppSettings["BulkuploadPath"];
        string FinalMISDepartment = ConfigurationManager.AppSettings["FinalMISDepartment"];
        string CTSExperienceinMonths = ConfigurationManager.AppSettings["CTSExperienceinMonths"];
        string GradeCode = ConfigurationManager.AppSettings["GradeCode"];
        string BusinessUnit = ConfigurationManager.AppSettings["BusinessUnit"];
        string Region = ConfigurationManager.AppSettings["Region"];
        string GradeDescription = ConfigurationManager.AppSettings["GradeDescription"];
        string AccountName = ConfigurationManager.AppSettings["AccountName"];
        string EmailTriggerPath = ConfigurationManager.AppSettings["EmailTriggerPath"];
        string Level = ConfigurationManager.AppSettings["Level"];
        string DepartmentDescription = ConfigurationManager.AppSettings["DepartmentDescription"];
        OleDbConnection Econ;
        SqlConnection con;
        string constr, Query, sqlconn;
        Logger.Logger log = new Logger.Logger();
        BulkUploadBAL objUserOp = new BulkUploadBAL();
        #region PageLoad
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["filename"] = null;
            Session["dtresult"] = null;
            if (!Page.IsPostBack)
            {
                try
                {
                    if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                    {
                        Response.Redirect("Login.aspx", true);
                    }
                    else
                    {
                        lblToday.Text = DateTime.Now.ToString("MM/dd/yyyy");
                        Session["RJCHECKED_ITEMS"] = null;
                        BindResignedAndJaAssociates();
                    }
                }
                catch (Exception ex)
                {
                    log.logError("Bulk Upload : " + ex.Message + ex.StackTrace);
                }
            }
            dvUserMessage.Visible = false;

        }
        #endregion

        #region OutputMessageORExcel
        protected void ShowUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }

        protected void GenerateExcel(string filename, System.Data.DataTable dtresult)
        {
            try
            {
                Session["filename"] = filename;
                Session["dtresult"] = dtresult;
                ifr.Src = "GenerateOutput.aspx";
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }
        #endregion

        #region GetExcelRecords
        private void ExcelConn(string FilePath)
        {
            constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", FilePath);
            Econ = new OleDbConnection(constr);
        }
        private System.Data.DataTable GetExcelRecords(string FilePath, string sheet)
        {
            try
            {
                ExcelConn(FilePath);
                switch (ddl_upld.SelectedItem.Text)
                {
                    //New Hire Report
                    case "New hire Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Final MIS Department Grouping] in (" + FinalMISDepartment + ") and [Region] in (" + Region + ") and [Grade Description] in (" + GradeDescription + ") and [Account Name] not in (" + AccountName + ") and Level in (" + Level + ") and [Department Description] not in (" + DepartmentDescription + ")");
                        break;
                    //Head Count Report
                    case "Head Count Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Final MIS Department Grouping] in (" + FinalMISDepartment + ") and [Region] in (" + Region + ") and [Grade Description] in (" + GradeDescription + ") and [Account Name] not in (" + AccountName + ") and Level in (" + Level + ") and [Department Description] not in (" + DepartmentDescription + ")");
                        break;
                    //Attrition Report
                    case "Attrition Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Final MIS Department Grouping] in (" + FinalMISDepartment + ") and [Region] in (" + Region + ") and [Grade Description] in (" + GradeDescription + ") and [Account Name] not in (" + AccountName + ")  and Level in (" + Level + ") and [Department Description] not in (" + DepartmentDescription + ")");
                        break;
                    //Resignation Submission
                    case "Submission Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Business Unit] in (" + BusinessUnit + ") and [Grade] in (" + GradeCode + ")");
                        break;
                    //Job Abandonment
                    case "Job Abandonment Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Business Unit] in (" + BusinessUnit + ") and [Grade] in (" + GradeCode + ")");
                        break;
                    //Resignation Withdrawal
                    case "Withdrawal Feed":
                        Query = string.Format("select * from [" + sheet + "$] where [Business Unit] in (" + BusinessUnit + ") and [Grade] in (" + GradeCode + ")");
                        break;
                    default: log.logInfo("report type not found");
                        break;

                }
                OleDbCommand Ecom = new OleDbCommand(Query, Econ);
                Econ.Open();
                DataSet ds = new DataSet();
                OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
                Econ.Close();
                oda.Fill(ds);
                System.Data.DataTable Exceldt = ds.Tables[0];
                log.logInfo("No. of rows inserted: " + Exceldt.Rows.Count);
                return Exceldt;
            }
            catch (Exception ex)
            {
                log.logError("Reading excel records from uploaded excel" + ex.Message + ex.StackTrace);
                return null;
            }
        }
        #endregion

        #region Validations

        protected System.Data.DataTable ValidateNulls(System.Data.DataTable dtexcel, int colcount)
        {
            try
            {
                for (int i = dtexcel.Columns.Count - 1; i > colcount; i--)
                {
                    dtexcel.Columns.RemoveAt(i);
                }
                dtexcel.AcceptChanges();
                int j;
                for (int i = 0; i < dtexcel.Rows.Count; i++)
                {

                    for (j = 0; j < dtexcel.Columns.Count; j++)
                    {
                        if (!dtexcel.Rows[i].IsNull(j))
                            break;
                    }

                    if (j == dtexcel.Columns.Count)
                    {
                        dtexcel.Rows[i].Delete();
                    }

                }
                dtexcel.AcceptChanges();
                return dtexcel;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }

        protected bool ValidateColumns(System.Data.DataTable dtexcel, string key)
        {
            try
            {
                string[] columnNames = (from dc in dtexcel.Columns.Cast<DataColumn>() select dc.ColumnName).ToArray();
                string[] ActualColumnNames = ConfigurationManager.AppSettings[key].Split(';');
                IStructuralEquatable structuralEquator1 = columnNames;
                bool areEqual = structuralEquator1.Equals(ActualColumnNames, StringComparer.InvariantCultureIgnoreCase);
                return areEqual;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }
        }

        private bool validateSheetName(string sheetName, string filepath)
        {
            try
            {
                ExcelConn(filepath);
                Econ.Open();
                sheetName = "" + sheetName + "$";
                System.Data.DataTable dt = Econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                Econ.Close();
                if (dt == null)
                {
                    return false;
                }
                else
                {
                    String excelSheets;

                    // Add the sheet name to the string array.
                    foreach (DataRow row in dt.Rows)
                    {
                        excelSheets = row["TABLE_NAME"].ToString();
                        if (excelSheets.Contains(sheetName))
                        {
                            return true;
                        }
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }

        }

        #endregion

        #region UploadingExcel
        protected void btn_upload_Click(object sender, EventArgs e)
        {
            dvUserMessage.Visible = false;
            try
            {
                string result = null;
                log.logInfo("Trying to upload file");
                if (ddl_upld.SelectedValue == "0")
                {
                    result = "error;Please select upload type.";
                }
                else
                {
                    if (FileUpload_Bulkupload.HasFile)
                    {
                        string extension = System.IO.Path.GetExtension(FileUpload_Bulkupload.FileName);
                        string sheet = null;
                        string filePath = null;
                        string UserID = Convert.ToString(Session["loggedinuserID"]);
                        System.Data.DataTable dtresult = new System.Data.DataTable();
                        if (extension.ToUpper() == ".XLSX")
                        {
                            string oldfilename = FileUpload_Bulkupload.FileName;
                            string newfilename = DateTime.Now.ToString("ddMMyyyy_hhmmss") + oldfilename;
                            FileUpload_Bulkupload.SaveAs(bulkuploadPath + newfilename);
                            System.Data.DataTable dtexcel = new System.Data.DataTable();
                            FileUpload_Bulkupload = new FileUpload();
                            switch (ddl_upld.SelectedValue)
                            {
                                case "1":
                                    if (oldfilename.ToUpper() == "NEWHIREREPORT.XLSX")
                                    {
                                        sheet = "New Hire Report";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "NewHireColumns"))
                                            {
                                                int colcount = 59;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                DataRow[] dr = dtexcel.Select("[CTS Experience (in Months)] in (0,1,2,3,4,5,6)");
                                                if (dr.Length == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    dtexcel = dr.CopyToDataTable();
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        System.Data.DataTable dtCloned = dtexcel.Clone();
                                                        //change data type of column
                                                        dtCloned.Columns["Account ID"].DataType = typeof(String);
                                                        dtCloned.Columns["Project ID"].DataType = typeof(String);
                                                        //import row to cloned datatable
                                                        foreach (DataRow row in dtexcel.Rows)
                                                        {
                                                            dtCloned.ImportRow(row);
                                                        }

                                                        dtresult = BUbal.NewHireReportUpload(dtCloned, UserID);
                                                        ResetControls();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";
                                    }
                                    break;
                                case "2":
                                    if (oldfilename.ToUpper() == "HEADCOUNTREPORT.XLSX")
                                    {
                                        sheet = "Head Count Report";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "HeadCountColumns"))
                                            {
                                                int colcount = 58;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                DataRow[] dr = dtexcel.Select("[CTS Experience (in Months)] in (0,1,2,3,4,5,6)");
                                                if (dr.Length == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    dtexcel = dr.CopyToDataTable();
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        System.Data.DataTable dtCloned = dtexcel.Clone();
                                                        //change data type of column
                                                        dtCloned.Columns["Account ID"].DataType = typeof(String);
                                                        dtCloned.Columns["Project ID"].DataType = typeof(String);
                                                        //import row to cloned datatable
                                                        foreach (DataRow row in dtexcel.Rows)
                                                        {
                                                            dtCloned.ImportRow(row);
                                                        }
                                                        dtresult = BUbal.HeadCountReport(dtCloned, UserID);
                                                        ResetControls();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";
                                    }
                                    break;
                                case "3":
                                    if (oldfilename.ToUpper() == "ATTRITIONREPORT.XLSX")
                                    {
                                        log.logInfo("Entered into attrition block");
                                        sheet = "Attrition Report";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "AttritionColumns"))
                                            {
                                                log.logInfo("After inserting");
                                                int colcount = 63;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                DataRow[] dr = dtexcel.Select("[CTS Experience (in Months)] in (0,1,2,3,4,5,6)");
                                                if (dr.Length == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    dtexcel = dr.CopyToDataTable();
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        System.Data.DataTable dtCloned = dtexcel.Clone();
                                                        //change data type of column
                                                        dtCloned.Columns["Account ID"].DataType = typeof(String);
                                                        dtCloned.Columns["Project ID"].DataType = typeof(String);
                                                        //import row to cloned datatable
                                                        foreach (DataRow row in dtexcel.Rows)
                                                        {
                                                            dtCloned.ImportRow(row);
                                                        }
                                                        dtresult = BUbal.AttritionReport(dtCloned, UserID);
                                                        ResetControls();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";
                                    }
                                    break;
                                case "4":
                                    if (oldfilename.ToUpper() == "SUBMISSION.XLSX")
                                    {
                                        sheet = "Submission";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "SubmissionColumns"))
                                            {
                                                int colcount = 15;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                if (dtexcel.Rows.Count == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        dtresult = BUbal.ResignationSubmissionReport(dtexcel, UserID);
                                                        ResetControls();
                                                        BindResignedAndJaAssociates();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";
                                    }
                                    break;
                                case "5":
                                    if (oldfilename.ToUpper() == "JOBABANDONMENT.XLSX")
                                    {
                                        sheet = "Job Abandonment";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "JobAbandonmentColumns"))
                                            {
                                                int colcount = 14;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                if (dtexcel.Rows.Count == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        dtresult = BUbal.JobAbandonment(dtexcel, UserID);
                                                        ResetControls();
                                                        BindResignedAndJaAssociates();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";
                                    }
                                    break;
                                case "6":
                                    if (oldfilename.ToUpper() == "WITHDRAWAL.XLSX")
                                    {
                                        sheet = "Withdrawal";
                                        filePath = bulkuploadPath + newfilename;
                                        dtexcel = GetExcelRecords(filePath, sheet);
                                        if (validateSheetName(sheet, filePath) == false)
                                        {
                                            result = "error;Invalid Sheet Name, please use valid template";
                                        }
                                        else
                                        {
                                            if (ValidateColumns(dtexcel, "WithdrawalColumns"))
                                            {
                                                int colcount = 14;
                                                dtexcel = ValidateNulls(dtexcel, colcount);
                                                if (dtexcel.Rows.Count == 0)
                                                {
                                                    result = "warning;No records for the required selection criteria";
                                                }
                                                else
                                                {
                                                    if (dtexcel.Rows.Count > 300)
                                                    {
                                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                                    }
                                                    else
                                                    {
                                                        dtresult = BUbal.ResignationWithdrawal(dtexcel, UserID);
                                                        ResetControls();
                                                        GenerateExcel(oldfilename.Split('.')[0], dtresult);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                result = "error;Invalid Column Names, please use valid template";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result = "error;Please upload valid file.";

                                    }
                                    break;
                                default: log.logInfo("report type not found");
                                    break;
                            }
                        }
                        else
                        {
                            result = "error;Sorry. Only Files with extension '.xlsx' are allowed.";

                        }
                    }
                    else
                    {
                        result = "error;Please browse and select file to upload.";
                    }
                }

                if (!string.IsNullOrEmpty(result) && result.Contains(';'))
                {
                    string msgtype = result.Split(';')[0];
                    string message = result.Split(';')[1];
                    ShowUserMessage(msgtype, message);
                    if (msgtype == "success")
                    {
                        ResetControls();
                        lblToday.Text = DateTime.Now.ToString("MM/dd/yyyy");
                        Session["RJCHECKED_ITEMS"] = null;
                        BindResignedAndJaAssociates();
                    }
                }

            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            finally
            {

            }

        }
        #endregion

        #region ReportSelectionANDReset
        protected void ddl_upld_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_upld.SelectedValue != "0")
            {
                lnk_template.Visible = true;
                switch (ddl_upld.SelectedValue)
                {
                    case "1": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\NewHireReport.xlsx";
                        break;
                    case "2": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\HeadCountReport.xlsx";
                        break;
                    case "3": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\AttritionReport.xlsx";
                        break;
                    case "4": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\Submission.xlsx";
                        break;
                    case "5": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\JobAbandonment.xlsx";
                        break;
                    case "6": lnk_template.NavigateUrl = "..\\BulkuploadTemplates\\Withdrawal.xlsx";
                        break;
                    default: log.logInfo("report type not found");
                        break;
                }

            }
            else
            {
                lnk_template.NavigateUrl = "";
                lnk_template.Visible = false;
            }
        }

        protected void ResetControls()
        {
            ddl_upld.SelectedValue = "0";
            FileUpload_Bulkupload.Attributes.Clear();
            lnk_template.NavigateUrl = "";
            lnk_template.Visible = false;
            dvUserMessage.Visible = false;
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            ddl_upld.SelectedValue = "0";
            dvUserMessage.Visible = false;
            lnk_template.NavigateUrl = "";
            lnk_template.Visible = false;
        }
        #endregion
        protected void gv_ResignedAndJAAssociates_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SaveCheckedValues();
            gv_ResignedAndJAAssociates.PageIndex = e.NewPageIndex;
            gv_ResignedAndJAAssociates.DataSource = ViewState["ResignedAndJaAssociates"] as System.Data.DataTable;
            gv_ResignedAndJAAssociates.DataBind();
            PopulateCheckedValues();
        }
        protected void BindResignedAndJaAssociates()
        {
            string sloginid = Session["loggedinUserid"].ToString();           
            System.Data.DataTable dt = objUserOp.GetResignationJADetails();
            if (dt != null && dt.Rows.Count > 0)
            {

                ViewState["ResignedAndJaAssociates"] = dt;
                gv_ResignedAndJAAssociates.DataSource = dt;
                gv_ResignedAndJAAssociates.DataBind();
                trSendMail.Visible = true;
                trNoData.Visible = false;
            }
            else
            {
                trSendMail.Visible = false;
                trNoData.Visible = true;
            }
        }
        private void PopulateCheckedValues()
        {
            ArrayList userdetails = (ArrayList)Session["RJCHECKED_ITEMS"];
            if (userdetails != null && userdetails.Count > 0)
            {
                foreach (GridViewRow gvrow in gv_ResignedAndJAAssociates.Rows)
                {
                    int index = gv_ResignedAndJAAssociates.PageSize * gv_ResignedAndJAAssociates.PageIndex + (gvrow.RowIndex + 1);
                    if (userdetails.Contains(index))
                    {
                        System.Web.UI.WebControls.CheckBox myCheckBox = (System.Web.UI.WebControls.CheckBox)gvrow.FindControl("chkAssociate");
                        myCheckBox.Checked = true;
                    }
                }
            }
        }
        private void SaveCheckedValues()
        {
            ArrayList userdetails = new ArrayList();
            int index = -1;
            foreach (GridViewRow gvrow in gv_ResignedAndJAAssociates.Rows)
            {
                index = gv_ResignedAndJAAssociates.PageSize * gv_ResignedAndJAAssociates.PageIndex + (gvrow.RowIndex + 1);
                bool result = ((System.Web.UI.WebControls.CheckBox)gvrow.FindControl("chkAssociate")).Checked;

                // Check in the Session
                if (Session["RJCHECKED_ITEMS"] != null)
                    userdetails = (ArrayList)Session["RJCHECKED_ITEMS"];
                if (result)
                {
                    if (!userdetails.Contains(index))
                        userdetails.Add(index);
                }
                else
                    userdetails.Remove(index);
            }
            if (userdetails != null && userdetails.Count > 0)
                Session["RJCHECKED_ITEMS"] = userdetails;
        }
        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.CheckBox ChkBoxHeader = (System.Web.UI.WebControls.CheckBox)gv_ResignedAndJAAssociates.HeaderRow.FindControl("chkboxSelectAll");
            if (ChkBoxHeader.Checked)
            {

            }
        }
        protected void imgSendMail_Click(object sender, ImageClickEventArgs e)
        {
            if (SendMail())
            {
                Session["RJCHECKED_ITEMS"] = null;
                BindResignedAndJaAssociates();
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + "Mail notification sent successfully." + "', 'information');", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + "Sorry, Unable to send mail. Please try after some time or reach out to Admin." + "', 'information');", true);
            }
        }
        protected bool SendMail()
        {
            try
            {
                List<String> selectedUsers = GetSelectedUsersList();
                StringBuilder ids = new StringBuilder();
                if (selectedUsers.Count > 0)
                {
                    foreach (string s in selectedUsers)
                    {
                        ids.Append(s);
                        ids.Append(",");
                    }
                    System.Data.DataTable dt = (System.Data.DataTable)ViewState["ResignedAndJaAssociates"];
                    //string query = "[" + "Associate ID" + "]" + " in (" + ids.ToString() + ")";
                    //dt = dt.Select(query).CopyToDataTable();
                    dt = objUserOp.GetResignationJADetailsForMail(ids.ToString());
                    //GeneratExcelFile(dt);
                    //string filePath = EmailTriggerPath+"ResignedAndJaReport_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";
                    //GeneratExcelFile(dt, filePath);
                    //if (!Convert.ToBoolean(ConfigurationManager.AppSettings["USE_INTEROP"]))
                    //{
                    //    // Method to generate excel file using oledb
                       
                    //    ExportToXLSX(filePath, dt, "ResignedAndJaAssociates");
                    //}
                    //else
                    //{
                    //    // Method to generate excel file using interop
                    //   ExportToExcelWithInterop(dt, filePath);
                    //}                   
                    string shtml = getHTML(dt);
                    MailMessage mail = new MailMessage();
                    SmtpClient SmtpServer = new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"]);
                    mail.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"]);
                    mail.To.Add(ConfigurationManager.AppSettings["MailTo"]);
                    mail.Subject = "Resignation & JA uploaded on " + DateTime.Now.ToString("MM/dd/yyyy");
                    mail.IsBodyHtml = true;                    
                    mail.Body = shtml;
                    //System.Net.Mail.Attachment attachment;
                    //attachment = new System.Net.Mail.Attachment(filePath);
                    //mail.Attachments.Add(attachment);
                    SmtpServer.Port = 25;
                    SmtpServer.Send(mail);
                }
                else
                {                    
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + "Please select atleast one associate to send mail." + "', 'information');", true);
                }
                return true;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }
        }
        
        private string getHTML(System.Data.DataTable dt)
        {
            StringBuilder myBuilder = new StringBuilder();
            myBuilder.Append("Hi All,");
            myBuilder.Append("<br>"); 
            myBuilder.Append("<br>");
            myBuilder.Append("Please find below Resignation & JA Details.");
            myBuilder.Append("<br>");
            myBuilder.Append("<br>");
            myBuilder.Append("<table border='1px' cellpadding='5' cellspacing='0' ");
            myBuilder.Append("style='border: solid 1px Silver; font-size: x-small;'>");
            myBuilder.Append("<tr align='left' valign='top' bgcolor='#87CEFA' style='font-weight:bold'>");
            foreach (DataColumn myColumn in dt.Columns)
            {
                myBuilder.Append("<td width='200' align='left' valign='top' style='border: 1px solid black;border-left: solid 1px #e9e9e9'>");
                myBuilder.Append(myColumn.ColumnName);
                myBuilder.Append("</td>");
            }
            myBuilder.Append("</tr>");
            foreach (DataRow myRow in dt.Rows)
            {
                int index = dt.Rows.IndexOf(myRow);
                int i = index;
                myBuilder.Append("<tr align='left' valign='top'>");
                foreach (DataColumn myColumn in dt.Columns)
                {
                    if (myColumn.ToString() == "Latest EWS")
                    {
                        int j = 4;
                            {
                                if (dt.Rows[i]["Latest EWS"].ToString() == "Red")
                                {
                                    myBuilder.Append("<td align='left' valign='top'  bgcolor='Red' style='border: 1px solid black;border-left: solid 1px #e9e9e9'>");
                                    myBuilder.Append(myRow[myColumn.ColumnName].ToString());
                                    myBuilder.Append("</td>");
                                }
                                else if (dt.Rows[i]["Latest EWS"].ToString() == "Green")
                                {
                                    myBuilder.Append("<td align='left' valign='top'  bgcolor='Green' style='border: 1px solid black;border-left: solid 1px #e9e9e9' >");
                                    myBuilder.Append(myRow[myColumn.ColumnName].ToString());
                                    myBuilder.Append("</td>");
                                }
                                else if (dt.Rows[i]["Latest EWS"].ToString() == "Amber")
                                {
                                    myBuilder.Append("<td align='left' valign='top'  bgcolor='orange' style='border: 1px solid black;border-left: solid 1px #e9e9e9' >");
                                    myBuilder.Append(myRow[myColumn.ColumnName].ToString());
                                    myBuilder.Append("</td>");
                                }
                                else
                                {
                                    myBuilder.Append("<td align='left' valign='top' style='border: 1px solid black;border-left: solid 1px #e9e9e9' >");
                                    myBuilder.Append("No EWS");
                                    myBuilder.Append("</td>");
                                }
                            }
                        }
                    else
                    {
                        myBuilder.Append("<td align='left' valign='top' style='border: 1px solid black;border-left: solid 1px #e9e9e9' >");
                        myBuilder.Append(myRow[myColumn.ColumnName].ToString());
                        myBuilder.Append("</td>");
                    }
                }
                myBuilder.Append("</tr>");
            }
            myBuilder.Append("</table>");
            myBuilder.Append("<br>");
            myBuilder.Append("Regards,");
            myBuilder.Append("<br>");
            myBuilder.Append("DO Assimilation Team.");
            return myBuilder.ToString();
        }
        public List<String> GetSelectedUsersList()
        {
            List<String> selectedUsers = new List<String>();
            string selectedUserID = "";
            string selUserName = "";            

            int a = gv_ResignedAndJAAssociates.PageIndex;
            //Loop through All Pages
            for (int i = 0; i < gv_ResignedAndJAAssociates.PageCount; i++)
            {
                //Set Page Index
                gv_ResignedAndJAAssociates.SetPageIndex(i);
                //After Setting Page Index Loop through its Rows
                for (int j = 0; j < gv_ResignedAndJAAssociates.Rows.Count; j++) //Check if item is selected  
                {
                    if (((System.Web.UI.WebControls.CheckBox)gv_ResignedAndJAAssociates.Rows[j].FindControl("chkAssociate")).Checked) //If selected            
                    {
                        selectedUserID = gv_ResignedAndJAAssociates.Rows[j].Cells[1].Text.ToString() +";"+ gv_ResignedAndJAAssociates.Rows[j].Cells[3].Text.ToString();
                        selUserName = gv_ResignedAndJAAssociates.Rows[j].Cells[2].Text.ToString();
                        selectedUsers.Add(selectedUserID);
                    }
                }
            }
            gv_ResignedAndJAAssociates.SetPageIndex(a);
            return selectedUsers;
        }
        public void ExportToExcelWithInterop(System.Data.DataTable dt,string filePath)
        {


            Microsoft.Office.Interop.Excel.Application Excel;
            Microsoft.Office.Interop.Excel.Workbook workbook;
            Microsoft.Office.Interop.Excel.Worksheet worksheet;
            Microsoft.Office.Interop.Excel.Range cellrange;

            try
            {
                Excel = new Microsoft.Office.Interop.Excel.Application();
                Excel.Visible = false;
                Excel.DisplayAlerts = false;
                workbook = Excel.Workbooks.Add(Type.Missing);
                worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;
                worksheet.Name = "Resigned And JA Report";
                //worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 8]].Merge();
               
                worksheet.Cells.Font.Size = 12;
                int rowcount = 1;
                foreach (DataRow datarow in dt.Rows)
                {
                    rowcount += 1;
                    for (int i = 1; i <= dt.Columns.Count; i++)
                    {
                        if (rowcount == 2)
                        {
                            worksheet.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                            worksheet.Cells.Font.Color = System.Drawing.Color.Black;

                        }
                        worksheet.Cells[rowcount, i] = datarow[i - 1].ToString();
                        if (rowcount > 3)
                        {
                            if (i == dt.Columns.Count)
                            {
                                if (rowcount % 2 == 0)
                                {
                                    cellrange = worksheet.Range[worksheet.Cells[rowcount, 1], worksheet.Cells[rowcount, dt.Columns.Count]];
                                }
                            }
                        }
                    }
                }
                cellrange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[rowcount, dt.Columns.Count]];
                cellrange.EntireColumn.AutoFit();
                Microsoft.Office.Interop.Excel.Borders border = cellrange.Borders;
                border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                border.Weight = 2d;
                cellrange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[2, dt.Columns.Count]];
                workbook.SaveAs(filePath);
                workbook.Close();
                Excel.Quit();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + ex.StackTrace + ex.Message + "', 'information');", true);
                log.logError(ex.StackTrace + ex.Message);                
            }
            finally
            {
                worksheet = null;
                cellrange = null;
                workbook = null;

            }

        }
       
        public void ExportToXLSX(string sheetToCreate, System.Data.DataTable dtToExport, string tableName)
        {
            List<DataRow> rows = new List<DataRow>();
            foreach (DataRow row in dtToExport.Rows) rows.Add(row);
            ExportToXLSX(sheetToCreate, rows, dtToExport, tableName);
        }
        public void ExportToXLSX(string sheetToCreate, List<DataRow> selectedRows, System.Data.DataTable origDataTable, string tableName)
        {
            char Space = ' ';
            string dest = sheetToCreate;


            if (File.Exists(dest))
            {
                File.Delete(dest);
            }

            sheetToCreate = dest;

            if (tableName == null)
            {
                tableName = string.Empty;
            }

            tableName = tableName.Trim().Replace(Space, '_');
            if (tableName.Length == 0)
            {
                tableName = origDataTable.TableName.Replace(Space, '_');
            }

            if (tableName.Length == 0)
            {
                tableName = "NoTableName";
            }

            if (tableName.Length > 30)
            {
                tableName = tableName.Substring(0, 30);
            }

            //Excel names are less than 31 chars
            string queryCreateExcelTable = "CREATE TABLE [" + tableName + "] (";
            Dictionary<string, string> colNames = new Dictionary<string, string>();

            foreach (DataColumn dc in origDataTable.Columns)
            {
                //Cause the query to name each of the columns to be created.
                string modifiedcolName = dc.ColumnName;//.Replace(Space, '_').Replace('.', '#');
                string origColName = dc.ColumnName;
                colNames.Add(modifiedcolName, origColName);
                queryCreateExcelTable += "[" + modifiedcolName + "]" + " text,";
            }

            queryCreateExcelTable = queryCreateExcelTable.TrimEnd(new char[] { Convert.ToChar(",") }) + ")";

            //adds the closing parentheses to the query string
            if (selectedRows.Count > 65000 && sheetToCreate.ToLower().EndsWith(".xls"))
            {
                //use Excel 2007 for large sheets.
                sheetToCreate = sheetToCreate.ToLower().Replace(".xls", string.Empty) + ".xlsx";
            }

            string strCn = string.Empty;
            string ext = System.IO.Path.GetExtension(sheetToCreate).ToLower();
            if (ext == ".xls") strCn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sheetToCreate + "; Extended Properties='Excel 8.0;HDR=YES'";
            if (ext == ".xlsx") strCn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sheetToCreate + ";Extended Properties='Excel 12.0 Xml;HDR=YES' ";
            if (ext == ".xlsb") strCn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sheetToCreate + ";Extended Properties='Excel 12.0;HDR=YES' ";
            if (ext == ".xlsm") strCn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sheetToCreate + ";Extended Properties='Excel 12.0 Macro;HDR=YES' ";

            System.Data.OleDb.OleDbConnection cn = new System.Data.OleDb.OleDbConnection(strCn);
            System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand(queryCreateExcelTable, cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter("SELECT * FROM [" + tableName + "]", cn);
            System.Data.OleDb.OleDbCommandBuilder cb = new System.Data.OleDb.OleDbCommandBuilder(da);

            //creates the INSERT INTO command
            cb.QuotePrefix = "[";
            cb.QuoteSuffix = "]";
            cmd = cb.GetInsertCommand();

            //gets a hold of the INSERT INTO command.
            foreach (DataRow row in selectedRows)
            {
                foreach (System.Data.OleDb.OleDbParameter param in cmd.Parameters)
                {
                    param.Value = row[colNames[param.SourceColumn.Replace('#', '.')]];
                }

                cmd.ExecuteNonQuery(); //INSERT INTO command.
            }
            cn.Close();
            cn.Dispose();
            da.Dispose();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }       
    }
}