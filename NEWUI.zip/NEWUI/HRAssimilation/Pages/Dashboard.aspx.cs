﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using HRAssimilation.Business;
using System.Web.Services;
namespace HRAssimilation.Pages
{
    public partial class Dashboard : System.Web.UI.Page
    {
        UserOperationsBAL objUop = new UserOperationsBAL();
        Logger.Logger log = new Logger.Logger();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ValidateUserSession();
                if (Session["loggedinUserName"] != null && Session["roleName"] != null)
                {
                    dvDashboardMessage.InnerHtml = "<br/><h3>Welcome " + Session["loggedinUserName"].ToString() + ". You are logged in with role '" + Convert.ToString(Session["roleName"]) + "'</h3>";
                    DataSet ds = GetDashboardDetails(Convert.ToString(Session["loggedinUserid"]), Convert.ToString(Session["role"]));
                    if (null != ds && ds.Tables.Count > 0)
                    {
                        GetChartsData();
                        bindCurrentAssociateStatus();
                        bindMonthOnMonthYTD();
                    }

                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        //This method binds the current status of the associates.

        public void bindCurrentAssociateStatus()
        {
            try
            {
                DataSet ds = GetDashboardDetails(Convert.ToString(Session["loggedinUserid"]), Convert.ToString(Session["role"]));
                DataTable dt = ds.Tables[0];
                DataTable dt2 = new DataTable();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt2.Columns.Add(dt.Rows[i][0].ToString());
                }
                for (int i = 1; i < dt.Columns.Count; i++)
                {
                    dt2.Rows.Add();
                }
                for (int i = 0; i < dt.Columns.Count - 1; i++)
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        dt2.Rows[i][j] = dt.Rows[j][i + 1];
                    }
                }
                gv_CurrentAssociateStatus.DataSource = dt;
                gv_CurrentAssociateStatus.DataBind();                
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        public void bindMonthOnMonthYTD()
        {
            try
            {
                DataSet ds = ((DataSet)HttpContext.Current.Session["ChartsData"]);
                DataTable dtTranspose = TransposeData(ds.Tables[3]);
                gv_MonthOnMonthYTD.DataSource = dtTranspose;
                gv_MonthOnMonthYTD.DataBind();
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        public DataTable TransposeData(DataTable dt)
        {
            try
            {
                DataTable dt2 = new DataTable();
                dt2.Columns.Add("Month");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt2.Columns.Add(dt.Rows[i][0].ToString());
                }

                DataRow ytd = dt2.NewRow();
                ytd[0] = "YTD(%)";

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    ytd[i + 1] = Convert.ToDouble(dt.Rows[i][4]) > 0 ? dt.Rows[i][4] : "";
                }
                dt2.Rows.Add(ytd);

                DataRow me = dt2.NewRow();
                me[0] = "Monthly Exits";

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    me[i + 1] = Convert.ToInt32(dt.Rows[i][1]) > 0 ? dt.Rows[i][1] : "";
                }
                dt2.Rows.Add(me);

                DataRow ohc = dt2.NewRow();
                ohc[0] = "Opening Head Count";

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ohc[i + 1] = Convert.ToInt32(dt.Rows[i][2]) > 0 ? dt.Rows[i][2] : "";
                }
                dt2.Rows.Add(ohc);

                DataRow chc = dt2.NewRow();
                chc[0] = "Closing Head Count";

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    chc[i + 1] = Convert.ToInt32(dt.Rows[i][3]) > 0 ? dt.Rows[i][3] : "";
                }
                dt2.Rows.Add(chc);

                return dt2;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        public DataSet GetDashboardDetails(string userid, string roleid)
        {
            DataSet dsDashboard = new DataSet();
            try
            {
                dsDashboard = objUop.GetDashboardDetails(userid, roleid);
                return dsDashboard;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        public void ValidateUserSession()
        {
            try
            {
                if (Session["loggedinUserid"] == null)
                {
                    Response.Redirect("Login.aspx", true);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        public void GetChartsData()
        {
            DataSet dsDashboardChartsData = new DataSet();
            try
            {
                dsDashboardChartsData = objUop.GetDashboardChartsData();
                Session["ChartsData"] = dsDashboardChartsData;

                DataTable dtV = dsDashboardChartsData.Tables[0];
                var maxVerticalYTDValue = dtV.AsEnumerable().Max(row => row["YTD Attrition %"]);
                hdnVMAX.Value = maxVerticalYTDValue.ToString();

                DataTable dtL = dsDashboardChartsData.Tables[1];
                var maxLocationYTDValue = dtL.AsEnumerable().Max(row => row["YTD Attrition %"]);
                hdnLMAX.Value = maxLocationYTDValue.ToString();

                DataTable dtR = dsDashboardChartsData.Tables[2];
                var maxReasonYTDValue = dtR.AsEnumerable().Max(row => row["Attrition Count"]);
                hdnRMAX.Value = maxReasonYTDValue.ToString();

                DataTable dt = dsDashboardChartsData.Tables[2];
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        //This method shows the Attrition results based on the Vertical.
        [WebMethod]
        public static List<YTDAttritionVerticalWise> getYTDAttritionVerticalWiseData()
        {
            List<YTDAttritionVerticalWise> data = new List<YTDAttritionVerticalWise>();
            // Get data from DB and construct data as below            


            List<VYTDPlot> previousYear = new List<VYTDPlot>();
            List<VYTDPlot> currentYear = new List<VYTDPlot>();
            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)HttpContext.Current.Session["ChartsData"]);

            DataTable dtV = dsFilter.Tables[0];

            var prvYear = dtV.AsEnumerable().Min(row => row["Year"]);
            var currYear = dtV.AsEnumerable().Max(row => row["Year"]);

            DataTable dt = new DataTable();
            dt.Columns.Add("Vertical");
            dt.Columns.Add("Total Exits - " + prvYear.ToString());
            dt.Columns.Add("Total Exits - " + currYear.ToString());

            DataView viw = new DataView(dtV);
            DataTable distinctVerticals = viw.ToTable(true, "Vertical");
            DataRow drP = null;
            DataRow drC = null;
            DataRow drN = null;
            DataView dvF = new DataView(dtV);
            foreach (DataRow drv in distinctVerticals.Rows)
            {
                dvF.RowFilter = "Vertical = '" + drv["Vertical"].ToString() + "' AND Year = '" + prvYear.ToString() + "'";
                drP = dvF.ToTable().Rows[0];
                dvF = viw;
                dvF.RowFilter = "Vertical = '" + drv["Vertical"].ToString() + "' AND Year = '" + currYear.ToString() + "'";
                drC = dvF.ToTable().Rows[0];
                drN = dt.NewRow();
                drN["Vertical"] = drv["Vertical"];
                drN[1] = drP["YTD Attrition %"];
                drN[2] = drC["YTD Attrition %"];
                dt.Rows.Add(drN);
                dvF = viw;
            }

            foreach (DataRow dr in dt.Rows)
            {
                currentYear.Add(new VYTDPlot
                {
                    x = dr["Vertical"].ToString(),
                    y = Convert.ToDouble(dr[2].ToString())
                });

                previousYear.Add(new VYTDPlot
                {
                    x = dr["Vertical"].ToString(),
                    y = Convert.ToDouble(dr[1].ToString())
                });
            }

            data.Add(new YTDAttritionVerticalWise
            {
                key = dt.Columns[1].ToString(),
                values = previousYear
            }
            );

            data.Add(new YTDAttritionVerticalWise
            {
                key = dt.Columns[2].ToString(),
                values = currentYear
            }
           );

            return data;
        }
        //This method shows the Attrition results based on the Location.
        [WebMethod]
        public static List<YTDAttritionLocationWise> getYTDAttritionLocationWiseData()
        {
            List<YTDAttritionLocationWise> data = new List<YTDAttritionLocationWise>();

            // Get data from DB and construct data as below


            List<LYTDPlot> previousYear = new List<LYTDPlot>();
            List<LYTDPlot> currentYear = new List<LYTDPlot>();

            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)HttpContext.Current.Session["ChartsData"]);
            //DataTable dt = dsFilter.Tables[1];
            DataTable dtV = dsFilter.Tables[1];

            var prvYear = dtV.AsEnumerable().Min(row => row["Year"]);
            var currYear = dtV.AsEnumerable().Max(row => row["Year"]);


            DataTable dt = new DataTable();
            dt.Columns.Add("Location");
            dt.Columns.Add("Total Exits - " + prvYear.ToString());
            dt.Columns.Add("Total Exits - " + currYear.ToString());

            DataView viw = new DataView(dtV);
            DataTable distinctLocations = viw.ToTable(true, "Location");
            DataRow drP = null;
            DataRow drC = null;
            DataRow drN = null;
            DataView dvF = new DataView(dtV);
            foreach (DataRow drv in distinctLocations.Rows)
            {


                dvF.RowFilter = "Location = '" + drv["Location"].ToString() + "' AND Year = '" + prvYear.ToString() + "'";
                drP = dvF.ToTable().Rows[0];
                dvF = viw;
                dvF.RowFilter = "Location = '" + drv["Location"].ToString() + "' AND Year = '" + currYear.ToString() + "'";
                drC = dvF.ToTable().Rows[0];
                drN = dt.NewRow();
                drN["Location"] = drv["Location"];
                drN[1] = drP["YTD Attrition %"];
                drN[2] = drC["YTD Attrition %"];

                dt.Rows.Add(drN);
                dvF = viw;

                //drP = dtV.Select("Location = '" + drv["Location"].ToString() + "' AND Year = '" + prvYear.ToString() + "'");
                //drC = dtV.Select("Location = '" + drv["Location"].ToString() + "' AND Year = '" + currYear.ToString() + "'");
                //drN = dt.NewRow();
                //drN["Location"] = drv["Location"];
                //drN[1] = drP[0]["YTD Attrition %"];
                //drN[2] = drC[0]["YTD Attrition %"];

                //dt.Rows.Add(drN);
            }
            foreach (DataRow dr in dt.Rows)
            {
                currentYear.Add(new LYTDPlot
                {
                    x = dr["Location"].ToString(),
                    y = Convert.ToDouble(dr[2].ToString())
                });

                previousYear.Add(new LYTDPlot
                {
                    x = dr["Location"].ToString(),
                    y = Convert.ToDouble(dr[1].ToString())
                });
            }

            data.Add(new YTDAttritionLocationWise
            {
                key = dt.Columns[1].ToString(),
                values = previousYear
            }
            );

            data.Add(new YTDAttritionLocationWise
            {
                key = dt.Columns[2].ToString(),
                values = currentYear
            }
           );

            return data;
        }
        //This method shows the Attrition results based on the Reason of Attrition .
        [WebMethod]
        public static List<YTDAttritionReasonWise> getYTDAttritionReasonWiseData()
        {
            List<YTDAttritionReasonWise> data = new List<YTDAttritionReasonWise>();

            // Get data from DB and construct data as below             

            List<RYTDPlot> currentYear = new List<RYTDPlot>();
            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)HttpContext.Current.Session["ChartsData"]);

            DataTable dt = dsFilter.Tables[2];
            foreach (DataRow dr in dt.Rows)
            {
                currentYear.Add(new RYTDPlot
                {
                    x = dr["Reason"].ToString(),
                    y = Convert.ToDouble(dr[1].ToString())
                });

            }

            data.Add(new YTDAttritionReasonWise
            {
                key = dt.Columns[1].ToString(),
                values = currentYear
            }
            );

            return data;
        }
//This method shows Attrition calculation based on month on month.
        protected void gv_MonthOnMonthYTD_DataBound(object sender, EventArgs e)
        {
            int i = 2;
            GridViewRow row = gv_MonthOnMonthYTD.Rows[i];
            row.Cells[1].ColumnSpan = 12;
            for (int j = 2; j <= 12; j++)
                row.Cells[j].Visible = false;

        }
    }
    public class YTDAttritionVerticalWise
    {
        public string key { get; set; }
        public List<VYTDPlot> values = new List<VYTDPlot>();
    }
    public class VYTDPlot
    {
        public string x { get; set; }
        public double y { get; set; }
    }
    public class YTDAttritionLocationWise
    {
        public string key { get; set; }
        public List<LYTDPlot> values = new List<LYTDPlot>();
    }
    public class LYTDPlot
    {
        public string x { get; set; }
        public double y { get; set; }
    }
    public class YTDAttritionReasonWise
    {
        public string key { get; set; }
        public List<RYTDPlot> values = new List<RYTDPlot>();
    }
    public class RYTDPlot
    {
        public string x { get; set; }
        public double y { get; set; }
        
    }
}