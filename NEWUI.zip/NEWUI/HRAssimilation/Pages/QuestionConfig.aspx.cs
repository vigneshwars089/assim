﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Entity;
using HRAssimilation.Business;
using System.Data;

namespace HRAssimilation.Pages
{
    public partial class QuestionConfig : System.Web.UI.Page
    {
        MasterSettingConfigBAL MasterConfigBAL = new MasterSettingConfigBAL();
        Question QuestDetails = new Question();
        Logger.Logger log = new Logger.Logger();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                    {
                        Response.Redirect("Login.aspx", true);
                    }
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                }

                gv_Questionsbind();
            }            
        }
        protected bool checkForVunerableChars(string value)
        {
            if(value.Contains('<')||value.Contains('>'))
                return true;
            else
                return false;
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            string result;
            try
            {
                int num;
                if (!string.IsNullOrEmpty(txt_question.Text))
                {
                    if (checkForVunerableChars(txt_question.Text))
                    {
                        Response.Redirect("~/ErrorPages/Oops.aspx", true);
                    }
                    if (int.TryParse(txt_weightage.Text, out num))
                    {
                        if (Convert.ToInt32(txt_weightage.Text) <= 100 && Convert.ToInt32(txt_weightage.Text) > 0)
                        {
                            QuestDetails.Weightage = txt_weightage.Text;
                            QuestDetails.CreatedBy = Convert.ToString(Session["loggedinuserID"]);
                            QuestDetails.QuestionDescription = txt_question.Text;
                            result = MasterConfigBAL.InsertQuestion(QuestDetails);
                        }
                        else
                        {
                            result = "error;Weightage value must be between 1-100";
                        }
                    }
                    else
                    {
                        result = "error; Provide Weightage to Add Question";
                    }
                }
                else
                {
                    result = "error;Question should not be empty";
                }

                if (result.Contains(';'))
                {
                    showUserMessage(result.Split(';')[0], result.Split(';')[1]);
                    if (result.Split(';')[0] == "success")
                    {
                        txt_question.Text = "";
                        txt_weightage.Text = "";
                    }
                }                
                gv_Questionsbind();
            }           
            catch (Exception ex)
            {
                log.logError(ex.Message);             
            }
        }

        public void gv_Questionsbind()
        {
            try
            {
                DataSet ds = new DataSet();
                ds = MasterConfigBAL.GetMasterQuestions();
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    gv_Questions.DataSource = ds.Tables[0];
                    gv_Questions.DataBind();
                    btn_publish.Visible = true;
                    gv_Questions.Visible = true;
                }
                else
                {
                    btn_publish.Visible = false;
                    gv_Questions.Visible = false;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        protected void gv_Questions_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_Questions.PageIndex = e.NewPageIndex;
            gv_Questionsbind();
        }

        protected void gv_Questions_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string result = string.Empty;
            GridViewRow GVR = gv_Questions.Rows[e.RowIndex];
            Label lbl_QuestID = (Label)GVR.FindControl("lbl_QuestionID");
            QuestDetails.QuestionID = lbl_QuestID.Text;
            QuestDetails.CreatedBy = Convert.ToString(Session["loggedinuserID"]);
            result = MasterConfigBAL.DeleteQuestion(QuestDetails);
            if (result.Contains(';'))
            {
                showUserMessage(result.Split(';')[0], result.Split(';')[1]);
            }
            gv_Questionsbind();
        }

        protected void btn_publish_Click(object sender, EventArgs e)
        {
            string result = null;
            try
            {
                DataTable dtDraft = new DataTable();
                dtDraft.Columns.Add("Qid");
                dtDraft.Columns.Add("Description");
                dtDraft.Columns.Add("Weightage");
                if (gv_Questions.Rows.Count == 10)
                {
                    foreach (GridViewRow row in gv_Questions.Rows)
                    {
                        DataRow dr = dtDraft.NewRow();
                        dr["Qid"] = ((Label)row.FindControl("lbl_QuestionID")).Text;
                        dr["Description"] = ((Label)row.FindControl("lbl_question")).Text;
                        dr["Weightage"] = ((TextBox)row.FindControl("txt_weightage")).Text;
                        dtDraft.Rows.Add(dr);
                    }
                    QuestDetails.CreatedBy = Convert.ToString(Session["loggedinuserID"]);
                    result = MasterConfigBAL.ManageQuestionConfig(dtDraft, QuestDetails.CreatedBy);
                    if (result.Contains(';'))
                    {
                        showUserMessage(result.Split(';')[0], result.Split(';')[1]);
                    }
                }
                else
                {
                    showUserMessage("warning", "Sorry, Total number of questions must be equal to 10. Current count is " + gv_Questions.Rows.Count + "");
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void showUserMessage(string msgType, string message)
        {
           ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);           
        }
    }
}