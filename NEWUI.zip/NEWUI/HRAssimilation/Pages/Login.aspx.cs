﻿using System;
using HRAssimilation.Entity;
using HRAssimilation.Business;
using System.Data;
using System.Configuration;

namespace HRAssimilation.Pages
{
    public partial class Login : System.Web.UI.Page
    {
        UserDetails usrlogin = new UserDetails();
        Logger.Logger log = new Logger.Logger();
        UserConfigurationBAL objUserConfig = new UserConfigurationBAL();
        AuthenticateUserBAL objAuthneciateusr = new AuthenticateUserBAL();


        protected void Page_Load(object sender, EventArgs e)
        {
            hideMessageControl();
            if (Request.QueryString["Timeout"] != null && Request.QueryString["Timeout"] == "yes")
            {
                dvUserMessage.Visible = true;
                dvUserMessage.Attributes["class"] = "alert-box error";
                dvUserMessage.InnerHtml = "Session Timed Out. Please login again to continue.";
            }
            //if (null != Session["loggedinUserid"] && Session["loggedinUserid"].ToString()!="")
            if (!string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                Response.Redirect("Dashboard.aspx", false);
        }
        protected void showUserMessage(string msgType, string message)
        {
            switch (msgType)
            {
                case "error":
                    dvUserMessage.Visible = true;
                    dvUserMessage.Attributes["class"] = "alert-box error";
                    dvUserMessage.InnerHtml = message;
                    break;
                case "success":
                    dvUserMessage.Visible = true;
                    dvUserMessage.Attributes["class"] = "alert-box success";
                    dvUserMessage.InnerHtml = message;
                    break;
                case "warning":
                    dvUserMessage.Visible = true;
                    dvUserMessage.Attributes["class"] = "alert-box warning";
                    dvUserMessage.InnerHtml = message;
                    break;
                default:
                    log.logInfo("message type not found");
                    break;
            }
        }
        protected void hideMessageControl()
        {
            dvUserMessage.Visible = false;
        }
        public void logHostDetails(string loginStatus)
        {
            try
            {
                string hostName = ""; 
                string fromIP = "";
                log.logInfo("Attempt for login with userid : " + txtbox_UserID.Text + " From host: " + hostName + "[" + fromIP + "]" + "->" + loginStatus);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            try
            {

                usrlogin.UserID = txtbox_UserID.Text;
                usrlogin.Password = txtbox_Password.Text;
                ActiveDirectoryOperationsBAL ado = new ActiveDirectoryOperationsBAL();
                string ADAuthenticationEnabled = ConfigurationManager.AppSettings["EnableADAuthentication"];
                bool ADAuthenticated;
                if (ADAuthenticationEnabled == "TRUE")
                    ADAuthenticated = ado.isADAuthenticated(usrlogin);
                else
                    ADAuthenticated = true;                    

                if (ADAuthenticated)
                {
                    AuthenticateUserBAL checkUserID = new AuthenticateUserBAL();
                    string retvalue = checkUserID.AuthenticateUserID(usrlogin.UserID);
                    if (retvalue.Contains("success"))
                    {
                        
                        logHostDetails("Success");
                        Session["loggedinUserid"] = usrlogin.UserID;
                        Session["loggedinUserName"] = retvalue.Split(';')[1];
                        //Track user
                        UserOperationsBAL ub = new UserOperationsBAL();
                        TrackUsers tu = new TrackUsers();
                        tu.UserID = Convert.ToString(Session["loggedinUserid"]);
                        tu.SessionID = Session.SessionID;
                        tu.Action = "Login";
                        ub.TrackUser(tu);
                        bindRoles();
                        if(ddlRoles.Items.Count>0)
                        hideMessageControl();
                    }
                    else
                    {
                        logHostDetails("Failed");                        
                        showUserMessage("error", "Sorry, User: " + txtbox_UserID.Text + " doesn't have access.<br>Please reach out to Admin for access.");                        
                    }
                }
                else
                {
                    logHostDetails("Failed");                    
                    showUserMessage("error", "Sorry, Authentication failed. Please try again.");
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void bindRoles()
        {
            try
            {
                DataSet roles = objUserConfig.GetUserRoles(Session["loggedinUserid"].ToString());
                if (roles != null && roles.Tables.Count > 0 && roles.Tables[0].Rows.Count > 0 && roles.Tables[0].Columns.Count>1)
                {
                    dvLogin.Visible = false;
                    up_RoleSelector.Visible = true;
                    ddlRoles.DataSource = roles;
                    ddlRoles.DataTextField = "RoleName";
                    ddlRoles.DataValueField = "RoleID";
                    ddlRoles.DataBind();                    
                        RedirectToDashboard();                    
                }
                else
                {
                    showUserMessage("error", "Sorry, there are no roles mapped to your id.<br> Please reach out to Admin for role mapping.");
                    Session["loggedinUserid"] = null;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            txtbox_UserID.Text = "";
            txtbox_Password.Text = "";
            lbl_error.Text = "";
            Response.Redirect("login.aspx", false);
        }

        protected void btnGo_Click(object sender, EventArgs e)
        {
            Session["role"] = ddlRoles.SelectedValue;
            Session["roleName"] = ddlRoles.SelectedItem.Text;
            user_location();
            Response.Redirect("Dashboard.aspx", false);
        }
        protected void RedirectToDashboard()
        {
            Session["role"] = ddlRoles.SelectedValue;
            Session["roleName"] = ddlRoles.SelectedItem.Text;
            user_location();
            Response.Redirect("Dashboard.aspx", false);

        }
        protected void user_location()
        {
            string userid = Convert.ToString(Session["loggedinuserID"]);
            Session["userLocation"] = objAuthneciateusr.userlocation(userid);
        }

    }
}