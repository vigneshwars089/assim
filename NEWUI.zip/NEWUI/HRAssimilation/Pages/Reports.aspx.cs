﻿using HRAssimilation.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using HRAssimilation.Entity;
using System.IO;
using System.Globalization;

namespace HRAssimilation.Pages
{
    public partial class Reports : System.Web.UI.Page
    {
        ReportDAL objReportdal = new ReportDAL();
        Logger.Logger log = new Logger.Logger();
        protected void Page_Load(object sender, EventArgs e)
        {


            dvReportMessage.Visible = false;
            ValidateUserSession();
            if (!Page.IsPostBack)
            {
                if (Convert.ToString(Session["role"]) == "2" && objReportdal.UsersUnderTMPOC(Convert.ToString(Session["LoggedinUserID"])) == false)
                {
                    tbl_report.Visible = false;
                    tbl_filter.Visible = false;
                    dv_buttons.Visible = false;
                    trNoUsersForReports.Visible = true;
                }
                else
                {
                    tbl_report.Visible = true;
                    dv_buttons.Visible = true;
                    string sroleid = Session["role"].ToString();
                    BindReportDropdown();
                    DataSet dsdata = objReportdal.BindaFilterdata(sroleid, Convert.ToString(Session["LoggedinUserID"]));
                    Session["dsdata"] = dsdata;
                }
            }
            else
            {
                //Get control and block other postback events
                string CtrlID = string.Empty;
                if (EventArgument.Value == "buttonclick")
                {
                    this.lsb_Location.SelectedIndexChanged -= new EventHandler(Location_SelectedIndexChanged);
                    this.lsb_Vertical.SelectedIndexChanged -= new EventHandler(OnChangeFilterVertical);
                    this.lsb_Department.SelectedIndexChanged -= new EventHandler(OnChangeFilterDept);
                }
            }


        }

        #region check user session
        public void ValidateUserSession()
        {
            try
            {
                if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                {
                    Response.Redirect("Login.aspx", true);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }
        #endregion

        #region Bind data for listbox controls
        private void BindReportDropdown()
        {

            DataSet ds = objReportdal.BindReportlist();
            ddl_ReportName.DataSource = ds;
            ddl_ReportName.DataTextField = "ReportName";
            ddl_ReportName.DataValueField = "ReportName";
            ddl_ReportName.DataBind();
            ddl_ReportName.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        private void BindLocationDropdown(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Locaiton Dropdown");
                lsb_Location.DataSource = dt;
                lsb_Location.DataTextField = "Location";
                lsb_Location.DataValueField = "ID";
                lsb_Location.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Location.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Location.SelectedValue = "0";
                    lsb_Location.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }

        private void BindAccountdtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Account Details");
                string scolumns = "AccountID,AccountName";
                string[] scols = scolumns.Split(',');
                DataTable dtaccounts = dt.DefaultView.ToTable(true, scols);
                lsb_Account.DataSource = dtaccounts;
                lsb_Account.DataTextField = "AccountName";
                lsb_Account.DataValueField = "AccountID";
                lsb_Account.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Account.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Account.SelectedValue = "0";
                    lsb_Account.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }
        private void BindMonthDropdown()
        {
            try
            {
                log.logInfo("Binding Month Dropdown");
                lsb_month.Items.Clear();
                int selectedYear = Convert.ToInt32(ddl_Year.SelectedItem.Text);
                DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);
                if (selectedYear < DateTime.Now.Year)
                {
                    for (int i = 1; i < 13; i++)
                    {
                        lsb_month.Items.Add(new ListItem(info.GetMonthName(i), i.ToString()));
                    }
                    lsb_month.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_month.SelectedValue = "0";
                    lsb_month.SelectedItem.Selected = true;
                }
                else
                    if (selectedYear == DateTime.Now.Year)
                    {
                        for (int i = 1; i <= DateTime.Now.Month; i++)
                        {

                            lsb_month.Items.Add(new ListItem(info.GetMonthName(i), i.ToString()));
                        }
                        lsb_month.Items.Insert(0, new ListItem("Select All", "0"));
                        lsb_month.SelectedValue = "0";
                        lsb_month.SelectedItem.Selected = true;
                    }
            }
            catch (FormatException ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }
        [WebMethod]
        public static List<ListItem> AddNewTMPOC(string LocationID)
        {
            DataSet dsFilter = new DataSet();
            List<ListItem> lTMPOC = new List<ListItem>();
            dsFilter = (DataSet)HttpContext.Current.Session["dsdata"];
            if (LocationID.Length > 0)
            {
                string slocation = LocationID;
                if (dsFilter != null && dsFilter.Tables.Count > 0)
                {
                    slocation = sTrailingChars(slocation);
                    DataRow[] dr = dsFilter.Tables[8].Select("LocationID in (" + slocation + ")");
                    DataTable dt = dsFilter.Tables[8].Clone();
                    if (dr.Length > 0)
                    {
                        dt = dr.CopyToDataTable();
                        foreach (var item in dr)
                        {
                            lTMPOC.Add(new ListItem
                            {
                                Value = item["AssociateID"].ToString(),
                                Text = item["Name"].ToString()
                            });
                        }
                    }
                }
            }
            lTMPOC = lTMPOC.Distinct().ToList().OrderBy(p => p.Value).ToList();
            return lTMPOC;
        }



        public void BindFacilitydtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Facility Details");
                lsb_Facility.DataSource = dt;
                lsb_Facility.DataTextField = "FacilityName";
                lsb_Facility.DataValueField = "Code";
                lsb_Facility.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Facility.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Facility.SelectedValue = "0";
                    lsb_Facility.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindDepartmentdtls(DataTable dt)
        {
            try
            {
                lsb_Department.DataSource = dt;
                lsb_Department.DataTextField = "DepartmentName";
                lsb_Department.DataValueField = "DepartmentID";
                lsb_Department.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Department.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Department.SelectedValue = "0";
                    lsb_Department.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindVerticaldtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Vertical Details");
                string scolumns = "VerticalID,VerticalName";
                string[] scols = scolumns.Split(',');
                DataTable dtVertical = dt.DefaultView.ToTable(true, scols);
                lsb_Vertical.DataSource = dtVertical;
                lsb_Vertical.DataTextField = "VerticalName";
                lsb_Vertical.DataValueField = "VerticalID";
                lsb_Vertical.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Vertical.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Vertical.SelectedValue = "0";
                    lsb_Vertical.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindReasondtls(DataTable dt)
        {
            try
            {
                lsb_Reason.DataSource = dt;
                lsb_Reason.DataTextField = "Reason";
                lsb_Reason.DataValueField = "Reason";
                lsb_Reason.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Reason.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Reason.SelectedValue = "0";
                    lsb_Reason.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindStatusdetail(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Staus Details");
                lsb_Status.DataSource = dt;
                lsb_Status.DataTextField = "StatusName";
                lsb_Status.DataValueField = "StatusName";
                lsb_Status.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Status.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Status.SelectedValue = "0";
                    lsb_Status.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindDesignationdtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Designation Details");
                lsb_Designation.DataSource = dt;
                lsb_Designation.DataTextField = "Designation";
                lsb_Designation.DataValueField = "Designation";
                lsb_Designation.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Designation.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Designation.SelectedValue = "0";
                    lsb_Designation.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindTalentMngrdtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding TMPOC Details");
                if (Session["role"].ToString() == "2")
                {
                    lsb_TalentManager.Items.Clear();
                    lsb_TalentManager.Items.Insert(0, new ListItem(Session["loggedinUserName"] + "(" + Session["loggedinUserid"].ToString() + ")", Session["loggedinUserid"].ToString()));
                    lsb_TalentManager.SelectedValue = "0";
                    lsb_TalentManager.SelectedItem.Selected = true;
                }
                else
                {
                    string scolumns = "AssociateID,Name";
                    string[] scols = scolumns.Split(',');
                    DataTable dtaccounts = dt.DefaultView.ToTable(true, scols);
                    lsb_TalentManager.DataSource = dtaccounts;
                    lsb_TalentManager.DataTextField = "Name";
                    lsb_TalentManager.DataValueField = "AssociateID";
                    lsb_TalentManager.DataBind();
                    if (dt.Rows.Count > 0)
                    {
                        lsb_TalentManager.Items.Insert(0, new ListItem("Select All", "0"));
                        lsb_TalentManager.SelectedValue = "0";
                        lsb_TalentManager.SelectedItem.Selected = true;
                    }
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }

        public void BindTenuredtls(DataTable dt)
        {
            try
            {
                log.logInfo("Binding Tenure selection filter");
                lsb_Tenure.DataSource = dt;
                lsb_Tenure.DataTextField = "Value";
                lsb_Tenure.DataValueField = "Value";
                lsb_Tenure.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_Tenure.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_Tenure.SelectedValue = "0";
                    lsb_Tenure.SelectedItem.Selected = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        public void BindConnectTypes(DataTable dt)
        {
            try
            {
                lsb_ConnectType.DataSource = dt;
                lsb_ConnectType.DataTextField = "ConnectType";
                lsb_ConnectType.DataValueField = "ConnectType";
                lsb_ConnectType.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lsb_ConnectType.Items.Insert(0, new ListItem("Select All", "0"));
                    lsb_ConnectType.SelectedValue = "0";
                    lsb_ConnectType.SelectedItem.Selected = true;
                }
            }
            catch(Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        #endregion
        
        #region validate mandatory fields.
        protected string Validatefield(string sSelReportName)
        {
            dvReportMessage.Visible = false;
            string sMsg = "";
            if (sSelReportName != "--Select--")
            {
                if (sSelReportName == "YTD attrition report")
                {
                    if (string.IsNullOrEmpty(ddl_Year.SelectedItem.Text) || lsb_Location.SelectedItem == null || lsb_Facility.SelectedItem == null
                        || lsb_Department.SelectedItem == null || lsb_Vertical.SelectedItem == null || lsb_Account.SelectedItem == null
                        || lsb_Reason.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                }
                else if (sSelReportName == "Attrition report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Location.SelectedItem == null ||
                        lsb_Facility.SelectedItem == null || lsb_Department.SelectedItem == null || lsb_Vertical.SelectedItem == null ||
                        lsb_Account.SelectedItem == null || lsb_Reason.SelectedItem == null || lsb_Designation.SelectedItem == null || lsb_Tenure.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Attrition Count report" || sSelReportName == "Location wise attrition count report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Location.SelectedItem == null
                        || lsb_Facility.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Vertical wise attrition count report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Department.SelectedItem == null
                       || lsb_Vertical.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Tenure wise attrition count report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Tenure.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Retention summary report" || sSelReportName == "EWS report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Department.SelectedItem == null
                        || lsb_Vertical.SelectedItem == null || lsb_Account.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Connects report")
                {
                    if (lsb_Location.SelectedItem == null
                       || lsb_TalentManager.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    //else
                    //{
                    //    sMsg = ValidateDateRange(sSelReportName);
                    //}
                }
                else if (sSelReportName == "Status wise report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text) || lsb_Status.SelectedItem == null
                       || lsb_Location.SelectedItem == null || lsb_TalentManager.SelectedItem == null)
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
                else if (sSelReportName == "Portal Usage report")
                {
                    if (string.IsNullOrEmpty(txt_Fromdt.Text) || string.IsNullOrEmpty(txt_Todt.Text))
                    {
                        sMsg = "error; Please select Mandatory fields.";
                    }
                    else
                    {
                        sMsg = ValidateDateRange(sSelReportName);
                    }
                }
            }
            else
            {
                sMsg = "error; Please select any one report name from dropdown.";
            }
            return sMsg;
        }
        #endregion

        #region validate DateRange
        protected string ValidateDateRange(string sSelReportName)
        {
            string sflag = "";
            if (sSelReportName != "YTD attrition report")
            {
                if (!String.IsNullOrEmpty(txt_Fromdt.Text) && !String.IsNullOrEmpty(txt_Todt.Text))
                {
                    DateTime Frmdt = Convert.ToDateTime(txt_Fromdt.Text);
                    DateTime Todt = Convert.ToDateTime(txt_Todt.Text).AddDays(-1);
                    TimeSpan difference = (Todt - Frmdt);
                    int d = difference.Days;
                    if (d > 365)
                    {
                        sflag = "error; DateRange should be less than 365 days.";
                    }
                }
            }
            return sflag;
        }
        #endregion

        #region Generate Report
        protected void btn_GenerateReport_Click(object sender, EventArgs e)
        {
            ReportsfilterDetails objReportfilter = new ReportsfilterDetails();
            string sSelReportName = ddl_ReportName.SelectedItem.Text.ToString();
            string sfieldMsg = Validatefield(sSelReportName);
            DataSet ds = new DataSet();
            if (sfieldMsg.Trim().Length == 0)
            {
                if (sSelReportName != "--Select--")
                {
                    switch (sSelReportName)
                    {
                        case "YTD attrition report":
                            objReportfilter.Year = ddl_Year.SelectedItem.Text;
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.Facility = (TrimTrailingChars(GetSelectedvalue(lsb_Facility)));
                            objReportfilter.Department = (TrimTrailingChars(GetSelectedvalue(lsb_Department)));
                            objReportfilter.Vertical = (TrimTrailingChars(GetSelectedvalue(lsb_Vertical)));
                            objReportfilter.Account = (TrimTrailingChars(GetSelectedvalue(lsb_Account)));
                            objReportfilter.Reason = (TrimTrailingChars(GetSelectedvalue(lsb_Reason)));
                            ds = objReportdal.GenerateYTDReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "Attrition report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Department = GetSelectedvalue(lsb_Department);
                            objReportfilter.Vertical = GetSelectedvalue(lsb_Vertical);
                            objReportfilter.Account = GetSelectedvalue(lsb_Account);
                            objReportfilter.Reason = GetSelectedvalue(lsb_Reason);
                            objReportfilter.Designation = GetSelectedvalue(lsb_Designation);
                            objReportfilter.Tenure = GetSelectedvalue(lsb_Tenure);
                            objReportfilter.Facility = GetSelectedvalue(lsb_Facility);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();
                            ds = objReportdal.GenerateAttritionReport(objReportfilter);
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Attrition Count report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.Facility = GetSelectedvalue(lsb_Facility);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();
                            ds = objReportdal.GenerateAttritionCountReport(objReportfilter);
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Location wise attrition count report":

                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.Facility = GetSelectedvalue(lsb_Facility);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();
                            ds = objReportdal.GenerateLocationWiseAttritionCountReport(objReportfilter);

                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                GenerateExcelReportlocn(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Vertical wise attrition count report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Department = GetSelectedvalue(lsb_Department);
                            objReportfilter.Vertical = GetSelectedvalue(lsb_Vertical);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();

                            ds = objReportdal.GenerateVerticalwiseReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                GenerateExcelReportVertical(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Tenure wise attrition count report":

                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Tenure = GetSelectedvalue(lsb_Tenure);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();
                            ds = objReportdal.GenerateTenurewiseReport(objReportfilter);
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                GenerateExcelReportTenure(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Retention summary report":

                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Department = GetSelectedvalue(lsb_Department);
                            objReportfilter.Account = GetSelectedvalue(lsb_Account);
                            objReportfilter.Vertical = GetSelectedvalue(lsb_Vertical);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();

                            ds = objReportdal.GenerateRetentionReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                GenerateExcelReportRetention(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "Retention Details report":

                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Department = GetSelectedvalue(lsb_Department);
                            objReportfilter.Account = GetSelectedvalue(lsb_Account);
                            objReportfilter.Vertical = GetSelectedvalue(lsb_Vertical);
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            objReportfilter.Role = Session["role"].ToString();

                            ds = objReportdal.GetRetentionDetailsReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0],sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                            
                        case "EWS report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Department = GetSelectedvalue(lsb_Department);
                            objReportfilter.Vertical = GetSelectedvalue(lsb_Vertical);
                            objReportfilter.Account = GetSelectedvalue(lsb_Account);
                            objReportfilter.Role = Session["role"].ToString();
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            ds = objReportdal.GenerateEWSReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                GenerateExcelReportEWS(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Connects report":
                            objReportfilter.Year = ddl_Year.SelectedItem.Text;
                            objReportfilter.Month = GetSelectedvalue(lsb_month);
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.TalentMAnager = GetSelectedvalue(lsb_TalentManager);                            
                            ds = objReportdal.GenerateConnectsReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "EWS Accuracy report":
                            objReportfilter.Year = ddl_Year.SelectedItem.Text;
                            objReportfilter.Month = GetSelectedvalue(lsb_month);
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.TalentMAnager = GetSelectedvalue(lsb_TalentManager);                            
                            ds = objReportdal.GenerateEWSAccuracyReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "Associate Details report":
                            objReportfilter.Year = ddl_Year.SelectedItem.Text;
                            objReportfilter.Month = GetSelectedvalue(lsb_month);
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.TalentMAnager = GetSelectedvalue(lsb_TalentManager);
                            objReportfilter.Role = Session["role"].ToString();
                            objReportfilter.IncludeNewJoiners = chkbox_NewJoiners.Checked;
                            ds = objReportdal.GenerateAssociateDetailsReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;

                        case "Status wise report":

                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.Status = GetSelectedvalue(lsb_Status);
                            objReportfilter.Location = GetSelectedvalue(lsb_Location);
                            objReportfilter.TalentMAnager = GetSelectedvalue(lsb_TalentManager);

                            ds = objReportdal.GenerateStatuswiseReport(objReportfilter);
                            string[] columnNames = ds.Tables[0].Columns.Cast<DataColumn>()
                                 .Select(x => x.ColumnName)
                                 .ToArray();

                            string[] queriedColumns = objReportfilter.Status.Split(',');

                            if (!queriedColumns.Contains("0"))
                            {
                                foreach (string acolumn in columnNames)
                                {
                                    if (queriedColumns.Contains(acolumn) || acolumn.Contains("Location") || acolumn.Contains("TMPOC"))
                                    {

                                    }
                                    else
                                    {
                                        ds.Tables[0].Columns.Remove(acolumn);
                                    }
                                }
                                ds.Tables[0].AcceptChanges();
                            }
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "Portal Usage report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;      
                            objReportfilter.Role = Session["role"].ToString();
                            objReportfilter.TMPOC = Session["loggedinUserid"].ToString();
                            ds = objReportdal.GeneratePortalUsageReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "Engagement Activity Details":
                            objReportfilter.Year = ddl_Year.SelectedItem.Text;
                            objReportfilter.Month = GetSelectedvalue(lsb_month);
                            objReportfilter.TMPOC = GetSelectedvalue(lsb_TalentManager);
                            objReportfilter.ConnectType = GetSelectedvalue(lsb_ConnectType);
                            ds = objReportdal.GenerateEngagementActivityDetailsReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                                //Excel_Read.GenerateExcelReport(sSelReportName, ds.Tables[0]);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        case "JA and Resignation Report":
                            objReportfilter.FromDate = txt_Fromdt.Text;
                            objReportfilter.ToDate = txt_Todt.Text;
                            objReportfilter.ActionType = GetSelectedvalue(lsb_ActionType);
                            objReportfilter.TMPOC = Session["ROLE"].ToString() == "2" ? Session["LOGGEDINUSERID"].ToString() : null;
                            ds = objReportdal.GenerateJAandResignationReport(objReportfilter);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                ExportDataTabletoExcel(ds.Tables[0], sSelReportName);
                            }
                            else
                            {
                                showUserMessage("error", "Data Not available for this filter");
                            }
                            break;
                        default: log.logInfo("report type not found");
                            break;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(sfieldMsg) && sfieldMsg.Contains(';'))
                {
                    string msgtype = sfieldMsg.Split(';')[0];
                    string message = sfieldMsg.Split(';')[1];
                    showUserMessage(msgtype, message);
                }
            }

        }
        #endregion

        #region download Excel
        private void ExportDataTabletoExcel(DataTable table, string reportname)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + reportname + ". Logged In User: " + Session["loggedinuserid"].ToString());
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.Buffer = true;
                HttpContext.Current.Response.ContentType = "application/ms-excel";
                HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                HttpContext.Current.Response.AddHeader("Content-Disposition",
                    "attachment;filename=" + reportname + " " + DateTime.Now + ".xls");

                HttpContext.Current.Response.Charset = "utf-8";
                HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                //sets font
                HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                HttpContext.Current.Response.Write("<BR><BR><BR>");
                //sets the table border, cell spacing, border color, font of the text, background, foreground, font height
                HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
                  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
                  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                //am getting my grid's column headers
                int columnscount = table.Columns.Count;

                for (int j = 0; j < columnscount; j++)
                {      //write in new column
                    HttpContext.Current.Response.Write("<Td>");
                    //Get column headers  and make it as bold in excel columns
                    HttpContext.Current.Response.Write("<B>");
                    HttpContext.Current.Response.Write(table.Columns[j].Caption.ToString());
                    HttpContext.Current.Response.Write("</B>");
                    HttpContext.Current.Response.Write("</Td>");
                }
                HttpContext.Current.Response.Write("</TR>");
                foreach (DataRow row in table.Rows)
                {//write in new row
                    HttpContext.Current.Response.Write("<TR>");
                    for (int i = 0; i < table.Columns.Count; i++)
                    {
                        HttpContext.Current.Response.Write("<Td>");
                        HttpContext.Current.Response.Write(row[i].ToString());
                        HttpContext.Current.Response.Write("</Td>");
                    }

                    HttpContext.Current.Response.Write("</TR>");
                }
                HttpContext.Current.Response.Write("</Table>");
                HttpContext.Current.Response.Write("</font>");
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.End();

            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + reportname + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        public void GenerateExcelReport(string Reportname, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + Reportname + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string excel = Excel_Read.GenerateExcelReport(Reportname, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                 "attachment;filename=" + Reportname + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Write(excel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + Reportname + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        #endregion

        public void GenerateExcelReportlocn(string sName, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + sName + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string sexcel = Excel_Read.GenerateExcelAttritionrepReport(sName, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                 "attachment;filename=" + sName + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                //Response.ContentEncoding = Encoding.Default; 
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Output.Write(sexcel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + sName + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        public void GenerateExcelReportRetention(string sName, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + sName + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string sexcel = Excel_Read.GenerateExcelReportRetention(sName, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                 "attachment;filename=" + sName + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                //Response.ContentEncoding = Encoding.Default; 
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Output.Write(sexcel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + sName + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        public void GenerateExcelReportVertical(string sName, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + sName + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string sexcel = Excel_Read.GenerateExcelReportVertical(sName, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                "attachment;filename=" + sName + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                //Response.ContentEncoding = Encoding.Default; 
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Output.Write(sexcel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + sName + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        public void GenerateExcelReportTenure(string sName, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + sName + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string sexcel = Excel_Read.GenerateExcelReportTenure(sName, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                "attachment;filename=" + sName + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                //Response.ContentEncoding = Encoding.Default; 
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Output.Write(sexcel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + sName + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        public void GenerateExcelReportEWS(string sName, DataTable dt)
        {
            try
            {
                log.logInfo("Reports Page - Generating " + sName + ". Logged In User: " + Session["loggedinuserid"].ToString());
                string sexcel = Excel_Read.GenerateExcelReportEWS(sName, dt);
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition",
                "attachment;filename=" + sName + " " + DateTime.Now + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                //Response.ContentEncoding = Encoding.Default; 
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                Response.Output.Write(sexcel.ToString());
                Response.Flush();
                Response.Close();
                //Response.End();
            }
            catch (Exception ex)
            {
                log.logError("Error downloading " + sName + ". Error: " + ex.Message + ex.StackTrace);
            }
        }
        #region show error message
        protected void showUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        #endregion

        #region Onchage Events for control

        protected void BindListbox(object sender, EventArgs e)
        {
            try
            {
                dvReportMessage.Visible = false;
                DataSet dsFilter = new DataSet();
                dsFilter = ((DataSet)Session["dsdata"]);

                if (dsFilter != null && dsFilter.Tables.Count > 0)
                {
                    string sSelReportName = ddl_ReportName.SelectedValue;
                    int year, i;
                    switch (sSelReportName)
                    {
                        case "YTD attrition report":
                            ddl_Year.Items.Clear();
                            year = Convert.ToInt32(DateTime.Now.Year.ToString());
                            i = 0;
                            for (; year >= 2015; year--, i++)
                            {
                                ddl_Year.Items.Insert(i, new ListItem(year.ToString(), i.ToString()));
                            }
                            BindLocationDropdown(dsFilter.Tables[0]);
                            BindFacilitydtls(dsFilter.Tables[1]);
                            BindDepartmentdtls(dsFilter.Tables[4]);
                            BindVerticaldtls(dsFilter.Tables[2]);
                            BindAccountdtls(dsFilter.Tables[2]);
                            BindReasondtls(dsFilter.Tables[7]);
                            break;
                        case "Attrition report":

                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindLocationDropdown(dsFilter.Tables[0]);
                            BindFacilitydtls(dsFilter.Tables[1]);
                            BindDepartmentdtls(dsFilter.Tables[4]);
                            BindVerticaldtls(dsFilter.Tables[3]);
                            BindAccountdtls(dsFilter.Tables[2]);
                            BindReasondtls(dsFilter.Tables[7]);
                            BindDesignationdtls(dsFilter.Tables[6]);
                            BindTenuredtls(dsFilter.Tables[9]);
                            break;
                        case "Attrition Count report":
                        case "Location wise attrition count report":
                            //else if (sSelReportName == "Attrition Count report" || sSelReportName == "Location wise attrition count report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindLocationDropdown(dsFilter.Tables[0]);
                            BindFacilitydtls(dsFilter.Tables[1]);
                            break;
                        //}
                        case "Vertical wise attrition count report":
                            //else if (sSelReportName == "Vertical wise attrition count report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindDepartmentdtls(dsFilter.Tables[4]);
                            BindVerticaldtls(dsFilter.Tables[3]);
                            break;
                        //}
                        case "Tenure wise attrition count report":
                            //else if (sSelReportName == "Tenure wise attrition count report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindTenuredtls(dsFilter.Tables[9]);
                            break;
                        //}
                        case "Retention summary report":
                        case "EWS report":
                        case "Retention Details report":
                            //else if (sSelReportName == "Retention summary report" || sSelReportName == "EWS report" || sSelReportName == "Retention Details report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindDepartmentdtls(dsFilter.Tables[4]);
                            BindVerticaldtls(dsFilter.Tables[3]);
                            BindAccountdtls(dsFilter.Tables[2]);
                            break;
                        //}
                        case "Connects report":
                        case "EWS Accuracy report":
                        case "Associate Details report":
                            //else if (sSelReportName == "Connects report" || sSelReportName == "EWS Accuracy report" || sSelReportName == "Associate Details report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            ddl_Year.Items.Clear();
                            year = Convert.ToInt32(DateTime.Now.Year.ToString());
                            i = 0;

                            for (; year >= 2015; year--, i++)
                            {
                                ddl_Year.Items.Insert(i, new ListItem(year.ToString(), i.ToString()));
                            }
                            BindMonthDropdown();
                            BindLocationDropdown(dsFilter.Tables[0]);
                            BindTalentMngrdtls(dsFilter.Tables[8]);
                            break;
                        //}
                        case "Status wise report":
                            //else if (sSelReportName == "Status wise report")
                            //{
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            BindStatusdetail(dsFilter.Tables[5]);
                            BindLocationDropdown(dsFilter.Tables[0]);
                            BindTalentMngrdtls(dsFilter.Tables[8]);
                            break;
                        //}
                        case "Engagement Activity Details":
                            {
                                year = Convert.ToInt32(DateTime.Now.Year.ToString());
                                i = 0;
                                ddl_Year.Items.Clear();
                                for (; year >= 2015; year--, i++)
                                {
                                    ddl_Year.Items.Insert(i, new ListItem(year.ToString(), i.ToString()));
                                }
                                BindMonthDropdown();
                                BindTalentMngrdtls(dsFilter.Tables[8]);
                                BindConnectTypes(dsFilter.Tables[10]);
                                break;
                            }
                        case "JA and Resignation Report":
                            txt_Fromdt.Text = String.Empty;
                            txt_Todt.Text = String.Empty;
                            lsb_ActionType.Items.Insert(0, new ListItem("Select All", "0"));
                            lsb_ActionType.SelectedValue = "0";
                            lsb_ActionType.SelectedItem.Selected = true;
                            break;
                        //}
                    }
                    this.lsb_Location.SelectedIndexChanged -= new EventHandler(Location_SelectedIndexChanged);
                    this.lsb_Vertical.SelectedIndexChanged -= new EventHandler(OnChangeFilterVertical);
                    this.lsb_Department.SelectedIndexChanged -= new EventHandler(OnChangeFilterDept);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            finally
            {

            }
        }

        protected void Location_SelectedIndexChanged(object sender, EventArgs e)
        {
            {
                DataSet dsFilter = new DataSet();
                dsFilter = ((DataSet)Session["dsdata"]);
                string slocation = GetSelectedvalue(lsb_Location);
                if (slocation.Length > 0)
                {
                    if (dsFilter != null && dsFilter.Tables.Count > 0)
                    {

                        slocation = TrimTrailingChars(slocation);
                        DataRow[] dr = dsFilter.Tables[1].Select("LocationID in (" + slocation + ")");
                        DataTable dt = dsFilter.Tables[1].Clone();
                        if (dr.Length > 0)
                        {
                            dt = dr.CopyToDataTable();
                            BindFacilitydtls(dt);
                        }
                    }
                }
            }
            this.lsb_Vertical.SelectedIndexChanged -= new EventHandler(OnChangeFilterVertical);
            this.lsb_Department.SelectedIndexChanged -= new EventHandler(OnChangeFilterDept);
            this.lsb_Location.SelectedIndexChanged -= new EventHandler(Location_SelectedIndexChanged);
        }
        protected void bindAccountVertical()
        {
            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)Session["dsdata"]);
            string sDepartment = GetSelectedvalue(lsb_Department);
            string sVertical = GetSelectedvalue(lsb_Vertical);

            if (sDepartment.Length > 0 && sVertical.Length == 0)
            {
                DataTable dtResult = new DataTable();
                dtResult.Columns.Add("AccountID", typeof(string));
                dtResult.Columns.Add("AccountName", typeof(string));
                dtResult.Columns.Add("VerticalID", typeof(string));
                dtResult.Columns.Add("VerticalName", typeof(string));

                DataTable dtVertical = dsFilter.Tables[3];
                DataTable dtAccount = dsFilter.Tables[2];
                DataTable dt = new DataTable();
                var result = from dataRows1 in dtAccount.AsEnumerable()
                             join dataRows2 in dtVertical.AsEnumerable()
                             on dataRows1.Field<string>("VerticalID") equals dataRows2.Field<string>("VerticalID")
                             select dt.LoadDataRow(new object[]
                                {
                                dataRows1.Field<string>("AccountID"),
                                dataRows1.Field<string>("AccountName"),
                                dataRows1.Field<string>("VerticalID"),
                                dataRows2.Field<string>("VerticalName")
                                }, false);
                DataTable dtset = result.CopyToDataTable();

            }
        }

        protected void OnChangeFilterVertical(object sender, EventArgs e)
        {

            {
                DataSet dsFilter = new DataSet();
                dsFilter = ((DataSet)Session["dsdata"]);
                string sDepartment = GetSelectedvalue(lsb_Department);
                string sVertical = GetSelectedvalue(lsb_Vertical);

                if (sDepartment.Length > 0 && sVertical.Length > 0)
                {
                    if (dsFilter != null && dsFilter.Tables.Count > 0)
                    {
                        sDepartment = AddsingleQutoes(TrimTrailingChars(sDepartment));
                        sVertical = AddsingleQutoes(TrimTrailingChars(sVertical));
                        DataRow[] dr = dsFilter.Tables[2].Select("DepartmentID in(" + sDepartment + ")" + " and VerticalID in (" + sVertical + ")");
                        DataTable dtAccountdtls = dsFilter.Tables[2].Clone();
                        if (dr.Length > 0)
                        {
                            dtAccountdtls = dr.CopyToDataTable();
                        }
                        BindAccountdtls(dtAccountdtls);
                    }
                }
            }

            this.lsb_Department.SelectedIndexChanged -= new EventHandler(OnChangeFilterDept);
            this.lsb_Location.SelectedIndexChanged -= new EventHandler(Location_SelectedIndexChanged);

        }

        protected void OnChangeFilterDept(object sender, EventArgs e)
        {
            {
                DataSet dsFilter = new DataSet();
                dsFilter = ((DataSet)Session["dsdata"]);
                string sDepartment = GetSelectedvalue(lsb_Department);
                string sVertical = GetSelectedvalue(lsb_Vertical);

                if (sDepartment.Length > 0)
                {
                    if (dsFilter != null && dsFilter.Tables.Count > 0)
                    {
                        sDepartment = AddsingleQutoes(TrimTrailingChars(sDepartment));
                        DataRow[] dr = dsFilter.Tables[2].Select("DepartmentID in(" + sDepartment + ")");
                        DataTable dtAccountdtls = dsFilter.Tables[2].Clone();
                        if (dr.Length > 0)
                        {
                            dtAccountdtls = dr.CopyToDataTable();
                        }
                        BindVerticaldtls(dtAccountdtls);
                        BindAccountdtls(dtAccountdtls);
                    }
                }
            }
            this.lsb_Vertical.SelectedIndexChanged -= new EventHandler(OnChangeFilterVertical);
            this.lsb_Location.SelectedIndexChanged -= new EventHandler(Location_SelectedIndexChanged);
        }

        #endregion

        protected void ValidateData()
        {
            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)Session["dsdata"]);
            var str = lsb_Location.SelectedValue.ToString();
            BindFacilitydtls(dsFilter.Tables[1]);
        }

        public string GetSelectedvalue(ListBox id)
        {
            string sValue = "";
            try
            {
                var selected = id.GetSelectedIndices().ToList();
                foreach (var item in selected)
                {
                    sValue += id.Items[item].Value.ToString() + ",";
                }
                sValue = sValue.Substring(0, sValue.Length - 1);
            }
            catch (Exception)
            {
                sValue = "";
            }
            return sValue;
        }

        protected string TrimTrailingChars(string str)
        {
            return str = str.TrimEnd(',');
        }

        protected string AddsingleQutoes(string sinput)
        {
            return sinput = string.Join(",", sinput.Split(',').Select(x => string.Format("'{0}'", x)).ToList());
        }

        [WebMethod]
        public static List<ListItem> AddNewItem(string name)
        {
            DataSet dsFilter = new DataSet();
            List<ListItem> lFacility = new List<ListItem>();
            dsFilter = ((DataSet)HttpContext.Current.Session["dsdata"]);

            if (name.Length > 0)
            {
                string slocation = name;
                if (dsFilter != null && dsFilter.Tables.Count > 0)
                {

                    slocation = sTrailingChars(slocation);
                    DataRow[] dr = dsFilter.Tables[1].Select("LocationID in (" + slocation + ")");
                    DataTable dt = dsFilter.Tables[1].Clone();
                    if (dr.Length > 0)
                    {
                        dt = dr.CopyToDataTable();
                        foreach (var item in dr)
                        {
                            lFacility.Add(new ListItem
                            {
                                Value = item["Code"].ToString(),
                                Text = item["FacilityName"].ToString()
                            });
                        }
                    }
                }
                return lFacility;
            }
            return lFacility;
        }


        [WebMethod]
        public static List<LDepartment> AddDepartment(string sDept)
        {
            DataSet dsFilter = new DataSet();
            dsFilter = ((DataSet)HttpContext.Current.Session["dsdata"]);
            List<LDepartment> lDept = new List<LDepartment>();
            LDepartment objDept = new LDepartment();
            string sDepartment = sDept;

            if (sDepartment.Length > 0)
            {
                if (dsFilter != null && dsFilter.Tables.Count > 0)
                {
                    List<LVertical> lVertdtl = new List<LVertical>();
                    List<LAccount> lAccountdtls = new List<LAccount>();
                    sDepartment = AddsingleQutoestostring(sTrailingChars(sDepartment));
                    DataRow[] dr = dsFilter.Tables[2].Select("DepartmentID in(" + sDepartment + ")");
                    if (dr.Length > 0)
                    {
                        foreach (var item in dr)
                        {

                            bool bflag = lVertdtl.Exists(x => x.VerticalID == item["VerticalID"].ToString());
                            if (!bflag)
                            {
                                lVertdtl.Add(new LVertical
                                {
                                    VerticalName = item["VerticalName"].ToString(),
                                    VerticalID = item["VerticalID"].ToString()
                                });
                            }
                            lAccountdtls.Add(new LAccount
                            {
                                AccountName = item["AccountName"].ToString(),
                                AccountID = item["AccountID"].ToString()
                            });
                        }
                        objDept.Verticladtls = lVertdtl;
                        objDept.Accountdtls = lAccountdtls;
                        lDept.Add(objDept);
                    }
                }
            }
            return lDept;
        }

        [WebMethod]
        public static List<ListItem> AddVertical(string sVerticaldata, string sDeptdata)
        {
            DataSet dsFilter = new DataSet();
            string sDepartment = sDeptdata;
            dsFilter = ((DataSet)HttpContext.Current.Session["dsdata"]);
            string sVertical = sVerticaldata;
            List<ListItem> lVertical = new List<ListItem>();
            if (sDepartment.Length > 0 && sVertical.Length > 0)
            {
                if (dsFilter != null && dsFilter.Tables.Count > 0)
                {
                    sDepartment = AddsingleQutoestostring(sTrailingChars(sDepartment));
                    sVertical = AddsingleQutoestostring(sTrailingChars(sVertical));
                    DataRow[] dr = null;
                    if (!string.IsNullOrEmpty(sDepartment))
                    {
                        dr = dsFilter.Tables[2].Select("DepartmentID in(" + sDepartment + ")" + " and VerticalID in (" + sVertical + ")");
                    }
                    else
                    {
                        dr = dsFilter.Tables[2].Select("  VerticalID in (" + sVertical + ")");
                    }
                    DataTable dtAccountdtls = dsFilter.Tables[2].Clone();
                    if (dr.Length > 0)
                    {
                        dtAccountdtls = dr.CopyToDataTable();
                        foreach (var item in dr)
                        {
                            lVertical.Add(new ListItem
                            {
                                Value = item["AccountID"].ToString(),
                                Text = item["AccountName"].ToString()
                            });
                        }
                    }
                }
            }
            return lVertical;
        }

        public class LAccount
        {
            public string AccountName { get; set; }
            public string AccountID { get; set; }
        }

        public class LVertical
        {
            public string VerticalName { get; set; }
            public string VerticalID { get; set; }
        }

        public class LDepartment
        {
            public List<LVertical> Verticladtls { get; set; }
            public List<LAccount> Accountdtls { get; set; }
        }

        public static string sTrailingChars(string str)
        {
            return str = str.TrimEnd(',');
        }

        public static string AddsingleQutoestostring(string sinput)
        {
            return sinput = string.Join(",", sinput.Split(',').Select(x => string.Format("'{0}'", x)).ToList());
        }

        protected void ddl_Year_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindMonthDropdown();
        }      

    }
}