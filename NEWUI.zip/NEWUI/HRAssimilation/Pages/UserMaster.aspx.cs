﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Business;
using HRAssimilation.Entity;
using System.Data;

namespace HRAssimilation.Pages
{
    public partial class Usermaster : System.Web.UI.Page
    {
        UserConfigurationBAL usrconfigBAL = new UserConfigurationBAL();
        ActiveDirectoryOperationsBAL adoBAL = new ActiveDirectoryOperationsBAL();
        UserDetails usrdetails = new UserDetails();
        UserRoleDetails roledetails = new UserRoleDetails();
        UserPOCLeadMappingDetails POCLeadMappingdetails = new UserPOCLeadMappingDetails();
        UserLocationMappingDetails locdetails = new UserLocationMappingDetails();
        Logger.Logger log = new Logger.Logger();

        string flag = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    log.logInfo("UserMaster pageload");
                    if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
                    {
                        Response.Redirect("Login.aspx", true);
                    }
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                }
                Session["SortedData"] = null;
                RefreshGrids();
                chkboxlist_location_bind();
                chkboxlist_Roles_BindRoles();
                BindAll();
            }
            HideMessageControl();
        }

        protected void ShowUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);            
        }

        protected void ShowUserMessage_roles(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);            
        }
        protected void ShowUserMessage_lead(string msgType, string message)
        {
           ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);           
        }

        protected void ShowUserMessage_loc(string msgType, string message)
        {
           ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        protected void Img_Search_Click(object sender, ImageClickEventArgs e)
        {
            ResetControls();
            usrdetails.Error_msg = string.Empty;
            usrdetails = adoBAL.getuserdetails(txt_CognizantID.Text);
            txt_FirstName.Text = usrdetails.FirstName;
            txt_LastName.Text = usrdetails.LastName;
            txt_EmailID.Text = usrdetails.EmailID;
            if (!string.IsNullOrEmpty(usrdetails.Error_msg))
            {
                ShowUserMessage("error", usrdetails.Error_msg);
            }
        }
        protected void HideMessageControl()
        {
            dvUserMessage.Visible = false;
            dv_result.Visible = false;
            dv_result_lead.Visible = false;
            dv_messageloc.Visible = false;
        }
        protected void btn_submit_Click(object sender, EventArgs e)
        {

            flag = "save";
            usrdetails.CognizantID = txt_CognizantID.Text;
            usrdetails.FirstName = txt_FirstName.Text;
            usrdetails.LastName = txt_LastName.Text;
            usrdetails.EmailID = txt_EmailID.Text;
            usrdetails.CreatedBy = Session["loggedinUserid"].ToString();
            usrdetails.ModifiedBy = Session["loggedinUserid"].ToString();
            usrdetails.IsActive = "Y";
            string result = usrconfigBAL.Manageuser(usrdetails, flag);
            if (result.Contains(';'))
            {
                ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
                if (result.Split(';')[0] == "success")
                {
                    DataTable dt = usrconfigBAL.BindUserDetails();
                    Session["UserTable"] = dt;
                    if (Session["SortedData"] != null)
                        ApplySort();
                }
                ResetControls();
                txt_CognizantID.Text = string.Empty;
            }
            else
                ShowUserMessage("error", result);
            BindAll();
            RefreshGrids();
        }

        protected void grdview_AssociateDetails_BindUserDetails()
        {
            try
            {
                if (Session["SortedData"] != null)
                {
                    grdview_AssociateDetails.DataSource = Session["SortedData"] as DataTable;
                    grdview_AssociateDetails.DataBind();
                }
                else
                {
                    DataTable dt = new DataTable();
                    dt = usrconfigBAL.BindUserDetails();
                    grdview_AssociateDetails.DataSource = dt;
                    Session["UserTable"] = dt;
                    
                    grdview_AssociateDetails.DataBind();
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        protected void grdview_AssociateDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdview_AssociateDetails.PageIndex = e.NewPageIndex;
            grdview_AssociateDetails.EditIndex = -1;
            grdview_AssociateDetails_BindUserDetails();
            Session["pid"] = e.NewPageIndex;
        }
        protected void ApplySort()
        {
            DataTable dt = Session["UserTable"] as DataTable;
            if (dt != null)
            {
                dt.DefaultView.Sort = ViewState["SortExpression"] + " " + ViewState["SortDirection"].ToString();
                grdview_AssociateDetails.DataSource = dt;
                grdview_AssociateDetails.DataBind();
                grdview_AssociateDetails.PageIndex = Convert.ToInt32(Session["pid"]);
                Session["SortedData"] = dt;
            }
        }
        protected void grdview_AssociateDetails_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dt = Session["UserTable"] as DataTable;
            if (dt != null)
            {
                dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
                grdview_AssociateDetails.DataSource = dt;
                grdview_AssociateDetails.DataBind();
                Session["SortedData"] = dt;
            }
        }

        protected void CancelEdit_AssociateDetails(object sender, GridViewCancelEditEventArgs e)
        {
            grdview_AssociateDetails.EditIndex = -1;
            if (Session["SortedData"] != null)
            {
                grdview_AssociateDetails.DataSource = Session["SortedData"] as DataTable;
                grdview_AssociateDetails.DataBind();
            }
            else
            {
                grdview_AssociateDetails_BindUserDetails();
            }
        }

        protected void EditRecord_AssociateDetails(object sender, GridViewEditEventArgs e)
        {
            grdview_AssociateDetails.EditIndex = e.NewEditIndex;
            if (Session["SortedData"] != null)
            {
                grdview_AssociateDetails.DataSource = Session["SortedData"] as DataTable;
                grdview_AssociateDetails.DataBind();
            }
            else
            {
                grdview_AssociateDetails_BindUserDetails();
            }
        }

        protected void RowDataBound(object sender, GridViewRowEventArgs e)
        {

            int editIndex = grdview_AssociateDetails.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && grdview_AssociateDetails.EditIndex == e.Row.RowIndex)
            {
                DropDownList status = (DropDownList)e.Row.FindControl("ddl_status");
                Label lbl = (Label)e.Row.FindControl("lbl_Status1");               
                status.Items.FindByText(lbl.Text).Selected = true;
            }
            else
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lbl1 = (Label)e.Row.FindControl("lbl_flag");
                    Label lbl2 = (Label)e.Row.FindControl("lbl_CTSID");
                    Label lbl3 = (Label)e.Row.FindControl("lbl_flag_TMPOC");
                    if (lbl3.Text == "0" || lbl1.Text == "0" || lbl2.Text == Convert.ToString(Session["loggedinuserID"]))
                    {
                        e.Row.Cells[10].Enabled = false;
                        if (lbl2.Text == Convert.ToString(Session["loggedinuserID"]))
                            e.Row.Cells[10].ToolTip = "Self Data cannot be edited";
                        else if (lbl1.Text == "0")
                            e.Row.Cells[10].ToolTip = "TM POCs are mapped under this user, status cannot be edited";
                        else if (lbl3.Text == "0")
                            e.Row.Cells[10].ToolTip = "User is mapped to an Account-Facility combination";
                    }
                }
        }

        protected void UpdateRecord_AssociateDetails(object sender, GridViewUpdateEventArgs e)
        {

            flag = "edit";
            string statusID = ((DropDownList)grdview_AssociateDetails.Rows[e.RowIndex].FindControl("ddl_Status")).SelectedValue;
            GridViewRow row = grdview_AssociateDetails.Rows[e.RowIndex];
            Label lbl = (Label)row.FindControl("lbl_CTSID");
            Label lbl_FN = (Label)row.FindControl("lbl_FName");
            Label lbl_LN = (Label)row.FindControl("lbl_LName");
            Label lbl_mail = (Label)row.FindControl("lbl_mailID");
           
            usrdetails.CognizantID = lbl.Text;
            usrdetails.FirstName = lbl_FN.Text;
            usrdetails.LastName = lbl_LN.Text;
            usrdetails.EmailID = lbl_mail.Text;
            usrdetails.CreatedBy = Session["loggedinUserid"].ToString();
            usrdetails.ModifiedBy = Session["loggedinUserid"].ToString();

            if (statusID == "0")
            { usrdetails.IsActive = "Y"; }
            else
            { usrdetails.IsActive = "N"; }

            string result = usrconfigBAL.Manageuser(usrdetails, flag);
            if (result.Contains(';'))
                ShowUserMessage(result.Split(';')[0], result.Split(';')[1]);
            else
                ShowUserMessage("error", result);
            grdview_AssociateDetails.EditIndex = -1;            
            if (result.Split(';')[0] == "success")
            {
                DataTable dt = new DataTable();
                dt = usrconfigBAL.BindUserDetails();
                grdview_AssociateDetails.DataSource = dt;
                Session["UserTable"] = dt;
            }
            if(null!=ViewState["SortExpression"])
            ApplySort();
            if (Session["SortedData"] != null)
            {
                grdview_AssociateDetails.DataSource = Session["SortedData"] as DataTable;
                grdview_AssociateDetails.DataBind();
                grdview_AssociateDetails.PageIndex = Convert.ToInt32(Session["pid"]);
            }
            else
            {
                RefreshGrids();
            }
            BindAll();
        }

        protected void chkboxlist_Roles_BindRoles()
        {
            try
            {
                DataTable dt = new DataTable();
                dt = usrconfigBAL.BindRoles();
                chkboxlist_Roles.DataSource = dt;
                chkboxlist_Roles.DataTextField = "RoleName";
                chkboxlist_Roles.DataValueField = "RoleID";
                chkboxlist_Roles.DataBind();
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void Btn_SaveRole_Click(object sender, EventArgs e)
        {
            flag = "save";
            string SelectedUsers = null;
            string SelectedRoles = null;
            string result = null;
            foreach (ListItem i in chkboxlist_users.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(SelectedUsers))
                {
                    SelectedUsers = i.Value;
                }
                else
                {
                    SelectedUsers = SelectedUsers + "," + i.Value;
                }
            }
            foreach (ListItem i in chkboxlist_Roles.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(SelectedRoles))
                {
                    SelectedRoles = i.Value;
                }
                else
                {
                    SelectedRoles = SelectedRoles + "," + i.Value;
                }
            }
            roledetails.Roles = SelectedRoles;
            roledetails.Users_Role = SelectedUsers;
            roledetails.CreatedBy = Session["loggedinUserid"].ToString();
            roledetails.ModifiedBy = Session["loggedinUserid"].ToString();
            result = usrconfigBAL.RoleMapping(roledetails, flag);
            if (result.Contains(';'))
            {
                ShowUserMessage_roles(result.Split(';')[0], result.Split(';')[1]);
                if (result.Split(';')[0] == "success")
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "ResetControls", "resetControls();", true);
                    RefreshGrids();
                    BindAll();
                }
            }


        }

        protected void Button_Save_Click(object sender, EventArgs e)
        {
            string selectedTMPOCs = null;
            string selectedTMLead = ddl_TMleads.SelectedValue;
            foreach (ListItem i in chkbox_unmappedusers.Items.Cast<ListItem>().Where(x => x.Selected))
            {

                if (string.IsNullOrEmpty(selectedTMPOCs))
                {
                    selectedTMPOCs = i.Value;
                }
                else
                {
                    selectedTMPOCs = selectedTMPOCs + "," + i.Value;
                }

            }
            POCLeadMappingdetails.TMPOCs = selectedTMPOCs;
            POCLeadMappingdetails.TMLead = selectedTMLead;
            POCLeadMappingdetails.CreatedBy = Session["loggedinUserid"].ToString();
            POCLeadMappingdetails.ModifiedBy = Session["loggedinUserid"].ToString();
            string action = "save";
            string result = usrconfigBAL.POCLeadMapping(POCLeadMappingdetails, action);
            if (result.Contains(';'))
            {
                ShowUserMessage_lead(result.Split(';')[0], result.Split(';')[1]);
                if (result.Split(';')[0] == "success")
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "ResetControls", "resetControls();", true);
                    RefreshGrids();
                    BindAll();
                }
            }
        }

        protected void chkboxlist_location_bind()
        {
            DataSet ds = new DataSet();

            ds = usrconfigBAL.bindlocations();
            if (ds.Tables[0].Rows.Count == 0)
            {
                Message4.Visible = true;
            }

            chkboxlist_location.DataSource = ds;
            chkboxlist_location.DataTextField = "Location";
            chkboxlist_location.DataValueField = "ID";
            chkboxlist_location.DataBind();

        }

        protected void grdview_userrolemapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdview_userrolemapping.PageIndex = e.NewPageIndex;
            grdview_userrolemapping.EditIndex = -1;
            grdview_userrolemapping_bind();
        }

        protected void grdview_userrolemapping_RowEditing(object sender, GridViewEditEventArgs e)
        {

            grdview_userrolemapping.EditIndex = e.NewEditIndex;
            grdview_userrolemapping_bind();
        }

        protected void grdview_userrolemapping_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            flag = "update";            
            GridViewRow grd = grdview_userrolemapping.Rows[e.RowIndex];
            CheckBoxList chk = (CheckBoxList)grd.FindControl("chkbox_userRoles");
            string store = "";
            string result = null;
            foreach (ListItem li in chk.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(store))
                {
                    store = li.Value;
                }
                else
                {
                    store = store + "," + li.Value;
                }
            }
            if (string.IsNullOrEmpty(store))
            {
                result = "error; User should be configured with atleast one role";
            }
            else
            {
                Label lbl_ID = (Label)grd.FindControl("lbl_CogniID");
                roledetails.Roles = store;
                roledetails.Users_Role = lbl_ID.Text;
                roledetails.CreatedBy = Session["loggedinUserid"].ToString();
                roledetails.ModifiedBy = Session["loggedinUserid"].ToString();
                result = usrconfigBAL.RoleMapping(roledetails, flag);
                grdview_userrolemapping.EditIndex = -1;
                RefreshGrids();
                chkboxlist_Roles_BindRoles();
                BindAll();
            }
            if (result.Contains(';'))
            {
                ShowUserMessage_roles(result.Split(';')[0], result.Split(';')[1]);
            }
        }

        protected void grdview_userrolemapping_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdview_userrolemapping.EditIndex = -1;
            grdview_userrolemapping_bind();
        }

        protected void grdview_userrolemapping_bind()
        {
            DataSet ds = new DataSet();
            ds = usrconfigBAL.userrolesgridbind();
            grdview_userrolemapping.DataSource = ds.Tables[0];
            grdview_userrolemapping.DataBind();

        }

        protected void grdview_userrolemapping_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = grdview_userrolemapping.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && grdview_userrolemapping.EditIndex == e.Row.RowIndex)
            {
                CheckBoxList CBL = (CheckBoxList)e.Row.FindControl("chkbox_userRoles");
                Label lbl = (Label)e.Row.FindControl("lbl_roles_dummy");
                Label lbl2 = (Label)e.Row.FindControl("lbl_flag");
                Label lbl_TMPOcmapping = (Label)e.Row.FindControl("lbl_TMPOCMapping");
                string[] roles = lbl.Text.Split(',');
                foreach (string role in roles)
                {   
                    CBL.Items.FindByText(role).Selected = true;
                }
                if (lbl2.Text == "0")
                {
                    CBL.Items[2].Enabled = false;
                    CBL.Items[2].Attributes["title"] = "TM POCs are mapped under this user, TMLead Role cannot be edited";
                }
                if (lbl_TMPOcmapping.Text.ToString().ToUpper() == "Y")
                {
                    CBL.Items[1].Enabled = false;
                    CBL.Items[1].Attributes["title"] = "TM POCs are mapped to an account, TMPOC Role cannot be edited";
                }
            }
            else
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lbl1 = (Label)e.Row.FindControl("lbl_CogniID");
                    if (lbl1.Text == Convert.ToString(Session["loggedinuserID"]))
                    {
                        e.Row.Cells[8].Enabled = false;
                        e.Row.Cells[8].ToolTip = "Self Data cannot be edited";
                    }
                }
        }

        protected void grdview_POCLeadmapping_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = grdview_POCLeadmapping.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && grdview_POCLeadmapping.EditIndex == e.Row.RowIndex)
            {
                Label lbl_Lead = (Label)e.Row.FindControl("lbl_LeadID");
                DropDownList ddl = (DropDownList)e.Row.FindControl("ddl_TMLeads_update");
                DataSet ds = new DataSet();
                ds = usrconfigBAL.GetUnmappedUsers(Convert.ToString(Session["loggedinuserID"]));
                ddl.DataSource = ds.Tables[2];
                ddl.DataValueField = "AssociateID";
                ddl.DataTextField = "Associate";
                ddl.DataBind();
                ddl.Items.FindByValue(lbl_Lead.Text).Selected = true;
            }
            else
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lbl1 = (Label)e.Row.FindControl("lbl_POCID");
                    if (lbl1.Text == Convert.ToString(Session["loggedinuserID"]))
                    {
                        e.Row.Cells[6].Enabled = false;
                        e.Row.Cells[7].Enabled = false;
                        e.Row.Cells[6].ToolTip = "Self Data cannot be edited";
                        e.Row.Cells[7].ToolTip = "Self Data cannot be deleted";
                    }
                }
        }

        protected void grdview_POCLeadmapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdview_POCLeadmapping.PageIndex = e.NewPageIndex;
            grdview_POCLeadmapping.EditIndex = -1;
            grdview_POCLeadmapping_bind();
        }

        protected void grdview_POCLeadmapping_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdview_POCLeadmapping.EditIndex = e.NewEditIndex;
            grdview_POCLeadmapping_bind();
        }

        protected void grdview_POCLeadmapping_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string action = "update";
            GridViewRow grd = grdview_POCLeadmapping.Rows[e.RowIndex];
            DropDownList ddl = (DropDownList)grd.FindControl("ddl_TMLeads_update");
            Label lbl_POC = (Label)grd.FindControl("lbl_POCID");
            POCLeadMappingdetails.TMPOCs = lbl_POC.Text;
            POCLeadMappingdetails.TMLead = ddl.SelectedValue;
            POCLeadMappingdetails.CreatedBy = Session["loggedinuserID"].ToString();
            POCLeadMappingdetails.ModifiedBy = Session["loggedinuserID"].ToString();
            string result = usrconfigBAL.POCLeadMapping(POCLeadMappingdetails, action);
            if (result.Contains(';'))
            {
                ShowUserMessage_lead(result.Split(';')[0], result.Split(';')[1]);
            }
            grdview_POCLeadmapping.EditIndex = -1;
            RefreshGrids();
        }

        protected void grdview_POCLeadmapping_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdview_POCLeadmapping.EditIndex = -1;
            grdview_POCLeadmapping_bind();
        }

        protected void grdview_POCLeadmapping_bind()
        {
            DataSet ds = new DataSet();
            ds = usrconfigBAL.POCLeadMappingGrdBind();
            grdview_POCLeadmapping.DataSource = ds.Tables[0];
            grdview_POCLeadmapping.DataBind();
        }

        protected void BindAll()
        {
            try
            {

                DataSet ds = new DataSet();
                ds = usrconfigBAL.GetUnmappedUsers(Convert.ToString(Session["loggedinuserID"]));

                //bind users who are not configured with any roles(newly added)
                if (ds.Tables[0].Rows.Count != 0)
                {
                    chkboxlist_users.DataSource = ds.Tables[0];
                    chkboxlist_users.DataTextField = "Associate";
                    chkboxlist_users.DataValueField = "AssociateID";
                    chkboxlist_users.DataBind();
                    trNoUsersForRoleMapping.Visible = false;
                    tbl_rolemapping.Visible = true;
                    lblMessage.Visible = false;
                    UserList.Visible = true;
                }
                else
                {
                    UserList.Visible = false;
                    trNoUsersForRoleMapping.Visible = true;
                    tbl_rolemapping.Visible = false;
                }
                //bind TMPOCs who are not mapped to a TMLead
                if ((ds.Tables[1] != null && ds.Tables[1].Rows.Count == 0) || (ds.Tables[2] != null && ds.Tables[2].Rows.Count == 0))
                {
                    trTmLeadMessageNoUsers.Visible = true;
                    trTmLeadMapping.Visible = false;
                    tr_buttons.Visible = false;
                }
                else if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0 && ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                {
                    //bind TMPOC users
                    chkbox_unmappedusers.DataSource = ds.Tables[1];
                    chkbox_unmappedusers.DataValueField = "AssociateID";
                    chkbox_unmappedusers.DataTextField = "Associate";
                    chkbox_unmappedusers.DataBind();

                    //bind TMLeads
                    ddl_TMleads.DataSource = ds.Tables[2];
                    ddl_TMleads.DataTextField = "Associate";
                    ddl_TMleads.DataValueField = "AssociateID";
                    ddl_TMleads.DataBind();

                    //disable error messages

                    trTmLeadMessageNoUsers.Visible = false;
                    Message2.Visible = false;
                    unmappeduserlist.Visible = true;
                    trTmLeadMapping.Visible = true;
                    tr_buttons.Visible = true;

                }
                
                //bind users who are added into the tool but not mapped to location
                if (ds.Tables[3] != null && ds.Tables[3].Rows.Count > 0 && chkboxlist_location.Items.Count>0)
                {
                    chkbox_users_loc.DataSource = ds.Tables[3];
                    chkbox_users_loc.DataValueField = "AssociateID";
                    chkbox_users_loc.DataTextField = "Associate";
                    chkbox_users_loc.DataBind();
                    dvLocationMain.Visible = true;
                    tr_NoUsersLocation.Visible = false;
                    Message3.Visible = false;
                    userlist_location.Visible = true;
                }
                else
                {
                    dvLocationMain.Visible = false;
                    tr_NoUsersLocation.Visible = true;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void grdview_POCLeadmapping_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string action = "delete";
            GridViewRow grd = grdview_POCLeadmapping.Rows[e.RowIndex];

            Label POCID = (Label)grd.FindControl("lbl_POCID");
            Label LeadID = (Label)grd.FindControl("lbl_LeadID");
            POCLeadMappingdetails.TMPOCs = POCID.Text;
            POCLeadMappingdetails.TMLead = LeadID.Text;
            POCLeadMappingdetails.CreatedBy = Session["loggedinuserid"].ToString();
            string result = usrconfigBAL.POCLeadMapping(POCLeadMappingdetails, action);
            ShowUserMessage_lead(result.Split(';')[0], result.Split(';')[1]);
            grdview_POCLeadmapping.EditIndex = -1;
            RefreshGrids();
            BindAll();
        }

        protected void btn_save_locmapping_Click(object sender, EventArgs e)
        {
            string action = "save";
            string selectedusers = null;
            string selectedlocations = null;
            foreach (ListItem li in chkbox_users_loc.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(selectedusers))
                {
                    selectedusers = li.Value;
                }
                else
                {
                    selectedusers = selectedusers + "," + li.Value;
                }
            }
            foreach (ListItem li in chkboxlist_location.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(selectedlocations))
                {
                    selectedlocations = li.Value;
                }
                else
                {
                    selectedlocations = selectedlocations + "," + li.Value;
                }
            }
            locdetails.User_Location = selectedusers;
            locdetails.CreatedBy = Session["loggedinuserid"].ToString();
            locdetails.ModifiedBy = Session["loggedinuserid"].ToString();
            locdetails.Location = selectedlocations;
            string result = usrconfigBAL.LocationMapping(locdetails, action);
            if (result.Contains(';'))
            {
                ShowUserMessage_loc(result.Split(';')[0], result.Split(';')[1]);
                if (result.Split(';')[0] == "success")
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "ResetControls", "resetControls();", true);
                    RefreshGrids();
                    BindAll();
                }
            }
        }

        protected void btn_Reset_Click(object sender, EventArgs e)
        {
            ResetControls();
            txt_CognizantID.Text = string.Empty;
        }

        protected void ResetControls()
        {
            txt_FirstName.Text = string.Empty;
            txt_LastName.Text = string.Empty;
            txt_EmailID.Text = string.Empty;

        }

        private string GetSortDirection(string column)
        {
            // By default, set the sort direction to ascending.
            string sortDirection = "ASC";
            // Retrieve the last column that was sorted.
            string sortExpression = ViewState["SortExpression"] as string;
            if (sortExpression != null)
            {
                // Check if the same column is being sorted.
                // Otherwise, the default value can be returned.
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }
            // Save new values in ViewState.
            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;
            return sortDirection;
        }

        protected void reset_roles_Click(object sender, EventArgs e)
        {
            txtbox_Search.Text = string.Empty;
            lblMessage.Visible = false;
            BindAll();
        }

        protected void Img_search_role_Click(object sender, ImageClickEventArgs e)
        {
            if (string.IsNullOrEmpty(txtbox_Search.Text.Trim()))
            {
                ShowUserMessage_roles("error", "Please search with a user ID");
            }
            else
            {
                DataTable dt = usrconfigBAL.SearchUnmappedUsers(txtbox_Search.Text, "role");

                if (dt != null && dt.Rows.Count > 0)
                {
                    chkboxlist_users.DataSource = dt;
                    chkboxlist_users.DataTextField = "Associate";
                    chkboxlist_users.DataValueField = "AssociateID";
                    chkboxlist_users.DataBind();
                    lblMessage.Visible = false;
                    UserList.Visible = true;
                }
                else
                {
                    lblMessage.Visible = true;
                    UserList.Visible = false;
                }
            }
        }

        protected void img_srch_lead_Click(object sender, ImageClickEventArgs e)
        {
            DataTable dt = usrconfigBAL.SearchUnmappedUsers(txtbox_searchuser.Text, "lead");

            if (dt != null && dt.Rows.Count > 0)
            {
                chkbox_unmappedusers.DataSource = dt;
                chkbox_unmappedusers.DataTextField = "Associate";
                chkbox_unmappedusers.DataValueField = "AssociateID";
                chkbox_unmappedusers.DataBind();
                Message2.Visible = false;
                unmappeduserlist.Visible = true;
            }
            else
            {
                Message2.Visible = true;
                unmappeduserlist.Visible = false;
            }
        }

        protected void img_searchuser_loc_Click(object sender, ImageClickEventArgs e)
        {
            DataTable dt = usrconfigBAL.SearchUnmappedUsers(txtbox_searchuser_loc.Text, "location");

            if (dt != null && dt.Rows.Count > 0)
            {
                chkbox_users_loc.DataSource = dt;
                chkbox_users_loc.DataTextField = "Associate";
                chkbox_users_loc.DataValueField = "AssociateID";
                chkbox_users_loc.DataBind();
                Message3.Visible = false;
                userlist_location.Visible = true;
            }
            else
            {
                Message3.Visible = true;
                userlist_location.Visible = false;
            }
        }

        protected void txtbox_Search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtbox_Search.Text.Trim()))
            {
                BindAll();
                lblMessage.Visible = false;
                UserList.Visible = true;
            }
        }

        protected void txtbox_searchuser_loc_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtbox_searchuser_loc.Text.Trim()))
            {
                BindAll();
                Message3.Visible = false;
                userlist_location.Visible = true;
            }
        }

        protected void txtbox_searchuser_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtbox_searchuser.Text.Trim()))
            {
                BindAll();
                Message2.Visible = false;
                unmappeduserlist.Visible = true;
            }
        }

        protected void btn_resetLead_Click(object sender, EventArgs e)
        {
            BindAll();
        }

        protected void GV_UserLocMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GV_UserLocMapping.PageIndex = e.NewPageIndex;
            GV_UserLocMapping.EditIndex = -1;
            GV_UserLocMappingBind();
        }

        protected void GV_UserLocMappingBind()
        {
            DataTable dt = new DataTable();
            dt = usrconfigBAL.BindUserLocationMappingDetails();
            GV_UserLocMapping.DataSource = dt;
            GV_UserLocMapping.DataBind();
        }

        protected void GV_UserLocMapping_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            int editIndex = GV_UserLocMapping.EditIndex;
            if (editIndex != -1 && e.Row.RowType == DataControlRowType.DataRow && GV_UserLocMapping.EditIndex == e.Row.RowIndex)
            {
                CheckBoxList chk = (CheckBoxList)e.Row.FindControl("chkboxlist_locedit");
                DataSet ds = new DataSet();
                ds = usrconfigBAL.bindlocations();
                chk.DataSource = ds.Tables[0];
                chk.DataValueField = "ID";
                chk.DataTextField = "Location";
                chk.DataBind();
                HiddenField hdn = (HiddenField)e.Row.FindControl("hdn_LocationIds");
                HiddenField hdn_POCLocationID = (HiddenField)e.Row.FindControl("hdn_POCLocationID");
                 Label lblflag = (Label)e.Row.FindControl("lbl_Userflag");
                if (!string.IsNullOrEmpty(hdn.Value))
                {
                    foreach (string val in hdn.Value.Split(','))
                    {
                        chk.Items.FindByValue(val).Selected = true;
                    }
                }
                if (lblflag.Text.ToString().ToUpper() == "Y")
                {
                    if (!string.IsNullOrEmpty(hdn_POCLocationID.Value))
                    {
                        foreach (string val in hdn_POCLocationID.Value.Split(','))
                        {
                            chk.Items.FindByValue(val).Enabled = false;
                            chk.Items.FindByValue(val).Attributes["title"] = "TM POC is mapped to an account under this location, cannot be uncheked";
                        }
                    }
                }
            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblflag = (Label)e.Row.FindControl("lbl_Userflag");
                    HiddenField hd_associateID = (HiddenField)e.Row.FindControl("hdn_AssociateID");
                    
                    CheckBoxList chk = (CheckBoxList)e.Row.FindControl("chkboxlist_locedit");
                    if (lblflag.Text.ToString().ToUpper() == "Y")
                    {
                        e.Row.Cells[4].Enabled = false;
                        e.Row.Cells[4].ToolTip = "TM POC is mapped to an account under mapped locations, cannot be deleted";                        
                    }
                    else if (hd_associateID.Value == Convert.ToString(Session["loggedinuserID"]))
                    {
                        e.Row.Cells[3].Enabled = false;
                        e.Row.Cells[3].ToolTip = "Self Data cannot be edited";
                        e.Row.Cells[4].Enabled = false;
                        e.Row.Cells[4].ToolTip = "Self Data cannot be deleted";
                    }
                    else
                    {
                        e.Row.Cells[4].Enabled = true;
                        e.Row.Cells[4].ToolTip = "Delete";
                    }
                }
            }            
        }

        protected void GV_UserLocMapping_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow grd = GV_UserLocMapping.Rows[e.RowIndex];
            CheckBoxList chkboxlist_locedit = (CheckBoxList)grd.FindControl("chkboxlist_locedit");
            string selectedlocations = string.Empty;
            string result = string.Empty;
            foreach (ListItem li in chkboxlist_locedit.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(selectedlocations))
                {
                    selectedlocations = li.Value;
                }
                else
                {
                    selectedlocations = selectedlocations + "," + li.Value;
                }
            }
            if (string.IsNullOrEmpty(selectedlocations))
            {
               result = "error; User should be configured with atleast one Location";
            }
            else
            {
                HiddenField hdn = (HiddenField)grd.FindControl("hdn_AssociateID");
                locdetails.User_Location = hdn.Value;
                locdetails.Location = selectedlocations;
                locdetails.CreatedBy = Session["loggedinuserid"].ToString();
                locdetails.ModifiedBy = Session["loggedinuserid"].ToString();
                result = usrconfigBAL.LocationMapping(locdetails, "update");
                
                GV_UserLocMapping.EditIndex = -1;
                GV_UserLocMappingBind();
            }
            if (result.Contains(';'))
            {
                ShowUserMessage_loc(result.Split(';')[0], result.Split(';')[1]);
            }
            
        }

        protected void GV_UserLocMapping_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GV_UserLocMapping.EditIndex = -1;
            GV_UserLocMappingBind();
        }

        protected void GV_UserLocMapping_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GV_UserLocMapping.EditIndex = e.NewEditIndex;
            GV_UserLocMappingBind();
        }

        protected void GV_UserLocMapping_Delete(object sender, GridViewDeleteEventArgs e)
        {
            string action = "delete";
            UserLocationMappingDetails locdetails = new UserLocationMappingDetails();
            GridViewRow grd = GV_UserLocMapping.Rows[e.RowIndex];
            HiddenField hdnv = (HiddenField)grd.FindControl("hdn_AssociateID");
            HiddenField hdnlocn = (HiddenField)grd.FindControl("hdn_LocationIds");
            locdetails.User_Location = hdnv.Value;
            locdetails.Location = hdnlocn.Value;
            locdetails.ModifiedBy = Session["loggedinuserid"].ToString();
            locdetails.CreatedBy = Session["loggedinuserid"].ToString();
            string result = usrconfigBAL.LocationMapping(locdetails, action);            
            if (!string.IsNullOrEmpty(result))
            {
                ShowUserMessage_loc(result.Split(';')[0], result.Split(';')[1]);
            }
            BindAll();
            GV_UserLocMappingBind();
        }

        protected void RefreshGrids()
        {
            grdview_AssociateDetails_BindUserDetails();
            grdview_userrolemapping_bind();
            grdview_POCLeadmapping_bind();
            GV_UserLocMappingBind();
        }

        protected void btn_reset_loc_Click(object sender, EventArgs e)
        {
            BindAll();
        }
    }
}