﻿using HRAssimilation.Business;
using System;
using System.Data;
using System.Linq;
using System.Web.UI;

namespace HRAssimilation.Pages
{
    public partial class HrAssimilationMaster : System.Web.UI.MasterPage
    {
        UserConfigurationBAL objUserConfig = new UserConfigurationBAL();
        Logger.Logger log = new Logger.Logger();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "styleMainMenu", "styleMainMenu();", true);
            if (string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
            {
                dvmenu.Style.Add("visibility", "hidden");
                //btnLogout.Visible = false;
                lbl_userName.Visible = false;
                userDetails.Visible = false;
                Roles.Visible = false;
                if (GetCurrentPageName() != "Login.aspx") 
                Response.Redirect("Login.aspx", true);                   
            }
            else
            {
                string role;
                if(Roles.Items.Count>1)
                Roles.Visible = true;
                role = Roles.SelectedValue;
                if (string.IsNullOrEmpty(role))
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(Session["role"])))
                    {
                        role = Session["role"].ToString();                        
                    }
                    else
                    {
                        role = "1";
                    }
                }
                //btnLogout.Visible = true;
                lbl_userName.Visible = true;
                userDetails.Visible = true;
                if (Session["loggedinUserName"] != null)
                {
                    lbl_userName.Text = Session["loggedinUserName"].ToString();
                }
                dvmenu.Style.Add("visibility", "visible");
                CheckPageAccess();
                ChangeMenu(role);
            }

        }
        protected void CheckPageAccess()
        {
            try
            {
                string currentPageName = GetCurrentPageName();
                if (currentPageName.ToLower() != "login.aspx")
                {
                    DataSet dsPages = objUserConfig.GetPagesACL();
                    DataRow dr = dsPages.Tables[0].Select("PageName = '" + currentPageName + "'").First();
                    if (!dr["Roles"].ToString().Contains(Session["role"].ToString()))
                    {
                        Response.Redirect("Dashboard.aspx", false);
                    }
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                Response.Redirect("Dashboard.aspx", false);
            }
        }
        public string GetCurrentPageName()
        {
            string Path = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
            System.IO.FileInfo Info = new System.IO.FileInfo(Path);
            string pageName = Info.Name;
            return pageName;
        } 
        protected void ChangeMenu(string roleid)
        {
            string role = roleid;
            Roles.SelectedValue = roleid;
            Session["role"]=role;
            
            if (role == "1")
            {
                Admin.Visible = true;
                TMPOC.Visible = false;
                TMLead.Visible = false;
                Analytics.Visible = false;
            }
            else
                if (role == "2")
                {
                    TMPOC.Visible = true;
                    TMLead.Visible = false;
                    Analytics.Visible = false;
                    Admin.Visible = false;
                }
                else
                    if (role == "3")
                    {
                        TMLead.Visible = true;
                        TMPOC.Visible = false;
                        Analytics.Visible = false;
                        Admin.Visible = false;
                    }
                    else
                        if (role == "4")
                        {
                            Analytics.Visible = true;
                            TMLead.Visible = false;
                            TMPOC.Visible = false;
                            Admin.Visible = false;
                        }            
        }
        protected void Roles_SelectedIndexChanged(object sender, EventArgs e)
        {
            string role;
            role = Roles.SelectedValue;
            ChangeMenu(role);
            Session["roleName"] = Roles.SelectedItem.Text;
            Response.Redirect("Dashboard.aspx", false);
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{            
        //    Response.Redirect("Logout.aspx?Action=Logout", false);
        //}

        protected void Button1_Click1(object sender, EventArgs e)
        {
            //do nothing
        }
    }
}