﻿using HRAssimilation.Business;
using HRAssimilation.Entity;
using System;
using System.Linq;
using System.Web.UI;

namespace HRAssimilation.Pages
{
    public partial class JARevoke : System.Web.UI.Page
    {
        Logger.Logger log = new Logger.Logger();
        /// <summary>
        /// Page_Load is used to retrieve all the details when navigated to the page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidateUserSession();
            if (!Page.IsPostBack)
            {
                dvUserMessage.Visible = false;
                tblmaster.Visible = false;
                dv_buttons.Visible = false;
            }
        }
        public void ValidateUserSession()
        {
            try
            {
                if (Session["loggedinUserid"] == null)
                {
                    Response.Redirect("Login.aspx", true);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        /// <summary>
        /// btn_search_Click retrieves the data of the searched user.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_search_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_srcassoid.Text.Trim()))
            {
                string userid = txt_srcassoid.Text.Trim();
                ShowDetails(userid);
            }
            else
            {
                tblmaster.Visible = false;
                dv_buttons.Visible = false;
                showUserMessage("error", "Please enter valid Associate ID");
            }

        }
        /// <summary>
        /// showUserMessage displays the success or failure message
        /// </summary>
        /// <param name="msgType"></param>
        /// <param name="message"></param>
        protected void showUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }
        /// <summary>
        /// ShowDetails displays all the details of the user
        /// </summary>
        /// <param name="userid"></param>
        protected void ShowDetails(string userid)
        {

            Session["associateID"] = userid;
            AssociateDetails objAssociateDetails = GetAssociateDetails(userid);
            if (Session["loggedinUserid"] != null)
            {
                if (objAssociateDetails != null)
                {
                    if (Session["loggedinUserid"].ToString().Equals(objAssociateDetails.TMPOC))
                    {
                        if (!string.IsNullOrEmpty(objAssociateDetails.Message))
                        {
                            string sMessage = objAssociateDetails.Message.ToString();
                            if (sMessage.Contains(';'))
                            {
                                Resetvalues();
                                showUserMessage(sMessage.Split(';')[0], sMessage.Split(';')[1]);
                                tblmaster.Visible = false;
                                dv_buttons.Visible = false;
                            }
                        }
                        else
                        {
                            dv_buttons.Visible = true;
                            tblmaster.Visible = true;
                            dvUserMessage.Visible = false;
                            AssociateDetails objJAdtls = UpdateJAdetails(userid);
                            bindUserDetails(objAssociateDetails);
                            BindJAdetails(objJAdtls);
                            if (objAssociateDetails.TerminataionStatus == "Resigned - Under notice period")
                            {
                                dv_buttons.Visible = true;
                            }
                            else if (objAssociateDetails.TerminataionStatus == "JA Raised - Yet to be terminated" && !rb_jarvkd_no.Checked)
                            {
                                dv_buttons.Visible = true;
                            }
                            else
                            {
                                dv_buttons.Visible = false;
                                tb_reasonforja.Enabled = false;
                            }
                        }
                    }
                    else
                    {
                        if (objAssociateDetails.AssociateID == null)
                            showUserMessage("error", "Please provide valid user id.");
                        else
                            showUserMessage("warning", "Unauthorized to view details");
                        tblmaster.Visible = false;
                        dv_buttons.Visible = false;
                    }
                }
                else
                {
                    showUserMessage("warning", "Unauthorized to view details");
                    tblmaster.Visible = false;
                    dv_buttons.Visible = false;
                }
            }
        }
        public AssociateDetails GetAssociateDetails(string associateID)
        {
            AssociateDetails objAssociateDetails = new AssociateDetails();
            try
            {
                UserOperationsBAL objUOP = new UserOperationsBAL();
                objAssociateDetails = objUOP.GetSearchUserDetails(associateID);
                return objAssociateDetails;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        /// <summary>
        /// disableJAControls helps in disabling the JA details when the status is other than JA
        /// </summary>
        protected void disableJAControls()
        {
            tbl_JADetails.Visible = false;
            tbl_resignation.Visible = true;
            dv_buttons.Visible = true;
        }
        /// <summary>
        /// enableJAControls helps in enabling the JA details when the status is JA
        /// </summary>
        protected void enableJAControls()
        {
            tbl_JADetails.Visible = true;
            tbl_resignation.Visible = false;
            dv_buttons.Visible = true;
        }
        /// <summary>
        /// bindUserDetails gets the user details on search.
        /// </summary>
        /// <param name="objAssociateDetails"></param>
        protected void bindUserDetails(AssociateDetails objAssociateDetails)
        {
            try
            {

                txt_assoid.Text = objAssociateDetails.AssociateID;
                tb_level.Text = objAssociateDetails.JobCodeDescription;
                txt_assoname.Text = objAssociateDetails.AssociateName;
                txt_gender.Text = objAssociateDetails.Gender;
                txt_doj.Text = objAssociateDetails.HireDate;
                txt_dateofresg.Text = objAssociateDetails.LastResignationDate;
                txt_dojarsd.Text = objAssociateDetails.LastJARaisedDate;
                txt_terminationstatus.Text = objAssociateDetails.TerminataionStatus;
                txt_terminationstatus.ToolTip = objAssociateDetails.TerminataionStatus;
                if (objAssociateDetails.TerminataionStatus.ToUpper().Contains("DAYS"))
                {
                    tbl_resignation.Visible = false;
                    tbl_JADetails.Visible = false;
                    dv_buttons.Visible = false;
                }

                else
                {
                    if (objAssociateDetails.TerminataionStatus == "JA Raised - Yet to be terminated")
                    {
                        enableJAControls();
                    }

                    else if (objAssociateDetails.TerminataionStatus == "JA Revoked")
                    {
                        tbl_resignation.Visible = false;
                        tb_reasonforja.Enabled = false;
                        rb_jarvkd_yes.Enabled = false;
                        rb_jarvkd_no.Enabled = false;
                        txt_jarvkddt.Enabled = false;
                        dv_buttons.Visible = false;
                    }

                    else if (objAssociateDetails.TerminataionStatus == "Resigned - Under notice period")
                    {
                        disableJAControls();
                    }
                    else if (objAssociateDetails.TerminataionStatus == "Out of Assimilation Scope")
                    {
                        tb_resrreason.Enabled = false;
                        rb_dscnmngr_yes.Enabled = false;
                        rb_dscnmngr_no.Enabled = false;
                        rb_rtndsnasso_yes.Enabled = false;
                        rb_rtndsnasso_no.Enabled = false;
                        txt_lwd.Enabled = false;
                        rb_lwduptdsys_yes.Enabled = false;
                        rb_lwduptdsys_no.Enabled = false;
                        tb_reasonforja.Enabled = false;
                        rb_jarvkd_yes.Enabled = false;
                        rb_jarvkd_no.Enabled = false;
                        txt_jarvkddt.Enabled = false;
                        dv_buttons.Visible = false;
                    }
                    if (objAssociateDetails.TerminataionStatus == "Terminated")
                    {
                        tb_resrreason.Enabled = false;
                        rb_dscnmngr_yes.Enabled = false;
                        rb_dscnmngr_no.Enabled = false;
                        rb_rtndsnasso_yes.Enabled = false;
                        rb_rtndsnasso_no.Enabled = false;
                        txt_lwd.Enabled = false;
                        rb_lwduptdsys_yes.Enabled = false;
                        rb_lwduptdsys_no.Enabled = false;
                        tb_reasonforja.Enabled = false;
                        rb_jarvkd_yes.Enabled = false;
                        rb_jarvkd_no.Enabled = false;
                        txt_jarvkddt.Enabled = false;
                        dv_buttons.Visible = false;

                    }

                }
                txt_rsgwithdrawstatus.Text = objAssociateDetails.ResignationWithdrawalStatus;
                if (objAssociateDetails.ResignationWithdrawalStatus.ToString().ToLower() == "yes")
                {
                    txt_rsgwithdrawstatus.Text = "Resignation withdrawn";
                }

                txt_withdrawldate.Text = objAssociateDetails.LastResignationWithdrawlDate;
                txt_latestews.Text = objAssociateDetails.EWSStatus;
                tb_accnt.Text = objAssociateDetails.AccountName;
                tb_lastmetdt.Text = objAssociateDetails.LastMetDate;
                tb_dysincogni.Text = objAssociateDetails.Tenure;
                tb_tmpoc.Text = objAssociateDetails.TMPOC;
                tb_loc.Text = objAssociateDetails.Location;
                tb_supervisorid.Text = objAssociateDetails.SupervisorID;
                tb_supname.Text = objAssociateDetails.SupervisorName;
                tb_vert.Text = objAssociateDetails.VerticalName;
                tb_resrreport.Text = objAssociateDetails.ResignataionReport;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        protected void Resetvalues()
        {
            txt_assoid.Text = "";
            txt_assoname.Text = "";
            txt_gender.Text = "";
            txt_doj.Text = "";
            txt_dateofresg.Text = "";
            txt_dojarsd.Text = "";
            txt_terminationstatus.Text = "";
            txt_rsgwithdrawstatus.Text = "";
            txt_withdrawldate.Text = "";
            txt_latestews.Text = "";
            tb_lastmetdt.Text = "";
            tb_dysincogni.Text = "";
            tb_tmpoc.Text = "";
            tb_loc.Text = "";
            tb_supervisorid.Text = "";
            tb_supname.Text = "";
            tb_vert.Text = "";
            tb_resrreport.Text = "";
            tb_resrreason.Text = "";
            txt_lwd.Text = "";
            tb_reasonforja.Text = "";
            txt_jarvkddt.Text = "";
            rb_dscnmngr_yes.Checked = false;
            rb_dscnmngr_no.Checked = false;
            rb_rtndsnasso_yes.Checked = false;
            rb_rtndsnasso_no.Checked = false;
            rb_lwduptdsys_yes.Checked = false;
            rb_lwduptdsys_no.Checked = false;
            rb_jarvkd_yes.Checked = false;
            rb_jarvkd_no.Checked = false;
        }


        /// <summary>
        /// UpdateJAdetails method updates the user Job Abandonment details
        /// </summary>
        /// <param name="AssociateID"></param>
        /// <returns></returns>
        protected AssociateDetails UpdateJAdetails(string AssociateID)
        {
            AssociateDetails objdtls = new AssociateDetails();
            try
            {
                UserOperationsBAL objUOP = new UserOperationsBAL();
                objdtls = objUOP.GetJAdttails(AssociateID);
                return objdtls;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        protected void BindJAdetails(AssociateDetails objJAdtls)
        {
            tb_resrreason.Text = objJAdtls.DetailedReasonforResignation;
            if (objJAdtls.LastWorkingDate != null && objJAdtls.LastWorkingDate.Contains("1900"))
                txt_lwd.Text = "";
            else
                txt_lwd.Text = objJAdtls.LastWorkingDate;

            tb_reasonforja.Text = objJAdtls.DetailedReasonforJA;
            txt_jarvkddt.Text = objJAdtls.JARevokedDate;

            if (objJAdtls.DiscussionwithManager.ToString().ToLower() == "yes")
            {
                rb_dscnmngr_yes.Checked = true;
                rb_dscnmngr_no.Checked = false;
            }
            else
                if (objJAdtls.DiscussionwithManager.ToString().ToLower() == "no")
                {
                    rb_dscnmngr_no.Checked = true;
                    rb_dscnmngr_yes.Checked = false;
                }
                else
                {
                    rb_dscnmngr_no.Checked = false;
                    rb_dscnmngr_yes.Checked = false;
                }
            if (objJAdtls.RetentionDiscussionwithAssociate.ToString().ToLower() == "yes")
            {
                rb_rtndsnasso_yes.Checked = true;
            }
            else
                if (objJAdtls.RetentionDiscussionwithAssociate.ToString().ToLower() == "no")
                {
                    rb_rtndsnasso_no.Checked = true;
                }
                else
                {
                    rb_rtndsnasso_no.Checked = false;
                    rb_rtndsnasso_yes.Checked = false;
                }
            if (objJAdtls.JARevoked.ToString().ToLower() == "yes")
            {
                rb_jarvkd_no.Checked = false;
                rb_jarvkd_yes.Checked = true;
                rb_jarvkd_no.Enabled = false;
                rb_jarvkd_yes.Enabled = false;
                txt_jarvkddt.Enabled = false;
                dv_buttons.Visible = false;
            }
            else
                if (objJAdtls.JARevoked.ToString().ToLower() == "no")
                {

                    txt_jarvkddt.Enabled = false;
                    rb_jarvkd_no.Checked = true;
                    rb_jarvkd_no.Enabled = false;
                    rb_jarvkd_yes.Enabled = false;
                    txt_jarvkddt.Text = "";
                    dv_buttons.Visible = false;
                }
                else
                {
                    rb_jarvkd_yes.Checked = false;
                    rb_jarvkd_no.Checked = false;
                }
            if (string.IsNullOrEmpty(objJAdtls.JARevoked))
            {
                rb_jarvkd_no.Checked = false;
                rb_jarvkd_yes.Checked = false;
            }
            if (objJAdtls.LastWorkingDayUpdatedinSystem.ToString().ToLower() == "yes")
            {
                rb_lwduptdsys_yes.Checked = true;
            }
            else
                if (objJAdtls.LastWorkingDayUpdatedinSystem.ToString().ToLower() == "no")
                {
                    rb_lwduptdsys_no.Checked = true;
                }
                else
                {
                    rb_lwduptdsys_yes.Checked = false;
                    rb_lwduptdsys_no.Checked = false;
                }

            dvUserMessage.Visible = false;
        }


        protected void btn_save_Click(object sender, EventArgs e)
        {

            try
            {
                UserOperationsBAL objUOP = new UserOperationsBAL();
                InsertorupdateinResignation objResgdtls = new InsertorupdateinResignation();
                objResgdtls.AssociateID = txt_assoid.Text.ToString();
                objResgdtls.CreatedBy = Convert.ToString(Session["loggedinUserid"]);
                string updatetype = string.Empty;
                if (tbl_resignation.Visible)
                {
                    objResgdtls.DetailedReasonforResignation = tb_resrreason.Text.ToString();
                    //Last working date
                    string slwd = txt_lwd.Text.ToString();
                    if (!string.IsNullOrEmpty(slwd))
                    {
                        DateTime objlwd = DateTime.Parse(slwd, System.Globalization.CultureInfo.InvariantCulture);
                        slwd = objlwd.ToString("MM/dd/yyyy");

                        objResgdtls.LastWorkingDate = slwd;
                    }
                    else
                        objResgdtls.LastWorkingDate = "";
                    if (rb_dscnmngr_no.Checked)
                    {
                        objResgdtls.DiscussionwithManager = "No";

                    }
                    else
                        if (rb_dscnmngr_yes.Checked)
                        {
                            objResgdtls.DiscussionwithManager = "Yes";
                        }

                    if (rb_rtndsnasso_yes.Checked)
                    {
                        objResgdtls.RetentionDiscussionwithAssociate = "Yes";

                    }
                    else
                        if (rb_rtndsnasso_no.Checked)
                        {
                            objResgdtls.RetentionDiscussionwithAssociate = "No";
                        }

                    if (rb_lwduptdsys_yes.Checked == true)
                    {
                        objResgdtls.LastworkingDayUpdatedinSystem = "Yes";
                    }
                    if (rb_lwduptdsys_no.Checked == true)
                    {
                        objResgdtls.LastworkingDayUpdatedinSystem = "No";
                    }
                    updatetype = "Resignation";
                }
                else if (tbl_JADetails.Visible)
                {
                    objResgdtls.DetailedReasonforJA = tb_reasonforja.Text.ToString();

                    //JARevokedate


                    if (rb_jarvkd_yes.Checked == true)
                    {
                        objResgdtls.Jarevoked = "Yes";
                        txt_jarvkddt.Enabled = true;
                    }
                    else if (rb_jarvkd_no.Checked == true)
                    {
                        objResgdtls.Jarevoked = "No";
                        txt_jarvkddt.Text = "";
                        txt_jarvkddt.Enabled = false;
                    }
                    else
                    {
                        objResgdtls.Jarevoked = "";                        
                    }

                    string sJARevokedDate = txt_jarvkddt.Text.ToString();
                    if (!string.IsNullOrEmpty(sJARevokedDate))
                    {
                        DateTime objjadate = DateTime.Parse(sJARevokedDate, System.Globalization.CultureInfo.InvariantCulture);
                        sJARevokedDate = objjadate.ToString("MM/dd/yyyy");
                        objResgdtls.JARevokedDate = sJARevokedDate;
                    }
                    else
                        objResgdtls.JARevokedDate = "";
                    if (txt_jarvkddt.Text.Trim() == "")
                    {
                        if (rb_jarvkd_yes.Checked == true)
                        {
                            showUserMessage("warning", "JA Revoked date is mandatory");
                            return;
                        }
                    }                   
                    updatetype = "JA";
                }

                string result = objUOP.InsertOrUpdateResignationDtls(objResgdtls, updatetype);
                if (result.Contains(';'))
                {

                    if (result.Contains("success"))
                    {
                        ShowDetails(txt_assoid.Text);                        
                    }
                    showUserMessage(result.Split(';')[0], result.Split(';')[1]);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);

            }
        }

        /// <summary>
        /// btn_clear_Click clears the data.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_clear_Click(object sender, EventArgs e)
        {
            AssociateDetails objAssociateDetails = GetAssociateDetails(Session["associateID"].ToString());
            UserOperationsBAL objUOP = new UserOperationsBAL();
            AssociateDetails objJAdtls = objUOP.GetJAdttails(Session["associateID"].ToString());

            bindUserDetails(objAssociateDetails);
            BindJAdetails(objJAdtls);
            if (objAssociateDetails.TerminataionStatus == "Resigned - Under notice period")
            {
                dv_buttons.Visible = true;
            }
            else if (objAssociateDetails.TerminataionStatus == "JA Raised - Yet to be terminated" && !rb_jarvkd_no.Checked)
            {
                dv_buttons.Visible = true;
            }
            else
            {
                dv_buttons.Visible = false;
            }
        }

        /// <summary>
        /// rb_jarvkd_yes_CheckedChanged makes the JA revoked date true.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rb_jarvkd_yes_CheckedChanged(object sender, EventArgs e)
        {
            txt_jarvkddt.Enabled = true;
        }

        /// <summary>
        /// rb_jarvkd_no_CheckedChanged disables the JA revoked date.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rb_jarvkd_no_CheckedChanged(object sender, EventArgs e)
        {
            txt_jarvkddt.Enabled = false;

        }

    }
}