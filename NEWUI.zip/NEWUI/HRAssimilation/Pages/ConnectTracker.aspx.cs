﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRAssimilation.Business;
using HRAssimilation.Entity;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Data.OleDb;
using HRAssimilation.Utility;

namespace HRAssimilation.Pages
{
    public partial class ConnectTracker : System.Web.UI.Page
    {
        TmpocConnectTrackMaping oTracking = new TmpocConnectTrackMaping();
        Constant objcons = new Constant();
        UserConfigurationBAL objUserOp = new UserConfigurationBAL();
        Logger.Logger log = new Logger.Logger();
        GridOperationsBAL gridOp = new GridOperationsBAL();
        string constr, Query, sqlconn;
        OleDbConnection Econ;
        protected void Page_Load(object sender, EventArgs e)
        {
            dvUserMessage.Visible = false;
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            try
            {
                if (!Page.IsPostBack)
                {
                    string TMPOC = Convert.ToString(Session["loggedinUserid"]);
                    if (string.IsNullOrEmpty(TMPOC))
                    {
                        Response.Redirect("Login.aspx", true);
                    }
                    rdb_manual.Checked = true;
                    tbl_bulkupload.Visible = false;
                    dvUserSelection.Visible = true;
                    tbl_oneonone.Visible = true;
                    tbl_OtherConnects.Visible = false;
                    dvConnectDetails.Visible = false;
                    dvUserMessage.Visible = false;
                    BindAssociates();
                    BindAcccountsunderTMPOC(TMPOC);
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void GetOtherConnectsAssociates()
        {

            try
            {
                txtGridSearch.Text = "";
                string sloginid = Session["loggedinUserid"].ToString();
                string connecttype = ddl_connectType.SelectedItem.Text;
                DataTable dt = objUserOp.BindOtherConnectUsers(sloginid, connecttype);
                dt.Columns.Remove("AccountID");
                ViewState["MappedUsers_OtherConnects"] = dt.Copy();
                Session["MappedUsers_OtherConnects"] = dt;
                gv_AssociateOtherConnects.DataSource = dt;
                gv_AssociateOtherConnects.DataBind();
                //gv_AssociateOtherConnects.Columns[9].Visible = false;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }

        protected void GridEwsStatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridEwsStatus.PageIndex = e.NewPageIndex;
            BindGrid();

        }

        protected void BindAssociates()
        {
            try
            {

                string sloginid = Session["loggedinUserid"].ToString();
                //gv_Associates.DataSource = objUserOp.userrolesgridbind();
                DataTable dt = objUserOp.BindUserRoleGrid(sloginid);
                ViewState["MappedUsers_OneOnOne"] = dt.Copy();
                dt.Columns.Remove("AccountID");
                Session["MappedUsers_OneOnOne"] = dt;
                gv_Associates.DataSource = dt;
                gv_Associates.DataBind();
                if (gv_Associates.Rows.Count == 0)
                {
                    btn_submit.Visible = false;
                    tbl_GridFilter.Visible = false;
                }
                else
                {
                    btn_submit.Visible = true;
                }
                //gv_Associates.Style.Add("word-wrap", "break-word");
                //gv_Associates.
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void gv_Associates_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void chkbox_associate_CheckedChanged(object sender, EventArgs e)
        {

            ToggleCheckState(false);
        }
        private void ToggleCheckState(bool checkState)
        {
            // Iterate through the Products.Rows property
            foreach (GridViewRow row in gv_Associates.Rows)
            {
                // Access the CheckBox
                CheckBox cb = (CheckBox)row.FindControl("chkbox_associate");
                if (cb != null)
                    cb.Checked = checkState;
            }
        }
        protected void resetFilters()
        {
            txtGridSearch.Text = "";
            ddlSearchBy.SelectedValue = "1";
            chkbx_Met.Checked = true;
            chkbx_NotMet.Checked = true;
            if (trAccounts.Visible && ListBox_Accounts.Items.Count > 0)
                ListBox_Accounts.SelectedIndex = 0;
        }
        protected void resetGridFilters()
        {
            txtGridSearch.Text = "";
            ddlSearchBy.SelectedValue = "1";
        }
        protected void ResetSelection()
        {
            try
            {
                resetFilters();
                tbl_OtherConnects.Visible = false;
                tbl_oneonone.Visible = false;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void ResetData()
        {
            try
            {
                resetFilters();

                if (ddl_connectType.SelectedValue != "1")
                {

                    GetOtherConnectsAssociates();
                    tbl_oneonone.Visible = true;
                    gv_Associates.Visible = false;
                    gv_AssociateOtherConnects.Visible = true;
                    tbl_OtherConnects.Visible = true;
                    btn_OtherConnects.Visible = true;
                    btn_submit.Visible = false;
                    trGroupComments.Visible = true;
                    txt_GroupConnectComments.Text = "";
                    txt_GroupConnectDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
                }
                else
                {
                    BindAssociates();
                    gv_Associates.Visible = true;
                    gv_AssociateOtherConnects.Visible = false;
                    tbl_oneonone.Visible = true;
                    tbl_OtherConnects.Visible = false;
                    btn_OtherConnects.Visible = false;
                    btn_submit.Visible = true;
                }


            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void ddl_connectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_connectType.SelectedItem.Text.ToLower().Contains("day 1") || ddl_connectType.SelectedItem.Text.ToLower().Contains("day 2"))
                trAccounts.Visible = false;
            else
                trAccounts.Visible = true;
            ResetSelection();
            switch (ddl_connectType.SelectedItem.Text)
            {
                case "One On One":
                case "Group connect":
                    if (ddl_AdditionalFilters.Items.FindByValue("High Priority Connect") == null)
                        ddl_AdditionalFilters.Items.Add(new ListItem("High Priority Connect"));
                    break;
                case "Day 1 connect":
                case "Day 2 connect":
                case "Prerna":
                case "Skip meeting":
                case "Floor session":
                case "Other connects":
                    if (ddl_AdditionalFilters.Items.FindByValue("High Priority Connect") != null)
                        ddl_AdditionalFilters.Items.Remove(ddl_AdditionalFilters.Items.FindByText("High Priority Connect"));
                    break;
                default:
                    ddl_AdditionalFilters.Items.Clear();
                    break;
            }
            ddl_AdditionalFilters.ClearSelection();
            ddl_AdditionalFilters.Items.FindByValue("0").Selected = true;
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                bool bFlag = true;
                int a = gv_Associates.PageIndex;
                //Loop through All Pages
                for (int i = 0; i < gv_Associates.PageCount; i++)
                {
                    //Set Page Index
                    gv_Associates.SetPageIndex(i);
                    //After Setting Page Index Loop through its Rows
                    for (int j = 0; j < gv_Associates.Rows.Count; j++) //Check if item is selected  
                    {
                        if (((RadioButton)gv_Associates.Rows[j].FindControl("rdb_selectedAssociate")).Checked) //If selected            
                        {
                            bFlag = false;
                            string associateid = gv_Associates.Rows[j].Cells[1].Text;
                            AssociateDetails objAssociateDetails = GetAssociateDetails(associateid);
                            ConnectEWSDetails objConnectewsdtls = GetConnectdtls(associateid);
                            bindUserDetails(objAssociateDetails);
                            //bindStausfield(associateid);
                            BindConnectAndEWSDtls(objConnectewsdtls);
                            string status = txt_status.Text.ToString();
                            tbl_connectsMaster.Visible = false;
                            dvUserSelection.Visible = false;
                            dvConnectDetails.Visible = true;
                            if (status.ToLower().Equals("resigned - under notice period") || status.ToLower().Equals("ja raised - yet to be terminated"))
                            {
                                tblRJcomments.Visible = true;
                                tbl_EWSgen.Visible = false;
                                tbl_btn_Scope.Visible = false;
                                txtRJcomments.InnerText = "";
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + "Associate status is " + status + ". EWS reporting is disabled." + "', 'information');", true);
                            }
                            else
                            {
                                BindGrid();
                                ResetGridvalues();
                                tbl_EWSgen.Visible = true;
                                tblRJcomments.Visible = false;
                                tbl_btn_Scope.Visible = true;
                            }

                            break;
                        }
                    }
                }
                gv_Associates.SetPageIndex(a);
                if (bFlag)
                {
                    ShowAssociateMessage("error", "Please select any one Associate");
                }

                //for (int i = 0; i < gv_Associates.Rows.Count; i++) //Check if item is selected  
                //{
                //    if (((RadioButton)gv_Associates.Rows[i].FindControl("rdb_selectedAssociate")).Checked) //If selected            
                //    {
                //        string associateid = gv_Associates.Rows[i].Cells[1].Text;
                //        AssociateDetails objAssociateDetails = GetAssociateDetails(associateid);
                //        ConnectEWSDetails objConnectewsdtls = GetConnectdtls(associateid);
                //        bindUserDetails(objAssociateDetails);
                //        bindStausfield(associateid);
                //        BindConnectAndEWSDtls(objConnectewsdtls);
                //        ResetGridvalues();
                //        dvUserSelection.Visible = false;
                //        dvConnectDetails.Visible = true;
                //        break;
                //    }
                //}
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void returnBack()
        {
            dvUserSelection.Visible = true;
            dvConnectDetails.Visible = false;
            tbl_connectsMaster.Visible = true;
        }
        protected void btn_BackToTheConnectTracker(object sender, EventArgs e)
        {
            returnBack();
        }
        protected void bindUserDetails(AssociateDetails objAssociateDetails)
        {
            try
            {
                txt_assoid.Text = objAssociateDetails.AssociateID;
                txt_assoname.Text = objAssociateDetails.AssociateName;
                txt_designation.Text = objAssociateDetails.Designation;
                txt_gender.Text = objAssociateDetails.Gender;
                if (!string.IsNullOrEmpty(objAssociateDetails.DateOfBirth))
                {
                    DateTime dt = Convert.ToDateTime(objAssociateDetails.DateOfBirth);
                    txt_dob.Text = String.Format("{0:dd-MMM}", dt);
                }
                else
                    txt_dob.Text = objAssociateDetails.DateOfBirth;
                txt_location.Text = objAssociateDetails.Location;
                txt_sublocation.Text = objAssociateDetails.SubLocation;
                txt_account.Text = objAssociateDetails.AccountName;
                txt_vertical.Text = objAssociateDetails.VerticalName;
                txt_supervisorid.Text = objAssociateDetails.SupervisorID;
                txt_supervisorname.Text = objAssociateDetails.SupervisorName;
                txt_dateofjoining.Text = objAssociateDetails.HireDate;
                txt_tenure.Text = objAssociateDetails.Tenure;
                txt_status.Text = objAssociateDetails.status;
                txt_status.ToolTip = Convert.ToString(objAssociateDetails.status);
                txt_TMPOCComment.InnerText = "";
                txt_connectdate.Text = DateTime.Now.ToString("MM/dd/yyyy");
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }

        }
        public AssociateDetails GetAssociateDetails(string associateID)
        {
            AssociateDetails objAssociateDetails = new AssociateDetails();
            try
            {
                UserOperationsBAL objUOP = new UserOperationsBAL();
                objAssociateDetails = objUOP.GetSelUserDetails(associateID);
                return objAssociateDetails;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }



        protected void rdb_selectedAssociate_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void btn_OtherConnects_Click(object sender, EventArgs e)
        {
            string selectedUsers = string.Empty;
            try
            {
                int a = gv_AssociateOtherConnects.PageIndex;
                if (SubmitAttendance())
                {
                    Session["CHECKED_ITEMS"] = null;
                    txt_GroupConnectComments.Text = "";
                    //GetOtherConnectsAssociates();
                    SelectAllinListBox();
                    chkbx_Met.Checked = true;
                    chkbx_NotMet.Checked = true;
                    ShowFilteredData();
                    gv_AssociateOtherConnects.SetPageIndex(a);
                    tbl_OtherConnects.Visible = true;
                    txt_GroupConnectDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
                    //Getting Back to the First State
                    //if (gv_AssociateOtherConnects.Rows.Count > 0)
                    //    gv_AssociateOtherConnects.SetPageIndex(0);
                }
                if (gv_AssociateOtherConnects.Rows.Count > 0)
                    btn_OtherConnects.Visible = true;
                else
                    btn_OtherConnects.Visible = false;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

        protected void SelectAllinListBox()
        {
            foreach (ListItem item in ListBox_Accounts.Items)
            {
                ListBox_Accounts.Items.FindByValue(item.Value).Selected = true;
            }
        }
        public bool SubmitAttendance()
        {
            string sSelConnectType = ddl_connectType.SelectedItem.Text.ToString();
            DataSet ds = new DataSet();
            ConnectTypedtls objConnecttypedtls = new ConnectTypedtls();
            List<ConnectTypedtls> lstConnecttypedtls = new List<ConnectTypedtls>();
            string selectedUserID = "";
            string selUserName = "";
            string email = "";
            string selectedEWS = "";
            bool bFlaag = true;
            DateTime Connectdate = Convert.ToDateTime(txt_GroupConnectDate.Text);
            DateTime DOJ;
            int a = gv_AssociateOtherConnects.PageIndex;
            //Loop through All Pages
            for (int i = 0; i < gv_AssociateOtherConnects.PageCount; i++)
            {
                //Set Page Index
                gv_AssociateOtherConnects.SetPageIndex(i);
                //After Setting Page Index Loop through its Rows
                for (int j = 0; j < gv_AssociateOtherConnects.Rows.Count; j++) //Check if item is selected  
                {
                    if (((CheckBox)gv_AssociateOtherConnects.Rows[j].FindControl("chk_user")).Checked) //If selected            
                    {
                        bFlaag = false;
                        selectedEWS = (ddl_connectType.SelectedItem.Text.ToLower() == "group connect") ? ((DropDownList)gv_AssociateOtherConnects.Rows[j].FindControl("ddl_EWS")).SelectedItem.Text : null;
                        //DOJ = Convert.ToDateTime(((Label)gv_AssociateOtherConnects.Rows[j].FindControl("Date of Joining")).Text);
                        DOJ = Convert.ToDateTime(gv_AssociateOtherConnects.Rows[j].Cells[4].Text);
                        if (DOJ > Connectdate)
                        {
                            ShowUserMessage("error", "Connect Date should be greater than or equal to Hire Date");
                            return false;
                        }
                        if (ddl_connectType.SelectedItem.Text.ToLower() == "group connect" && selectedEWS.ToLower() == "select")
                        {
                            ShowUserMessage("error", "Please Select valid EWS for associates selected");
                            return false;
                        }
                        else
                        {
                            selectedUserID = gv_AssociateOtherConnects.Rows[j].Cells[2].Text.ToString();
                            selUserName = gv_AssociateOtherConnects.Rows[j].Cells[3].Text.ToString();
                            //if (gv_AssociateOtherConnects.Rows[j].FindControl("Email") !=null)
                            //email = gv_AssociateOtherConnects.Rows[j].FindControl("Email").ToString();

                            email = gv_AssociateOtherConnects.Rows[j].Cells[10].Text.ToString();
                            lstConnecttypedtls.Add(new ConnectTypedtls
                            {
                                AssociateID = selectedUserID.ToString(),
                                AssociateName = selUserName.ToString(),
                                SelConnectType = sSelConnectType.ToString(),
                                SubmittedBy = Session["loggedinUserid"].ToString(),
                                Comments = txt_GroupConnectComments.Text,
                                ConnectDate = txt_GroupConnectDate.Text,
                                EWS = selectedEWS,
                                Email = email
                            });
                        }

                    }
                }
            }

            if (bFlaag)
            {
                ShowUserMessage("error", "Please Select Associates");
                gv_AssociateOtherConnects.SetPageIndex(a);
                return false;
            }
            else
            {
                string srslt = objUserOp.InsertConnectTypedtls(lstConnecttypedtls);
                if (srslt == "sucess")
                {
                    ShowUserMessage("success", "Attendance submitted successfully.");
                    // Send Survey Mail to Associates for day 2 connects
                    if (sSelConnectType.ToLower().Equals("day 2 connect"))
                    {
                        var emailIds = (from e in lstConnecttypedtls
                                        where e.Email != null
                                        select e.Email).ToArray();
                        string toEmailIds = string.Join(",", emailIds);
                        log.logInfo("Sending survey mail");
                        if (!SendSurveyMail(toEmailIds))
                        {
                            log.logInfo("Failed to send. Trying second attempt");
                            if (!SendSurveyMail(toEmailIds))
                            {
                                log.logInfo("Failed to send in second attempt. Trying final third attempt");
                                bool finalStatus = SendSurveyMail(toEmailIds);
                                return finalStatus;
                            }
                        }
                    }
                    return true;
                }
                return false;
            }
        }
        private bool SendSurveyMail(string toEmailIds)
        {
            log.logInfo("inside survey mail");
            MailService mailSvc = new MailService();
            return mailSvc.SendSurveyMail(toEmailIds);
        }
        protected void GridEwsStatus_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {

        }

        protected void grdquen_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
        public void BindGrid()
        {
            string sUserid = txt_assoid.Text;
            DataSet ds = objUserOp.POCGetQuestionconfig(sUserid);
            DataTable dt = new DataTable();
            if (ds != null)
            {
                dt = ds.Tables[0];
                Session["dt_QtWeightage"] = dt;
                GridEwsStatus.DataSource = ds.Tables[0];
                GridEwsStatus.DataBind();
                GridEwsStatus.Visible = true;
                if (GridEwsStatus.Rows.Count == 0)
                {
                    txt_EWSAutoGen.Enabled = false;
                    ddl_TLEws.Enabled = false;
                    btn_GenerateEWS.Enabled = false;
                }
                else
                {
                    bind_DropdownstoStatus(dt);
                    if (ds.Tables.Count == 2)
                    {
                        DataRow dr = null;
                        dr = ds.Tables[1].Rows[0];
                        ddl_TLEws.SelectedItem.Text = Convert.ToString(dr["TLEWS"]);
                        txt_EWSAutoGen.Text = Convert.ToString(dr["EWSStatus"]);
                        txt_TMPOCComment.InnerText = Convert.ToString(dr["TMPOCComment"]);
                    }
                    ddl_TLEws.Enabled = true;
                    btn_GenerateEWS.Enabled = true;
                }
            }
        }

        private void bind_DropdownstoStatus(DataTable dt)
        {
            for (int i = 0; i < GridEwsStatus.Rows.Count; i++)
            {

                DropDownList ddl = (DropDownList)GridEwsStatus.Rows[i].Cells[1].FindControl("ddl_EWSStatus");
                Label lbl_Questionid = (Label)GridEwsStatus.Rows[i].FindControl("lbl_QuestionID");
                int iQuestionid = Convert.ToInt32(lbl_Questionid.Text);
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr.RowState != DataRowState.Deleted)
                    {
                        if (!dr["EWSStatus"].ToString().Equals("") && !dr["EWSStatus"].ToString().Equals(String.Empty))
                        {
                            if (dr["QuestionID"].ToString() == Convert.ToString(iQuestionid))
                            {
                                ddl.SelectedItem.Text = dr["EWSStatus"].ToString();
                                ddl.SelectedValue = dr["EWSStatus"].ToString();
                                ddl.SelectedItem.Selected = true;
                            }
                        }
                    }
                }
            }
        }

        protected void GenerateSystemEWS()
        {
            int iRed = 0;
            int iGreen = 0;
            int iAmber = 0;
            bool AllRated = true;
            DataTable dtweightage = new DataTable();
            dtweightage = ((DataTable)Session["dt_QtWeightage"]);
            for (int i = 0; i < GridEwsStatus.Rows.Count; i++)
            {
                int iWeightage = 0;
                DropDownList ddl_EWSStatus = (DropDownList)GridEwsStatus.Rows[i].FindControl("ddl_EWSStatus");
                //lbl_QuestionID
                Label lbl_Questionid = (Label)GridEwsStatus.Rows[i].FindControl("lbl_QuestionID");


                DataRow[] dr = dtweightage.Select("QuestionID =" + Convert.ToInt32(lbl_Questionid.Text));
                if (dr != null && dr.Length > 0)
                {
                    iWeightage = Convert.ToInt32(dr[0]["Weightage"]);
                }
                if (ddl_EWSStatus.SelectedItem.ToString().ToLower() == "red")
                {
                    iRed += iWeightage;
                }
                else if (ddl_EWSStatus.SelectedItem.ToString().ToLower() == "green")
                {
                    iGreen += iWeightage;
                }
                else if (ddl_EWSStatus.SelectedItem.ToString().ToLower() == "amber")
                {
                    iAmber += iWeightage;
                }
                else { AllRated = false; }
            }
            //Generate EWS 
            if (AllRated)
            {
                if (iRed >= 50)
                {
                    txt_EWSAutoGen.Text = "Red";
                }
                else if (iGreen >= 90)
                {
                    txt_EWSAutoGen.Text = "Green";
                }
                else if ((iRed < 50 && iGreen < 90) || iAmber == 100)
                {
                    txt_EWSAutoGen.Text = "Amber";
                }
            }
            else
            {
                txt_EWSAutoGen.Text = "";
            }
        }
        protected void btn_GenerateEWS_Click(object sender, EventArgs e)
        {
            GenerateSystemEWS();
        }

        protected void btn_SaveOrSubmitConnectTrack(object sender, EventArgs e)
        {
            try
            {
                int IsSubmitted = 0;
                if (GridEwsStatus.Rows.Count == 0)
                {
                    dvMessage.Visible = true;
                    dvMessage.Attributes["class"] = "alert-box error";
                    dvMessage.InnerHtml = "Questions are not configured";

                }
                else
                {
                    DateTime DateofJoining = Convert.ToDateTime(txt_dateofjoining.Text);
                    DateTime ConnectDate = Convert.ToDateTime(txt_connectdate.Text);
                    Button button = (Button)sender;
                    string buttonId = button.ID;
                    string status;
                    IsSubmitted = (buttonId == "btn_SaveConnectTrack") ? 0 : 1;
                    string result;
                    oTracking.AssociateID = (txt_assoid.Text).ToString();
                    oTracking.AssociateName = txt_assoname.Text.ToString();
                    oTracking.EWSStatus = txt_EWSAutoGen.Text.ToString();
                    oTracking.TLEWSStatus = ddl_TLEws.SelectedItem.ToString();
                    oTracking.SubmittedBy = Session["loggedinUserid"].ToString();
                    oTracking.TMPOCComment = txt_TMPOCComment.InnerText.ToString();
                    oTracking.IsSubmitted = IsSubmitted;
                    oTracking.ConnectDate = txt_connectdate.Text.ToString();
                    status = txt_status.Text.ToString();

                    if (status.ToLower() == "resigned - under notice period" || status.ToLower() == "ja raised - yet to be terminated")
                    {
                        result = objUserOp.POCUpdateComments(oTracking);
                        if (result.Contains(';'))
                            ShowAssociateMessage(result.Split(';')[0].ToString().ToLower(), result.Split(';')[1].ToString());
                        if (IsSubmitted == 1)
                        {
                            returnBack();
                            //BindAssociates();
                            ShowFilteredData();
                        }
                    }
                    else
                    {
                        if (ConnectDate >= DateofJoining)
                        {
                            result = objUserOp.POCInsertEWSStatusTrack(oTracking);
                            if (result.Split(';')[0].ToString().ToLower() == "success")
                            {
                                string srslt = InsertQuestionStatus();
                                if (srslt.Contains(';'))
                                    ShowAssociateMessage(srslt.Split(';')[0].ToString().ToLower(), "Saved successfully");
                                if (IsSubmitted == 1)
                                {
                                    returnBack();
                                    //BindAssociates();
                                    ShowFilteredData();
                                }
                            }
                        }
                        else
                            ShowUserMessage("error", "Connect Date should be greater than or equal to Hire Date");
                    }

                    //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('saved Successfuly');", true);                                        
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            //oTracking
        }


        protected TmpocEwsstatusindetail GetEWSDetail(int qid, string qdesc, string ucom, string ew, int weight)
        {
            TmpocEwsstatusindetail oStatus = new TmpocEwsstatusindetail();

            oStatus.SubmittedBy = Session["loggedinUserid"].ToString();
            oStatus.QuestionID = qid;
            oStatus.Description = qdesc;
            oStatus.Comments = ucom;
            oStatus.Status = ew;
            oStatus.Weightage = weight;

            return oStatus;

        }
        protected string InsertQuestionStatus()
        {
            string sresult = "";
            string sAssociateID = "";
            TmpocEwsstatusindetail oStatus = new TmpocEwsstatusindetail();
            List<TmpocEwsstatusindetail> lstStatus = new List<TmpocEwsstatusindetail>();
            DataTable dtweightage = new DataTable();

            try
            {
                dtweightage = ((DataTable)Session["dt_QtWeightage"]);
                DataView dv = new DataView(dtweightage);
                sAssociateID = (txt_assoid.Text).ToString();
                int iWeightage;
                for (int i = 0; i < GridEwsStatus.Rows.Count; i++)
                {

                    Label lbl_QuestionDesc = (Label)GridEwsStatus.Rows[i].FindControl("lbl_QuestionDesc");
                    Label lbl_Questionid = (Label)GridEwsStatus.Rows[i].FindControl("lbl_QuestionID");
                    TextBox txt_UsrComment = (TextBox)GridEwsStatus.Rows[i].FindControl("txt_UsrComment");
                    DropDownList ddl_EWSStatus = (DropDownList)GridEwsStatus.Rows[i].Cells[2].FindControl("ddl_EWSStatus");


                    dv.RowFilter = "QuestionID =" + Convert.ToInt32(lbl_Questionid.Text) + "";
                    iWeightage = Convert.ToInt32(dv[0]["Weightage"]);

                    lstStatus.Add(GetEWSDetail(Convert.ToInt32(lbl_Questionid.Text), lbl_QuestionDesc.Text.ToString(), txt_UsrComment.Text.ToString(), ddl_EWSStatus.SelectedItem.ToString(), iWeightage));
                }
                return sresult = objUserOp.POCInsertQuestionStatus(lstStatus, sAssociateID);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }

        protected ConnectEWSDetails GetConnectdtls(string associateid)
        {

            string ConnectType = string.Empty;
            DateTime RecentConnectDate = new DateTime();
            ConnectEWSDetails objConnectdtls = new ConnectEWSDetails();
            DataSet ds = new DataSet();
            try
            {
                ds = objUserOp.GetPOCconnectdtls(associateid, objcons.POCConnectSP);
                DataTable dtEWS = new DataTable();
                DataTable dtConnect = new DataTable();
                DataTable dtComment = new DataTable();
                dtEWS = ds.Tables[0];
                dtConnect = ds.Tables[1];
                dtComment = ds.Tables[2];
                if (dtConnect != null && dtConnect.Rows.Count == 1)
                {
                    ConnectType = dtConnect.Rows[0]["ConnectType"].ToString();
                    objConnectdtls.ConnectType = ConnectType.ToString();
                    RecentConnectDate = Convert.ToDateTime(dtConnect.Rows[0]["RecentDate"]);
                    objConnectdtls.RecentDate = RecentConnectDate.ToString();
                }
                if (dtComment != null && dtComment.Rows.Count == 1)
                {
                    objConnectdtls.Comments = (dtComment.Rows[0]["TMPOCComment"] != null) ? dtComment.Rows[0]["TMPOCComment"].ToString() : "";
                }
                if (dtEWS != null && dtEWS.Rows.Count > 0)
                {
                    objConnectdtls.AssociateID = (dtEWS.Rows[0]["AssociateId"] != null) ? dtEWS.Rows[0]["AssociateId"].ToString() : "";
                    objConnectdtls.sEwsstatus = (dtEWS.Rows[0]["EWSStatus"] != null) ? dtEWS.Rows[0]["EWSStatus"].ToString() : "";
                    objConnectdtls.TLEWSStatus = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                    if (dtEWS.Rows.Count == 1)
                    {
                        objConnectdtls.EWSStatus1 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                    }
                    else
                        if (dtEWS.Rows.Count == 2)
                        {
                            objConnectdtls.EWSStatus2 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                            objConnectdtls.EWSStatus1 = (dtEWS.Rows[1]["TLEWS"] != null) ? dtEWS.Rows[1]["TLEWS"].ToString() : "";
                        }
                        else
                        {
                            objConnectdtls.EWSStatus3 = (dtEWS.Rows[0]["TLEWS"] != null) ? dtEWS.Rows[0]["TLEWS"].ToString() : "";
                            if (dtEWS.Rows.Count > 1)
                            {
                                objConnectdtls.EWSStatus2 = (dtEWS.Rows[1]["TLEWS"] != null) ? dtEWS.Rows[1]["TLEWS"].ToString() : "";
                                if (dtEWS.Rows.Count > 2)
                                    objConnectdtls.EWSStatus1 = (dtEWS.Rows[2]["TLEWS"] != null) ? dtEWS.Rows[2]["TLEWS"].ToString() : "";
                            }
                        }

                }
                return objConnectdtls;
            }
            catch (Exception e)
            {
                log.logError(e.Message + e.StackTrace);
                return null;
            }
        }

        protected void BindConnectAndEWSDtls(ConnectEWSDetails objConnectdtls)
        {
            if (objConnectdtls != null)
            {
                txt_ewsm1.BackColor = (objConnectdtls.EWSStatus1 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus1.ToString())) : System.Drawing.Color.FromName("White");
                txt_ews2.BackColor = (objConnectdtls.EWSStatus2 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus2.ToString())) : System.Drawing.Color.FromName("White");
                txt_ews3.BackColor = (objConnectdtls.EWSStatus3 != null) ? (System.Drawing.Color.FromName(objConnectdtls.EWSStatus3.ToString())) : System.Drawing.Color.FromName("White");
                txt_recentcomts.InnerText = (objConnectdtls.Comments != null) ? objConnectdtls.Comments.ToString() : "";
                if (objConnectdtls != null && objConnectdtls.RecentDate != null)
                {
                    DateTime lastConnectDate = DateTime.Parse((objConnectdtls.RecentDate != null) ? objConnectdtls.RecentDate.ToString() : "", System.Globalization.CultureInfo.InvariantCulture);
                    if (lastConnectDate != null)
                    {
                        string selecteddate = lastConnectDate.ToString("MM/dd/yyyy");
                        txt_dolastconnec.Text = selecteddate;
                    }
                }
                else
                {
                    txt_dolastconnec.Text = "";
                }
                txt_typeoflasconct.Text = (objConnectdtls.ConnectType != null) ? objConnectdtls.ConnectType.ToString() : "";
                txt_latestsysews.BackColor = (objConnectdtls.sEwsstatus != null) ? (System.Drawing.Color.FromName(objConnectdtls.sEwsstatus.ToString())) : System.Drawing.Color.FromName("White");
                txt_tmpocews.BackColor = (objConnectdtls.TLEWSStatus != null) ? (System.Drawing.Color.FromName(objConnectdtls.TLEWSStatus.ToString())) : System.Drawing.Color.FromName("White");
            }
        }

        protected void ResetGridvalues()
        {
            for (int i = 0; i < GridEwsStatus.Rows.Count; i++)
            {
                DropDownList ddl_EWSStatus = (DropDownList)GridEwsStatus.Rows[i].Cells[2].FindControl("ddl_EWSStatus");
                TextBox txtComments = (TextBox)GridEwsStatus.Rows[i].FindControl("txt_UsrComment");
                ddl_EWSStatus.SelectedValue = "0";
                txtComments.Text = "";
            }
            ddl_TLEws.SelectedValue = "0";
            txt_EWSAutoGen.Text = "";
        }
        protected void bindStausfield(string userid)
        {
            try
            {

                DataSet ds = objUserOp.GetPOCconnectdtls(userid, objcons.SP_GetStatus);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txt_status.Text = ds.Tables[0].Rows[0]["status"].ToString();
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
        protected void ShowUserMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }

        protected void ShowAssociateMessage(string msgType, string message)
        {
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "notify('" + message + "', 'information');", true);
        }

        protected void gv_Associates_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SaveAssociateCheckedValues();
            gv_Associates.PageIndex = e.NewPageIndex;
            DataTable dt = ViewState["MappedUsers_OneOnOne"] as DataTable;
            if (dt.Columns.Contains("AccountID")) dt.Columns.Remove("AccountID");
            gv_Associates.DataSource = dt;
            gv_Associates.DataBind();
            PopulateAssociateCheckedValues();
        }


        protected void gv_AssociateOtherConnects_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SaveCheckedValues();
            gv_AssociateOtherConnects.PageIndex = e.NewPageIndex;
            gv_AssociateOtherConnects.DataSource = ViewState["MappedUsers_OtherConnects"] as DataTable;
            gv_AssociateOtherConnects.DataBind();
            PopulateCheckedValues();
        }

        //private void PopulateCheckedValues()
        //{
        //    ArrayList userdetails = (ArrayList)Session["CHECKED_ITEMS"];
        //    if (userdetails != null && userdetails.Count > 0)
        //    {
        //        foreach (GridViewRow gvrow in gv_AssociateOtherConnects.Rows)
        //        {
        //            int index = gv_AssociateOtherConnects.PageSize * gv_AssociateOtherConnects.PageIndex + (gvrow.RowIndex + 1);
        //            if (userdetails.Contains(index))
        //            {
        //                CheckBox myCheckBox = (CheckBox)gvrow.FindControl("chk_user");
        //                myCheckBox.Checked = true;
        //            }
        //        }
        //    }
        //}
        private void PopulateCheckedValues()
        {
            List<SelectedAssociates> userdetails = (List<SelectedAssociates>)Session["CHECKED_ITEMS"];
            if (userdetails != null && userdetails.Count > 0)
            {
                foreach (GridViewRow gvrow in gv_AssociateOtherConnects.Rows)
                {
                    int index = gv_AssociateOtherConnects.PageSize * gv_AssociateOtherConnects.PageIndex + (gvrow.RowIndex + 1);
                    if (userdetails.Any(q => q.IndexID == index))
                    {
                        var associate = userdetails.Where(q => q.IndexID == index).First();
                        CheckBox myCheckBox = (CheckBox)gvrow.FindControl("chk_user");
                        myCheckBox.Checked = associate.CheckedOrNot;
                        DropDownList ddl_EWS = (DropDownList)gvrow.FindControl("ddl_EWS");
                        ddl_EWS.ClearSelection();
                        ddl_EWS.Items.FindByText(associate.SelectetedEWS).Selected = true;
                    }
                }
            }
        }
        //This method is used to save the checkedstate of values
        //private void SaveCheckedValues()
        //{
        //    ArrayList userdetails = new ArrayList();
        //    int index = -1;
        //    foreach (GridViewRow gvrow in gv_AssociateOtherConnects.Rows)
        //    {
        //        index = gv_AssociateOtherConnects.PageSize * gv_AssociateOtherConnects.PageIndex + (gvrow.RowIndex + 1);
        //        bool result = ((CheckBox)gvrow.FindControl("chk_user")).Checked;

        //        // Check in the Session
        //        if (Session["CHECKED_ITEMS"] != null)
        //            userdetails = (ArrayList)Session["CHECKED_ITEMS"];
        //        if (result)
        //        {
        //            if (!userdetails.Contains(index))
        //                userdetails.Add(index);
        //        }
        //        else
        //            userdetails.Remove(index);
        //    }
        //    if (userdetails != null && userdetails.Count > 0)
        //        Session["CHECKED_ITEMS"] = userdetails;
        //}

        //private void SaveCheckedValues()
        //{
        //    Dictionary<int, string> userdetails = new Dictionary<int, string>();
        //    int index = -1;
        //    foreach (GridViewRow gvrow in gv_AssociateOtherConnects.Rows)
        //    {
        //        index = gv_AssociateOtherConnects.PageSize * gv_AssociateOtherConnects.PageIndex + (gvrow.RowIndex + 1);
        //        bool result = ((CheckBox)gvrow.FindControl("chk_user")).Checked;

        //        // Check in the Session
        //        if (Session["CHECKED_ITEMS"] != null)
        //            userdetails = (Dictionary<int, string>)Session["CHECKED_ITEMS"];
        //        if (result)
        //        {
        //             DropDownList ddl_EWS = (DropDownList)gvrow.FindControl("ddl_EWS");
        //                string selectedEWSValue=ddl_EWS.SelectedItem.Text;     
        //            if (!userdetails.ContainsKey(index))
        //                userdetails.Add(index, selectedEWSValue);
        //        }
        //        else
        //            userdetails.Remove(index);
        //    }
        //    if (userdetails != null && userdetails.Count > 0)
        //        Session["CHECKED_ITEMS"] = userdetails;
        //}

        private void SaveCheckedValues()
        {
            List<SelectedAssociates> userdetails = new List<SelectedAssociates>();
            // Check in the Session
            if (Session["CHECKED_ITEMS"] != null)
                userdetails = (List<SelectedAssociates>)Session["CHECKED_ITEMS"];

            int index = -1;
            foreach (GridViewRow gvrow in gv_AssociateOtherConnects.Rows)
            {
                index = gv_AssociateOtherConnects.PageSize * gv_AssociateOtherConnects.PageIndex + (gvrow.RowIndex + 1);
                if (userdetails.Any(q => q.IndexID == index))
                {
                    var associateExisting = userdetails.Where(q => q.IndexID == index).First();
                    userdetails.Remove(associateExisting);
                }
                bool result = ((CheckBox)gvrow.FindControl("chk_user")).Checked;
                DropDownList ddl_EWS = (DropDownList)gvrow.FindControl("ddl_EWS");
                string selectedEWSValue = ddl_EWS.SelectedItem.Text;
                SelectedAssociates associate = new SelectedAssociates();
                associate.IndexID = index;
                associate.CheckedOrNot = result;
                associate.SelectetedEWS = selectedEWSValue;
                userdetails.Add(associate);
            }
            if (userdetails != null && userdetails.Count > 0)
                Session["CHECKED_ITEMS"] = userdetails;
        }




        private void SaveAssociateCheckedValues()
        {
            ArrayList userdetails = new ArrayList();
            int index = -1;
            foreach (GridViewRow gvrow in gv_Associates.Rows)
            {
                index = gv_Associates.PageSize * gv_Associates.PageIndex + (gvrow.RowIndex + 1);
                bool result = ((RadioButton)gvrow.FindControl("rdb_selectedAssociate")).Checked;

                // Check in the Session
                if (Session["Checked_Associate"] != null)
                    userdetails = (ArrayList)Session["Checked_Associate"];
                if (result)
                {
                    if (!userdetails.Contains(index))
                    {
                        userdetails.Clear();
                        userdetails.Add(index);
                    }
                }
                else
                    userdetails.Remove(index);
            }
            if (userdetails != null && userdetails.Count > 0)
                Session["Checked_Associate"] = userdetails;
        }

        private void PopulateAssociateCheckedValues()
        {
            ArrayList userdetails = (ArrayList)Session["Checked_Associate"];
            if (userdetails != null && userdetails.Count > 0)
            {
                foreach (GridViewRow gvrow in gv_Associates.Rows)
                {
                    int index = gv_Associates.PageSize * gv_Associates.PageIndex + (gvrow.RowIndex + 1);
                    if (userdetails.Contains(index))
                    {
                        userdetails.Clear();
                        RadioButton myRadiobtn = ((RadioButton)gvrow.FindControl("rdb_selectedAssociate"));
                        myRadiobtn.Checked = true;
                    }
                }
            }
        }

        protected void ddl_EWSStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_EWSAutoGen.Text = "";
            GenerateSystemEWS();
        }

        public enum Status
        {
            Red = 1,
            Green = 2,
            Amber = 3
        }

        public void BindAcccountsunderTMPOC(string TMPOC)
        {
            try
            {
                DataTable dt = objUserOp.BindAcccountsunderTMPOC(TMPOC);
                ListBox_Accounts.DataSource = dt;
                ListBox_Accounts.DataValueField = "AccountID";
                ListBox_Accounts.DataTextField = "Account";
                ListBox_Accounts.DataBind();
                if (dt.Rows.Count > 0 && dt != null)
                {
                    ListBox_Accounts.Items.Insert(0, new ListItem("Select All", "0"));
                    ListBox_Accounts.SelectedValue = "0";
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        protected void btn_searchassociates_Click(object sender, EventArgs e)
        {
            Session["CHECKED_ITEMS"] = null;
            //resetGridFilters();
            ShowFilteredData();
        }

        protected string GetSelectedAccounts()
        {
            string selectedaccounts = "";
            foreach (ListItem i in ListBox_Accounts.Items.Cast<ListItem>().Where(x => x.Selected))
            {
                if (string.IsNullOrEmpty(selectedaccounts))
                {
                    selectedaccounts = "'" + i.Value + "'";
                }
                else
                {
                    selectedaccounts = selectedaccounts + "," + "'" + i.Value + "'";
                }
            }
            return selectedaccounts;
        }
        protected void ShowFilteredData()
        {
            try
            {
                resetGridFilters();
                string selectedaccounts = string.Empty;

                if (ddl_connectType.SelectedItem.Text.ToLower().Contains("day 1") || ddl_connectType.SelectedItem.Text.ToLower().Contains("day 2"))
                    selectedaccounts = "0";
                else
                    selectedaccounts = GetSelectedAccounts();
                string status = "";
                if (chkbx_Met.Checked)
                {
                    if (string.IsNullOrEmpty(status))
                    {
                        status = "'" + chkbx_Met.Text + "'";
                    }
                    else
                    {
                        status = "'" + status + "'" + "," + "'" + chkbx_Met.Text + "'";
                    }
                }
                if (chkbx_NotMet.Checked)
                {
                    if (string.IsNullOrEmpty(status))
                    {
                        status = "'" + chkbx_NotMet.Text + "'";
                    }
                    else
                    {
                        status = status + "," + "'" + chkbx_NotMet.Text + "'";
                    }
                }
                if (!string.IsNullOrEmpty(status) && !string.IsNullOrEmpty(selectedaccounts))
                {

                    if (ddl_connectType.SelectedValue == "1")
                    {
                        tbl_oneonone.Visible = true;
                        tbl_OtherConnects.Visible = false;
                        string sloginid = Session["loggedinUserid"].ToString();
                        DataTable dt = objUserOp.BindUserRoleGrid(sloginid, ddl_AdditionalFilters.SelectedValue);
                        ViewState["MappedUsers_OneOnOne"] = dt;
                        DataTable dtsearch = ViewState["MappedUsers_OneOnOne"] as DataTable;
                        DataRow[] dtsearchrow = dtsearch.Select("[AccountID] in (" + selectedaccounts + ") AND Status in (" + status + ")", "[Associate ID] ASC");
                        if (dtsearchrow.Count() > 0)
                        {
                            dtsearch = dtsearchrow.CopyToDataTable();
                            dtsearch.Columns.Remove("AccountID");
                            ViewState["MappedUsers_OneOnOne"] = dtsearch.Copy();
                            Session["MappedUsers_OneOnOne"] = dtsearch;
                            gv_Associates.DataSource = dtsearch;
                            gv_Associates.DataBind();
                            gv_Associates.Visible = true;
                            gv_Associates.SetPageIndex(0);
                            gv_AssociateOtherConnects.Visible = false;
                            tbl_oneonone.Visible = true;
                            tbl_GridFilter.Visible = true;
                            btn_submit.Visible = true;
                        }
                        else
                        {
                            dtsearch = null;
                            ViewState["MappedUsers_OneOnOne"] = null;
                            Session["MappedUsers_OneOnOne"] = null;
                            gv_Associates.DataSource = dtsearch;
                            gv_Associates.DataBind();
                            gv_Associates.Visible = true;
                            tbl_GridFilter.Visible = false;
                            gv_AssociateOtherConnects.Visible = false;
                            btn_OtherConnects.Visible = false;
                            btn_submit.Visible = false;
                        }
                    }
                    else
                    {
                        string sloginid = Session["loggedinUserid"].ToString();
                        string connecttype = ddl_connectType.SelectedItem.Text;
                        DataTable dt = objUserOp.BindOtherConnectUsers(sloginid, connecttype, ddl_AdditionalFilters.SelectedValue);
                        ViewState["MappedUsers_OtherConnects"] = dt;
                        DataTable dtsearch = ViewState["MappedUsers_OtherConnects"] as DataTable;
                        DataRow[] dtsearchrow;
                        if (ddl_connectType.SelectedItem.Text == "Day 1 connect" || ddl_connectType.SelectedItem.Text == "Day 2 connect")
                        {
                            dtsearchrow = dtsearch.Select("Status in (" + status + ")", "[Associate ID] ASC");
                        }
                        else
                        {
                            dtsearchrow = dtsearch.Select("[AccountID] in (" + selectedaccounts + ") AND Status in (" + status + ")", "[Associate ID] ASC");
                        }
                        if (dtsearchrow.Count() > 0)
                        {
                            dtsearch = dtsearchrow.CopyToDataTable();
                            dtsearch.Columns.Remove("AccountID");
                            ViewState["MappedUsers_OtherConnects"] = dtsearch.Copy();
                            Session["MappedUsers_OtherConnects"] = dtsearch;
                            gv_AssociateOtherConnects.DataSource = dtsearch;
                            gv_AssociateOtherConnects.DataBind();

                            if (ddl_connectType.SelectedItem.Text.ToLower() != "group connect")
                            {
                                DataControlField dataControlField = gv_AssociateOtherConnects.Columns.Cast<DataControlField>().SingleOrDefault(x => x.HeaderText == "EWS");
                                if (dataControlField != null)
                                {
                                    dataControlField.Visible = false;
                                    gv_AssociateOtherConnects.Attributes.Add("Class", "gc");
                                }
                            }
                            else
                            {
                                DataControlField dataControlField = gv_AssociateOtherConnects.Columns.Cast<DataControlField>().SingleOrDefault(x => x.HeaderText == "EWS");
                                if (dataControlField != null)
                                {
                                    dataControlField.Visible = true;
                                    gv_AssociateOtherConnects.Attributes.Remove("Class");
                                }
                            }

                            //gv_AssociateOtherConnects.Columns[1].Visible = ddl_connectType.SelectedItem.Text.ToLower() != "group connect" ? false : true;

                            gv_AssociateOtherConnects.SetPageIndex(0);
                            gv_Associates.Visible = false;
                            gv_AssociateOtherConnects.Visible = true;
                            tbl_oneonone.Visible = true;
                            tbl_OtherConnects.Visible = true;
                            trGroupComments.Visible = true;
                            txt_GroupConnectComments.Text = "";
                            btn_submit.Visible = false;
                            txt_GroupConnectDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
                            tbl_GridFilter.Visible = true;
                            btn_OtherConnects.Visible = true;
                        }
                        else
                        {
                            dtsearch = null;
                            ViewState["MappedUsers_OtherConnects"] = null;
                            Session["MappedUsers_OtherConnects"] = null;
                            gv_AssociateOtherConnects.DataSource = dtsearch;
                            gv_AssociateOtherConnects.DataBind();
                            tbl_oneonone.Visible = true;
                            gv_Associates.Visible = false;
                            gv_AssociateOtherConnects.Visible = true;
                            btn_OtherConnects.Visible = false;
                            btn_submit.Visible = false;
                            trGroupComments.Visible = false;
                            tbl_GridFilter.Visible = false;
                            txt_GroupConnectComments.Text = "";
                        }
                    }

                }
                else
                {
                    if (ddl_connectType.SelectedValue == "1")
                    {
                        ShowAssociateMessage("warning", "Please select the required criteria");
                    }
                    else
                        ShowUserMessage("warning", "Please select the required criteria");
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
        }

        protected void btnGridSearch_Click(object sender, ImageClickEventArgs e)
        {
            DataTable dt;
            if (ddl_connectType.SelectedValue == "1")
            {
                dt = (DataTable)Session["MappedUsers_OneOnOne"];
            }
            else
            {
                dt = (DataTable)Session["MappedUsers_OtherConnects"];
            }
            String searchType = "INT";
            switch (ddlSearchBy.SelectedItem.Text.ToString().ToLower())
            {
                case "associate id":
                    string searchkey = txtGridSearch.Text;
                    searchkey = searchkey.Replace("\n", String.Empty);
                    searchkey = searchkey.Replace("\r", String.Empty);
                    searchkey = searchkey.Replace("\t", String.Empty);
                    dt = gridOp.FilterGridRecords(dt, ddlSearchBy.SelectedItem.Text.ToString(), searchkey, searchType);
                    break;
                case "associate name":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, ddlSearchBy.SelectedItem.Text.ToString(), txtGridSearch.Text, searchType);
                    break;
                case "account":
                    searchType = "STRING";
                    dt = gridOp.FilterGridRecords(dt, ddlSearchBy.SelectedItem.Text.ToString(), txtGridSearch.Text, searchType);
                    break;
                default: break;
            }
            if (ddl_connectType.SelectedValue == "1")
            {
                gv_Associates.DataSource = dt;
                ViewState["MappedUsers_OneOnOne"] = dt;
                gv_Associates.DataBind();
                btn_submit.Visible = (dt == null) ? false : true;
            }
            else
            {
                gv_AssociateOtherConnects.DataSource = dt;
                ViewState["MappedUsers_OtherConnects"] = dt;
                gv_AssociateOtherConnects.DataBind();
                btn_OtherConnects.Visible = (dt == null) ? false : true;
                if (dt == null)
                {

                    trGroupComments.Visible = false;
                    txt_GroupConnectComments.Text = "";
                    tbl_OtherConnects.Visible = false;

                }
                else
                {
                    tbl_OtherConnects.Visible = true;
                    trGroupComments.Visible = true;
                    txt_GroupConnectComments.Text = "";

                }
            }

        }

        protected void btnGridReset_Click(object sender, ImageClickEventArgs e)
        {
            resetGridFilters();
            ResetGridData();
        }

        protected void ResetGridData()
        {
            if (ddl_connectType.SelectedValue == "1")
            {
                DataTable dtsearch = Session["MappedUsers_OneOnOne"] as DataTable;
                ViewState["MappedUsers_OneOnOne"] = dtsearch;
                gv_Associates.DataSource = dtsearch;
                gv_Associates.DataBind();
                gv_Associates.SetPageIndex(0);
                btn_submit.Visible = (dtsearch == null || dtsearch.Rows.Count < 1) ? false : true;
            }
            else
            {
                DataTable dtsearch = Session["MappedUsers_OtherConnects"] as DataTable;
                ViewState["MappedUsers_OtherConnects"] = dtsearch;
                gv_AssociateOtherConnects.DataSource = dtsearch;
                gv_AssociateOtherConnects.DataBind();
                gv_AssociateOtherConnects.SetPageIndex(0);
                btn_OtherConnects.Visible = (dtsearch == null || dtsearch.Rows.Count < 1) ? false : true;
                gv_AssociateOtherConnects.Visible = (dtsearch == null || dtsearch.Rows.Count < 1) ? false : true;
                tbl_oneonone.Visible = (dtsearch == null || dtsearch.Rows.Count < 1) ? false : true;
                tbl_OtherConnects.Visible = (dtsearch == null || dtsearch.Rows.Count < 1) ? false : true;
                trGroupComments.Visible = true;
            }
        }

        protected void rdb_manual_CheckedChanged(object sender, EventArgs e)
        {
            tbl_bulkupload.Visible = false;
            dvUserSelection.Visible = true;
            tblMain.Visible = true;
            ShowFilteredData();
        }

        protected void rdb_bulkupload_CheckedChanged(object sender, EventArgs e)
        {
            tbl_bulkupload.Visible = true;
            tblMain.Visible = false;
            dvUserSelection.Visible = false;
        }
        private bool validateSheetName(string sheetName, string filepath)
        {
            try
            {
                ExcelConn(filepath);
                Econ.Open();
                sheetName = "" + sheetName + "$";
                System.Data.DataTable dt = Econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                Econ.Close();
                if (dt == null)
                {
                    return false;
                }
                else
                {
                    String excelSheets;

                    // Add the sheet name to the string array.
                    foreach (DataRow row in dt.Rows)
                    {
                        excelSheets = row["TABLE_NAME"].ToString();
                        if (excelSheets.Contains(sheetName))
                        {
                            return true;
                        }
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }

        }
        private void ExcelConn(string FilePath)
        {
            constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", FilePath);
            Econ = new OleDbConnection(constr);
        }
        private System.Data.DataTable GetExcelRecords(string FilePath, string sheet)
        {
            try
            {
                ExcelConn(FilePath);
                Query = string.Format("select * from [" + sheet + "$]");
                OleDbCommand Ecom = new OleDbCommand(Query, Econ);
                Econ.Open();
                DataSet ds = new DataSet();
                OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
                Econ.Close();
                oda.Fill(ds);
                System.Data.DataTable Exceldt = ds.Tables[0];
                log.logInfo("No. of rows inserted: " + Exceldt.Rows.Count);
                return Exceldt;
            }
            catch (Exception ex)
            {
                log.logError("Reading excel records from uploaded excel" + ex.Message + ex.StackTrace);
                return null;
            }
        }
        protected bool ValidateColumns(System.Data.DataTable dtexcel, string key)
        {
            try
            {
                string[] columnNames = (from dc in dtexcel.Columns.Cast<DataColumn>() select dc.ColumnName.Trim()).ToArray();
                string[] ActualColumnNames = ConfigurationManager.AppSettings[key].Split(';');
                IStructuralEquatable structuralEquator1 = columnNames;
                bool areEqual = structuralEquator1.Equals(ActualColumnNames, StringComparer.InvariantCultureIgnoreCase);
                return areEqual;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return false;
            }
        }
        protected System.Data.DataTable ValidateNulls(System.Data.DataTable dtexcel, int colcount)
        {
            try
            {
                for (int i = dtexcel.Columns.Count - 1; i > colcount; i--)
                {
                    dtexcel.Columns.RemoveAt(i);
                }
                dtexcel.AcceptChanges();
                int j;
                for (int i = 0; i < dtexcel.Rows.Count; i++)
                {

                    for (j = 0; j < dtexcel.Columns.Count; j++)
                    {
                        if (!dtexcel.Rows[i].IsNull(j))
                            break;
                    }

                    if (j == dtexcel.Columns.Count)
                    {
                        dtexcel.Rows[i].Delete();
                    }

                }
                dtexcel.AcceptChanges();
                return dtexcel;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }
        protected void GenerateExcel(string filename, System.Data.DataTable dtresult)
        {
            try
            {
                Session["filename"] = filename;
                Session["dtresult"] = dtresult;
                ifr.Src = "GenerateOutput.aspx";
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }

        }
        protected void btn_upload_Click(object sender, EventArgs e)
        {
            string bulkuploadPath = ConfigurationManager.AppSettings["BulkuploadPath"];
            try
            {
                string result = null;
                log.logInfo("Trying to upload file");
                if (FileUpload_Bulkupload.HasFile)
                {
                    string extension = System.IO.Path.GetExtension(FileUpload_Bulkupload.FileName);
                    string sheet = "Sheet1";
                    string filePath = null;
                    string UserID = Convert.ToString(Session["loggedinuserID"]);
                    System.Data.DataSet dtresult = new System.Data.DataSet();
                    if (extension.ToUpper() == ".XLSX")
                    {
                        string oldfilename = FileUpload_Bulkupload.FileName;
                        string newfilename = DateTime.Now.ToString("ddMMyyyy_hhmmss") + oldfilename;
                        FileUpload_Bulkupload.SaveAs(bulkuploadPath + newfilename);
                        System.Data.DataTable dtexcel = new System.Data.DataTable();
                        FileUpload_Bulkupload = new FileUpload();

                        filePath = bulkuploadPath + newfilename;
                        dtexcel = GetExcelRecords(filePath, sheet);
                        if (validateSheetName(sheet, filePath) == false)
                        {
                            result = "error;Invalid Sheet Name, please use valid template";
                        }
                        else
                        {
                            if (ValidateColumns(dtexcel, "GroupConnectColumns"))
                            {
                                int colcount = 5;
                                dtexcel = ValidateNulls(dtexcel, colcount);
                                DataRow[] dr = dtexcel.Select();
                                if (dr.Length == 0)
                                {
                                    result = "warning;No records for the required selection criteria";
                                }
                                else
                                {
                                    dtexcel = dr.CopyToDataTable();
                                    if (dtexcel.Rows.Count > 300)
                                    {
                                        result = "error;Number of rows in excel exceeds maximum limit.";
                                    }
                                    else
                                    {
                                        System.Data.DataTable dtCloned = dtexcel.Clone();
                                        //change data type of column
                                        //dtCloned.Columns["Account ID"].DataType = typeof(String);
                                        dtCloned.Columns["Connect Date"].DataType = typeof(String);
                                        //import row to cloned datatable
                                        foreach (DataRow row in dtexcel.Rows)
                                        {
                                            if (!String.IsNullOrEmpty(Convert.ToString(row["Connect Date"])))
                                                row["Connect Date"] = Convert.ToDateTime(row["Connect Date"]).ToShortDateString();
                                            dtCloned.ImportRow(row);
                                        }
                                        BulkUploadBAL BUbal = new BulkUploadBAL();
                                        
                                        //dtresult = BUbal.GroupConnectUpload(dtCloned, UserID);
                                        //ResetControls();
                                        string emailIDs = dtresult.Tables[1].Rows[0][0].ToString();

                                        if (emailIDs != null && emailIDs.Length > 0)
                                        {
                                            log.logInfo("Sending survey mail");
                                            if (!SendSurveyMail(emailIDs))
                                            {
                                                log.logInfo("Failed to send. Trying second attempt");
                                                if (!SendSurveyMail(emailIDs))
                                                {
                                                    log.logInfo("Failed to send in second attempt. Trying final third attempt");
                                                    bool finalStatus = SendSurveyMail(emailIDs);
                                                    if (!finalStatus)
                                                    {
                                                        log.logInfo("Unable to send Survey Trigger mails - Bulk Upload");
                                                    }
                                                }
                                            }
                                        }
                                        GenerateExcel(oldfilename.Split('.')[0], dtresult.Tables[0]);
                                    }
                                }
                            }
                            else
                            {
                                result = "error;Invalid Column Names, please use valid template";
                            }
                        }
                    }
                    else
                    {
                        result = "error;Please upload valid file.";
                    }
                }
                else
                {
                    ShowUserMessage("information", "Please select file and try.");
                }

                if (!string.IsNullOrEmpty(result) && result.Contains(';'))
                {
                    string msgtype = result.Split(';')[0];
                    string message = result.Split(';')[1];
                    ShowUserMessage(msgtype, message);
                }

            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            finally
            {

            }

        }
        protected void btnSubmitCommnets_Click(object sender, EventArgs e)
        {
            oTracking.AssociateID = (txt_assoid.Text).ToString();
            oTracking.SubmittedBy = Session["loggedinUserid"].ToString();
            oTracking.TMPOCComment = txtRJcomments.InnerText.ToString();
            string result = objUserOp.POCUpdateComments(oTracking);
            if (result.Contains(';'))
            {
                ShowAssociateMessage(result.Split(';')[0].ToString().ToLower(), result.Split(';')[1].ToString());
                returnBack();
                ShowFilteredData();
            }
        }

        protected void btn_RJ_Return_Click(object sender, EventArgs e)
        {
            returnBack();
        }

        protected void gv_AssociateOtherConnects_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    if (e.Row.Cells != null && e.Row.Cells[7] != null && e.Row.Cells[7].Text.ToLower() == "met")
                    {
                        DropDownList ddl_EWS = (DropDownList)e.Row.FindControl("ddl_EWS");
                        HiddenField ews = (HiddenField)e.Row.FindControl("hdn_EWS");
                        if (!string.IsNullOrEmpty(ews.Value))
                        {
                            ddl_EWS.ClearSelection();
                            ddl_EWS.Items.FindByText(ews.Value).Selected = true;
                        }

                        if (ddl_connectType.SelectedValue == "2" || ddl_connectType.SelectedValue == "3")
                        {
                            e.Row.Cells[0].Enabled = false;
                            CheckBox cb = (CheckBox)e.Row.FindControl("chk_user");
                            cb.Enabled = false;
                            cb.ToolTip = "Associate already met.";
                            e.Row.Cells[1].Enabled = false;
                            ddl_EWS.ToolTip = "Associate already met.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }

    }
    public class SelectedAssociates
    {
        public int IndexID { get; set; }
        public bool CheckedOrNot { get; set; }
        public string SelectetedEWS { get; set; }
    }
}


