﻿using HRAssimilation.Business;
using HRAssimilation.Entity;
using System;
using System.Web;
using System.Web.Services;

namespace HRAssimilation.Pages
{
    public partial class Logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TrackLogoutUser();
            KillSession();
            if (Request.QueryString["Action"] == "Logout")
            {
                Response.Redirect("Login.aspx", true);
            }
            else if (Request.QueryString["Action"] == "Timeout")
            {
                Response.Redirect("Login.aspx?Timeout=yes", true);
            }
        }
        protected void KillSession()
        {
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
            Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-10);
        }
        protected void TrackLogoutUser()
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["loggedinUserid"])))
            {
                UserOperationsBAL ub = new UserOperationsBAL();
                TrackUsers tu = new TrackUsers();
                tu.UserID = Convert.ToString(Session["loggedinUserid"]);
                tu.SessionID = Session.SessionID;
                tu.Action = "Logout";
                ub.TrackUser(tu);
            }
        }
        [WebMethod]
        public static string KillLoggedInSession()
        {
            if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["loggedinUserid"])))
            {
                UserOperationsBAL ub = new UserOperationsBAL();
                TrackUsers tu = new TrackUsers();
                tu.UserID = Convert.ToString(HttpContext.Current.Session["loggedinUserid"]);
                tu.SessionID = HttpContext.Current.Session.SessionID;
                tu.Action = "Logout";
                ub.TrackUser(tu);
                HttpContext.Current.Session.Clear();
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Session.RemoveAll();
                HttpContext.Current.Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                HttpContext.Current.Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-10);
                return "success";
            }
            return "failure";
        }
    }
}