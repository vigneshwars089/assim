function notify(message, type, timeout) {
    // default values
   
    message = typeof message !== 'undefined' ? message : '';//Hello!
    type = typeof type !== 'undefined' ? type : 'success';
    timeout = typeof timeout !== 'undefined' ? timeout : 3000;

    // append markup if it doesn't already exist
    if ($('#notification').length < 1) {
        markup = '<div id="notification" class="information"><p id="notifymsg"></p><a class="close" href="#">x</a></div>';
        $('body').append(markup);
    }

    // elements
    $notification = $('#notification');
    $notificationSpan = $('#notification p');
    $notificationClose = $('#notification a.close');

    // set the message

    document.getElementById("notifymsg").innerText = message;
    // setup click event
    $notificationClose.click(function (e) {
        //e.preventDefault();
        (e.preventDefault) ? e.preventDefault() : e.returnValue = false;
        $notification.css('top', '-50px');
    });

    // for ie6, scroll to the top first
    //if ($.browser.msie && $.browser.version < 7) {
    //    $('html').scrollTop(0);
    //}
    var isIEVersion = getIEVersion();

    if (parseInt(isIEVersion) < 7) {
        $('html').scrollTop(0);
    }

    // hide old notification, then show the new notification
    $notification.css('top', '-50px').stop().removeClass().addClass(type).animate({
        top: 0
    }, 500, function () {
        $notification.delay(timeout).animate({
            top: '-150px'
        }, 500);
    });
}

function notifyalert(type) {
    var msg = document.getElementById("divcustommessage").innerText;
    notify(msg, type);
       
}

function getIEVersion() {
    var version = null;
    var agentStr = navigator.userAgent;
    if (agentStr.indexOf("MSIE 7.0") > -1 || agentStr.indexOf("Mozilla") > -1) {
        if (agentStr.indexOf("Trident/6.0") > -1) {
            version = '10';//Iexplore version
        } else if (agentStr.indexOf("Trident/5.0") > -1) {
            version = '9';
        } else if (agentStr.indexOf("Trident/4.0") > -1) {
            version = '8';
        } else if (agentStr.indexOf("Trident/7.0") > -1) {
            version = '11';
        }
        else {
            version = '7';
        }
    }
    return version;
}