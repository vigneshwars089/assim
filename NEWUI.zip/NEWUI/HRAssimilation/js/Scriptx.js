﻿var glb_logout;
//Create XMLHttpObject for send request to server using javascript
function GetXmlHttpObject() {
    var xmlHttp = null;
    try {
        // Firefox, Opera 8.0+, Safari
        xmlHttp = new XMLHttpRequest();
    }
    catch (e) {
        // Internet Explorer
        try {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    return xmlHttp;
}
//Function for action, when state changed to complete
function stateChanged() {
    if (xmlHttp.readyState == 4) {
        //window.alert(xmlHttp.responseText);
        //window.close();
    }
}
//Function for action, when state changed to complete
function stateChanged1() {
    if (xmlHttp.readyState == 4) {
        //window.alert(xmlHttp.responseText);
        glb_logout = 'yes';
        window.close();
    }
}

//Current Activity Insert or Update(using for CurrentActivity Report)
function CurrentActivityInsertOrUpdate(endUserID, subProcessID, stepIDControl, levelNumber) {
    //alert(document.aspnetForm[stepIDControl].options[document.aspnetForm[stepIDControl].selectedIndex].text);
    var stepText = document.aspnetForm[stepIDControl].options[document.aspnetForm[stepIDControl].selectedIndex].text;
    var stepID = document.aspnetForm[stepIDControl].value;
    //alert(endUserID + "--" + subProcessID + "--" + glb_StartTime + "--" + levelNumber + "--" + stepID + "--" + stepText);
    /*-----------------------------------------------------------
    Ajax Related Code                        
    -------------------------------------------------------------*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        alert("Your browser does not support AJAX!");
        return;
    }
    var url = "../AjaxSupport/InsertCurrentActivity.aspx";
    url = url + "?stepText=" + escape(stepText);
    //url=url+"&starttime="+glb_StartTime.toLocaleDateString() + ' ' + glb_StartTime.toLocaleTimeString();
    url = url + "&starttime=" + encodeURI(glb_StartTime.toDateString() + ' ' + glb_StartTime.toLocaleTimeString());
    url = url + "&enduserid=" + endUserID;
    url = url + "&subprocessid=" + subProcessID;
    url = url + "&stepid=" + stepID;
    url = url + "&levelnumber=" + levelNumber;
    if (glb_productiveType.toLowerCase() == "productive")
        url = url + "&status=2";
    else
        url = url + "&status=3";
    url = url + "&sid=" + Math.random();
    //alert(url);
    xmlHttp.onreadystatechange = stateChanged;
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
    /*-----------------------------------------------------------*/
}
function PreCheckLogOffAssociate(endUserID, subProcessID) {
    if ((window.event.clientX < 0) || (window.event.clientY < 0)) {
        return 'Are you sure you want to LogOff MMS?';
    }
}
function LogOffAssociate(endUserID, subProcessID) {
    //if((window.event.clientX<0) || (window.event.clientY<0))
    //{
    /*-----------------------------------------------------------
    Ajax Related Code                        
    -------------------------------------------------------------*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        alert("Your browser does not support AJAX!");
    }
    var url = "../AjaxSupport/LogOffAssociate.aspx";
    url = url + "?enduserid=" + endUserID;
    url = url + "&subprocessid=" + subProcessID;
    url = url + "&nc=" + Math.random();
    xmlHttp.onreadystatechange = stateChanged1;
    xmlHttp.open("GET", url, true);
    xmlHttp.send(null);
    /*-----------------------------------------------------------*/
    //}
}

//Testing purpose
function InsertMMSActivity(eid, spid, status, sprt, rst, isPIMOMandatory, isRemarksMandatory) {
    ////////////////////
    // Validation Start
    ////////////////////
    //PIMO or Volume
    if (isPIMOMandatory == 'True' && glb_productiveType != 'Non-Productive') {
        if (document.aspnetForm['txtFileOrVolume'] != null) {
            if (glb_ReportType == 'Volume') {
                if (document.aspnetForm['txtFileOrVolume'].value.length == 0) {
                    window.alert('Please enter volume');
                    document.aspnetForm['txtFileOrVolume'].focus();
                    return false;
                }
                else {
                    if (isNaN(document.aspnetForm['txtFileOrVolume'].value)) {
                        window.alert('Please enter volume in number format');
                        document.aspnetForm['txtFileOrVolume'].focus();
                        return false;
                    }
                }
            }
            else {
                if (document.aspnetForm['txtFileOrVolume'].value.length == 0) {
                    window.alert('Please enter value in textbox');
                    document.aspnetForm['txtFileOrVolume'].focus();
                    return false;
                }
            }
        }
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].value == '') {
            alert('Enter Level1 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].value == '') {
            alert('Enter Level2 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].value == '') {
            alert('Enter Level3 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].value == '') {
            alert('Enter Level4 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].value == '') {
            alert('Enter Level5 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].value == '') {
            alert('Enter Level6 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].value == '') {
            alert('Enter Level7 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].focus();
            return false;
        }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'] != null)
        if (document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].value == '') {
            alert('Enter Level8 Step');
            document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].style.display = 'block';
            document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].focus();
            return false;
        }
    //Remarks
    if (isRemarksMandatory == 'True') {
        if (document.aspnetForm['txtAreaRemarks'].value.length == 0) {
            window.alert('Please enter Remarks');
            document.aspnetForm['txtAreaRemarks'].focus();
            return false;
        }
    }

    // Validation End
    var params = "status=" + status;
    params = params + "&sprt=" + sprt;
    params = params + "&rst=" + rst;
    //alert("employeeID-"+eid);
    params = params + "&eid=" + eid;
    //alert("SubProcessID-"+spid);
    params = params + "&spid=" + spid;
    //alert(glb_StartTime.toLocaleDateString() + ' ' + glb_StartTime.toLocaleTimeString());
    //params = params + "&st="+glb_StartTime.toLocaleDateString() + ' ' + glb_StartTime.toLocaleTimeString();
    params = params + "&st=" + encodeURI(glb_StartTime.toDateString() + ' ' + glb_StartTime.toLocaleTimeString());
    EndTimeBySubmit();
    //alert(glb_EndTime.toLocaleDateString() + ' ' + glb_EndTime.toLocaleTimeString());
    //params = params + "&et="+glb_EndTime.toLocaleDateString() + ' ' + glb_EndTime.toLocaleTimeString();
    params = params + "&et=" + encodeURI(glb_EndTime.toDateString() + ' ' + glb_EndTime.toLocaleTimeString());

    if (document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'] != null) {
        //alert("Level1-"+document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].value);
        params = params + "&l1=" + document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].value
        if (oldl1 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].value != oldl1) {
            alert('Previous level1 step not matching with current level1 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'] != null) {
        //alert("Level2-"+document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].value);
        params = params + "&l2=" + document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].value
        if (oldl2 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].value != oldl2) {
            alert('Previous level2 step not matching with current level2 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'] != null) {
        //alert("Level3-"+document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].value);
        params = params + "&l3=" + document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].value
        if (oldl3 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].value != oldl3) {
            alert('Previous level3 step not matching with current level3 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl02$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'] != null) {
        //alert("Level4-"+document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].value);
        params = params + "&l4=" + document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].value
        if (oldl4 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].value != oldl4) {
            alert('Previous level4 step not matching with current level4 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl03$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'] != null) {
        //alert("Level5-"+document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].value);
        params = params + "&l5=" + document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].value
        if (oldl5 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].value != oldl5) {
            alert('Previous level5 step not matching with current level5 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl04$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'] != null) {
        //alert("Level6-"+document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].value);
        params = params + "&l6=" + document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].value
        if (oldl6 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].value != oldl6) {
            alert('Previous level6 step not matching with current level6 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl05$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'] != null) {
        //alert("Level7-"+document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].value);
        params = params + "&l7=" + document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].value
        if (oldl7 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].value != oldl7) {
            alert('Previous level7 step not matching with current level7 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl06$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'] != null) {
        //alert("Level8-"+document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].value);
        params = params + "&l8=" + document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].value
        if (oldl8 != null && document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].value != oldl8) {
            alert('Previous level8 step not matching with current level8 step');
            return false;
        }
        document.aspnetForm['rptrMMSTrackerLevels$ctl07$ddlLevel'].selectedIndex = 0;
    }
    if (document.aspnetForm['rptrMMSTrackerTxtInfo$ctl00$txtLevel'] != null) {
        //alert("Text1-"+document.aspnetForm['rptrMMSTrackerTxtInfo$ctl00$txtLevel'].value);
        params = params + "&txt1=" + escape(document.aspnetForm['rptrMMSTrackerTxtInfo$ctl00$txtLevel'].value)
        document.aspnetForm['rptrMMSTrackerTxtInfo$ctl00$txtLevel'].value = '';
    }
    if (document.aspnetForm['rptrMMSTrackerTxtInfo$ctl01$txtLevel'] != null) {
        //alert("Text2-"+document.aspnetForm['rptrMMSTrackerTxtInfo$ctl01$txtLevel'].value);
        params = params + "&txt2=" + escape(document.aspnetForm['rptrMMSTrackerTxtInfo$ctl01$txtLevel'].value)
        document.aspnetForm['rptrMMSTrackerTxtInfo$ctl01$txtLevel'].value = '';
    }
    if (document.aspnetForm['rptrMMSTrackerTxtInfo$ctl02$txtLevel'] != null) {
        //alert("Text3-"+document.aspnetForm['rptrMMSTrackerTxtInfo$ctl02$txtLevel'].value);
        params = params + "&txt3=" + escape(document.aspnetForm['rptrMMSTrackerTxtInfo$ctl02$txtLevel'].value)
        document.aspnetForm['rptrMMSTrackerTxtInfo$ctl02$txtLevel'].value = '';
    }
    if (document.aspnetForm['rptrMMSTrackerTxtInfo$ctl03$txtLevel'] != null) {
        //alert("Text4-"+document.aspnetForm['rptrMMSTrackerTxtInfo$ctl03$txtLevel'].value);
        params = params + "&txt4=" + escape(document.aspnetForm['rptrMMSTrackerTxtInfo$ctl03$txtLevel'].value)
        document.aspnetForm['rptrMMSTrackerTxtInfo$ctl03$txtLevel'].value = '';
    }

    //alert("Remarks-"+document.aspnetForm['txtAreaRemarks'].value);
    if (document.aspnetForm['txtAreaRemarks'] != null) {
        params = params + "&rmrks=" + escape(document.aspnetForm['txtAreaRemarks'].value)
        document.aspnetForm['txtAreaRemarks'].value = '';
    }
    //SLA Breached
    if (document.aspnetForm['ddlSLABreached'] != null) {
        params = params + "&sla=" + document.aspnetForm['ddlSLABreached'].value
        document.aspnetForm['ddlSLABreached'].selectedIndex = 0;
    }
    //PIMO or Volume
    if (document.aspnetForm['txtFileOrVolume'] != null) {
        params = params + "&pimoOrVolume=" + document.aspnetForm['txtFileOrVolume'].value
        document.aspnetForm['txtFileOrVolume'].value = '';
    }
    else
        params = params + "&pimoOrVolume=1"    //MMSUID
    params = params + "&mmsuid=" + document.aspnetForm['txtMMSUID'].value
    document.aspnetForm['txtMMSUID'].value = '';
    //TimeSpent
    document.aspnetForm['txtTotalTimeTaken'].value = '';
    //Start Time
    document.getElementById('lblStartTime').innerHTML = '';
    //End Time
    document.getElementById('lblEndTime').innerHTML = '';


    /*-----------------------------------------------------------
    Ajax Related Code                        
    -------------------------------------------------------------*/
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        alert("Your browser does not support AJAX!");
        return;
    }
    var url = "../AjaxSupport/InsertMMSActivity.aspx";
    xmlHttp.open("POST", url, true);
    //Send the proper header information along with the request
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.setRequestHeader("Content-length", params.length);
    //xmlHttp.setRequestHeader("Connection", "close");
    //Display loading msg
    document.getElementById('divLoading').style.display = 'block';
    //OnReadyStateChange Event
    xmlHttp.onreadystatechange = function () {//Call a function when the state changes.
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            document.getElementById('divLoading').style.display = 'none';
            document.getElementById('divLoaded').style.display = 'block';
            setTimeout("HideLoadedDiv()", 1000);
        }
    }
    xmlHttp.send(params);
    //    /*-----------------------------------------------------------*/
    //    if(glb_PendSelectedID != '' && glb_PendSelectedID!=null )
    //        document.getElementById(glb_PendSelectedID).className='whiteBG';

    //    //-----------------------------------------------------------------------------
    //    //Make productive as default
    //        document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].selectedIndex = 1;
    //        if(document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'] != null)
    //        {
    //            GetLevelSteps(document.aspnetForm['rptrMMSTrackerLevels$ctl00$ddlLevel'].value,document.aspnetForm['rptrMMSTrackerLevels$ctl01$ddlLevel'],2,'rptrMMSTrackerLevels$ctl00$ddlLevel')
    //        }
    //    //-----------------------------------------------------------------------------        
    //    //Unlock the locked controls on startTime
    //        if(glb_lockedDDLControlID != null && glb_lockedDDLControlID != '')
    //            document.getElementById(glb_lockedDDLControlID).style.display = 'block';
    //        if(glb_lockedspanControlID != null && glb_lockedspanControlID != '')            
    //            document.getElementById(glb_lockedspanControlID).style.display = 'none';
    //    //------------------------------------------------------------------------------
    //Reset MMS entry
    MMSReset();
    return false;
}
function HideLoadedDiv() {
    document.getElementById('divLoaded').style.display = 'none';
}