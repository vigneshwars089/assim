﻿
function ValidateLocationFacility() {

    var facilityName = $('#ContentBody_txt_NewFacility').val().trim();
    var facilityID = $('#ContentBody_txtNewFacilityID').val().trim();
    if (facilityName == "" || facilityID == "") {
        $('#ContentBody_dvUserMessage').html("Please fill mandatory fields.");
        $('#ContentBody_dvUserMessage').attr('class', 'alert-box error');
        $('#ContentBody_dvUserMessage').css("visibility", 'visible');
        return false;
    }
    return true;
}

function ValidateNewLocation() {
    var newLocation = $('#ContentBody_txtNewLocation').val().trim();
    if (newLocation == "") {
        notify('Please fill mandatory fields', 'information');
        return false;
    }
    return true;
}

function fnIsNumber(Value, field) {
    if (!isNaN(Value))
        return true;
    else {
        notify(field + ' should be numeric.', 'information');
        return false;
    }
}

function fnValidateAccoutDetails() {
    //debugger;
    var Department = $("#ContentBody_ddl_department").val().trim();
    var Vertical = $("#ContentBody_ddl_vertical").val().trim();
    var accountName = $('#ContentBody_txt_NewAccount').val().trim();
    var accountID = $('#ContentBody_txt_NewAccountID').val().trim();

    if (Department == undefined || Vertical == undefined || Department == "0" || Vertical == "0") {
        notify('Please select both Department and Vertical.', 'information');
        return false;
    }
    if (accountID == "" || accountID == null || accountName == "" || accountName == null) {
        notify('Please fill mandatory fields.', 'information');
        return false;
    }
    else {
        return fnIsNumber(accountID, "Account ID");
    }
    return true;
    //if (accountName == "" || accountID == "") {
    //    //if(accountName=="")
    //    //    $('#ContentBody_txt_NewAccount').css('border-color', 'red');
    //    //if (accountID == "")
    //    //    $('#ContentBody_txt_NewAccountID').css('border-color', 'red');

    //    $('#ContentBody_dvAccountMessage').html("Please fill mandatory fields.");
    //    $('#ContentBody_dvAccountMessage').attr('class', 'alert-box error');
    //    $('#ContentBody_dvAccountMessage').css("visibility", 'visible');
    //    return false;
    //}
    //return true;
}

function fnValidateProjectDetails() {
    //debugger;
    var ProjectID = $('#ContentBody_txt_ProjectID').val().trim();
    if ($("#ContentBody_ddl_Vertical_Project").val().trim() == "0" ||
        $("#ContentBody_ddl_Vertical_Project").val().trim() == null ||
        $("#ContentBody_ddl_Vertical_Project").val().trim() == undefined) {
        notify('Please select Vertical', 'information');
        return false;
    }
    if (ProjectID == "" || $("#ContentBody_txt_ProjectID").val().trim() == null ||
        $("#ContentBody_txt_ProjectName").val().trim() == "" || $("#ContentBody_txt_ProjectName").val().trim() == null) {
        notify('Please fill mandatory fields', 'information');
        return false;
    }

    if (isNaN(ProjectID)) {
        notify("Project ID should be numeric", "information");
        return false;
    }
    var rows = $("#ContentBody_gv_ProjectMapping tr")
    for (i = 0; i < rows.length - 1; i++) {
        var value = $("#ContentBody_gv_ProjectMapping tr:eq(" + i + ") td:eq(0) span").html();
        if (ProjectID == value) {
            notify('Project ID already exists', 'information');
            return false;
        }
    }
    return true;
}
function fnValidateProjectUpdate(ctrl) {
    //debugger;
    var control = ctrl;
    var grdControl = ctrl.parentNode.parentNode;
    var ProjectName = $(grdControl.cells[1]).find("input").val().trim();
    var ProjectNameOld = $(grdControl.cells[1]).find("input[name$=hdn_ProjectName]").val().trim();
    var Vertical = $(grdControl.cells[2]).find("select option:selected").text();
    var VerticalOld = $(grdControl.cells[2]).find("input[name$=hdn_VerticalName]").val().trim();
    if (ProjectName == "" || ProjectName == null) {
        notify('Project Name is empty', 'information');
        return false;
    }
    else if (ProjectName == ProjectNameOld && Vertical == VerticalOld) {
        notify('No changes are made in the Project and Vertical Selection', 'information');
        return false;
    }
    return true;
}


function fnValidateConnectsDetails() {
    //debugger;
    var ProjectID = $('#ContentBody_txt_ConnectsName').val().trim();

    if (ProjectID == "" || $("#ContentBody_txt_ConnectsName").val().trim() == null) {
        notify('Please fill mandatory fields', 'information');
        return false;
    }

    //var rows = $("#ContentBody_gv_ProjectMapping tr")
    //for (i = 0; i < rows.length - 1; i++) {
    //    var value = $("#ContentBody_gv_ProjectMapping tr:eq(" + i + ") td:eq(0) span").html();
    //    if (ProjectID == value) {
    //        notify('Project ID already exists', 'information');
    //        return false;
    //    }
    //}
    return true;
}
//$(function () {

//    $('.alphanumeric').keyup(function () {
//        var yourInput = $(this).val();
//        re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
//        var isSplChar = re.test(yourInput);
//        if (isSplChar) {
//            var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
//            $(this).val(no_spl_char);
//        }
//    });


//    $(".numeric").keyup(function () {
//        {
//            var yourInput = $(this).val();
//            reg = /[^0-9]/g;
//            $(this).val(yourInput.replace(reg, ""));
//        }
//    });


//    $(".alphabetic").keyup(function () {
//        {
//            var yourInput = $(this).val();
//            reg = /[[^a-z|^A-Z]]/g;
//            $(this).val(yourInput.replace(reg, ""));
//        }
//    });

//});


$(function () {

    $('.alphanumeric').on("keyup", function (event) {
        var yourInput = $(this).val();
        re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
        var isSplChar = re.test(yourInput);
        if (isSplChar) {
            var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
            $(this).val(no_spl_char);
        }
    });
    $('.alphanumericQ').on("keyup", function (event) {
        var yourInput = $(this).val();
        re = /[`~!@#$%^&*()_|+\-=;:'",.<>\{\}\[\]\\\/]/gi;
        var isSplChar = re.test(yourInput);
        if (isSplChar) {
            var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=;:'",.<>\{\}\[\]\\\/]/gi, '');
            $(this).val(no_spl_char);
        }
    });
    $('.alphanumericH').on("keyup", function (event) {
        var yourInput = $(this).val();
        re = /[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
        var isSplChar = re.test(yourInput);
        if (isSplChar) {
            var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi, '');
            $(this).val(no_spl_char);
        }
    });
    $('.alphanumericS').on("keypress", function (event) {
        {
            keyEntry = event.keyCode;
            if (keyEntry != '32')
                return true;
            else {
                return false;
            }
        }
    });

    $(".numeric").on("keyup", function (event) {
        {
            var yourInput = $(this).val();
            reg = /[^0-9]/g;
            $(this).val(yourInput.replace(reg, ""));
        }
    });


    $(".alphabetic").on("keypress", function (event) {
        {
            keyEntry = event.keyCode;
            if (((keyEntry >= '65') && (keyEntry <= '90')) || ((keyEntry >= '97') && (keyEntry <= '122')) || (keyEntry == '46') || (keyEntry == '32') || keyEntry == '45')
                return true;
            else {

                return false;
            }
        }
    });

    var prm = Sys.WebForms.PageRequestManager.getInstance();

    prm.add_endRequest(function () {
        $('.alphanumeric').on("keyup", function (event) {
            var yourInput = $(this).val();
            re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
            var isSplChar = re.test(yourInput);
            if (isSplChar) {
                var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
                $(this).val(no_spl_char);
            }
        });
        $('.alphanumericQ').on("keyup", function (event) {
            var yourInput = $(this).val();
            re = /[`~!@#$%^&*()_|+\-=;:'",.<>\{\}\[\]\\\/]/gi;
            var isSplChar = re.test(yourInput);
            if (isSplChar) {
                var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=;:'",.<>\{\}\[\]\\\/]/gi, '');
                $(this).val(no_spl_char);
            }
        });
        $('.alphanumericH').on("keyup", function (event) {
            var yourInput = $(this).val();
            re = /[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
            var isSplChar = re.test(yourInput);
            if (isSplChar) {
                var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi, '');
                $(this).val(no_spl_char);
            }
        });

        $('.alphanumericS').on("keypress", function (event) {
            {
                keyEntry = event.keyCode;
                if (keyEntry != '32')
                    return true;
                else {
                    return false;
                }
            }
        });
        $(".numeric").on("keyup", function (event) {
            {
                var yourInput = $(this).val();
                reg = /[^0-9]/g;
                $(this).val(yourInput.replace(reg, ""));
            }
        });

        $(".alphabetic").on("keypress", function (event) {
            {
                keyEntry = event.keyCode;
                if (((keyEntry >= '65') && (keyEntry <= '90')) || ((keyEntry >= '97') && (keyEntry <= '122')) || (keyEntry == '46') || (keyEntry == '32') || keyEntry == '45')
                    return true;
                else {

                    return false;
                }
            }
        });
    });


});

