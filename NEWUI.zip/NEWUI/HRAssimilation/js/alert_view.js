function notify(message, type, timeout) {
    // default values
    

    message = typeof message !== 'undefined' ? message : '';//Hello!
    type = typeof type !== 'undefined' ? type : 'success';
    timeout = typeof timeout !== 'undefined' ? timeout : 5000;

    $('#divNotification').dialogBox({
        width: 780,
        //
        //width: 'auto',
        autoOpen: false,
        resizable: false,
        modal: true,
        //changes done by shraddha to resize the dialogbox according to content
        hasMask: true,
        hasClose: true,
        autoHide: true,
        //hasBtn: true,
        autoSize: true,
        time: timeout,
        effect: 'flip-horizontal',
        title: 'Message',
        content: '<html><head><title>Test</title></head><body style=\"background:#FFFFFF\"><div id=\"notifymsg\" style=\"width: auto; height: auto; background-color: white; color: black; font-family: Verdana; font-size: 1.0em; \"></div></body></html>',
        callback: function () {
            document.getElementById("notifymsg").innerText = message;
        }
    });
    $(".tooltip").show();

    //// append markup if it doesn't already exist
    //if ($('#notification').length < 1) {
    //    markup = '<div id="notification" class="information"><div style="width:40%;float:left;">&nbsp;</div><div style="width:40%;float:left;"><p id="notifymsg" style="text-align:left;"></p></div><a class="close" href="#">x</a></div>';
    //    $('body').append(markup);
    //}

    //// elements
    //$notification = $('#notification');
    //$notificationSpan = $('#notification p');
    //$notificationClose = $('#notification a.close');

    //// set the message

    //document.getElementById("notifymsg").innerText = message;
    //// setup click event
    //$notificationClose.click(function (e) {
    //    (e.preventDefault) ? e.preventDefault() : e.returnValue = false;
    //    $notification.css('top', '-550px');
    //});

    ////// for ie6, scroll to the top first
    ////if ($.browser.msie && $.browser.version < 7) {
    ////    $('html').scrollTop(0);
    ////}

    //var isIEVersion = getIEVersion();

    //if (parseInt(isIEVersion) < 7) {
    //    $('html').scrollTop(0);
    //}

    //// hide old notification, then show the new notification
    //$notification.css('top', '-550px').stop().removeClass().addClass(type).animate({
    //    top: 0
    //}, 500, function () {
    //    $notification.delay(timeout).animate({
    //        top: '-650px'
    //    }, 500);
    //});
}

function notifyalert(type) {
    var msg = "";

    if (document.getElementById("divcustommessage") != null)
        msg = document.getElementById("divcustommessage").innerText;
    notify(msg, type);

}



function getIEVersion() {
    var version = null;
    var agentStr = navigator.userAgent;
    if (agentStr.indexOf("MSIE 7.0") > -1 || agentStr.indexOf("Mozilla") > -1) {
        if (agentStr.indexOf("Trident/6.0") > -1) {
            version = '10';//Iexplore version
        } else if (agentStr.indexOf("Trident/5.0") > -1) {
            version = '9';
        } else if (agentStr.indexOf("Trident/4.0") > -1) {
            version = '8';
        } else if (agentStr.indexOf("Trident/7.0") > -1) {
            version = '11';
        }
        else {
            version = '7';
        }
    }
    return version;
}

function notify_footer(message, type, timeout) {
    // default values

    message = typeof message !== 'undefined' ? message : '';//Hello!
    type = typeof type !== 'undefined' ? type : 'success';
    timeout = typeof timeout !== 'undefined' ? timeout : 3000;

    // append markup if it doesn't already exist
    if ($('#notification1').length < 1) {
        markup = '<div id="notification1" class="information" style="vertical-align:top;"><div style="width:100%;float:left;"><p id="notifymsg1" style="text-align:center;"></p></div><div style="width:100%;float:left;vertical-align:top;">&nbsp;</div></div>';
        $('body').append(markup);
    }

    // elements
    $notification = $('#notification1');
    $notificationSpan = $('#notification1 p');
    $notificationClose = $('#notification1 a.close');

    // set the message

    document.getElementById("notifymsg1").innerText = message;
    // setup click event
    var pageheight = $(window).height();
    //alert(pageheight);
    pageheight = pageheight + 100;
    $notificationClose.click(function (e) {
        (e.preventDefault) ? e.preventDefault() : e.returnValue = false;
        $notification.css('top', (pageheight+'px'));
    });

    // for ie6, scroll to the top first
    //if ($.browser.msie && $.browser.version < 7) {
    //    $('html').scrollTop(0);
    //}

    var isIEVersion = getIEVersion();

    if (parseInt(isIEVersion) < 7) {
        $('html').scrollTop(0);
    }

    // hide old notification, then show the new notification
    $notification.css('top', (pageheight + 'px')).stop().removeClass().addClass(type).animate({
        bottom: 12
    }, -10, function () {
        $notification.delay(0).animate({
            top: (pageheight-180)+'px'
        });
    }).animate({

        'top': (pageheight + 'px')

    }, 15000, function () {
        $("#test").hide();
    });
}

function notifyalert_footer(type) {
    var msg = "";

    if (document.getElementById("divcustommessagefooter") != null)
        msg = document.getElementById("divcustommessagefooter").innerText;
    notify_footer(msg, type);

}
