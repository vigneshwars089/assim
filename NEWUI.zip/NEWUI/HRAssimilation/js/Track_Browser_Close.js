﻿$(document).ready(function () {
    
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    var version = navigator.appVersion;
    if (isIE)
    {
        if((window.ActiveXObject) && "ActiveXObject" in window)
            window.location.href = "../ErrorPages/UnsupportedBrowser.html"
    }
    else
    if (!isIE)
    {        
        window.location.href = "../ErrorPages/UnsupportedBrowser.html"
    }
    var validNavigation = 0;
    var checkAddressBarClick = 0;

    $(document).mousemove(function (e) {
        y = e.pageY;
        x = e.pageX;
        if (y <= 5 && x <= 600) {
            checkAddressBarClick = 1;
        }
        //else if (y <= 5) {
        //    validNavigation = 0;
        //}
        else {
            checkAddressBarClick = 0;
        }
    });

    document.onkeydown = keydown;
    function keydown(evt) {
        if (!evt) evt = event;
        if (evt.keyCode == 116) {
            validNavigation = 1;
        }
        if (evt.altKey && evt.keyCode == 115) {
            $.ajax({
                url: "Logout.aspx/KillLoggedInSession",
                type: "POST",
                data: "{}",
                cache: false,
                async: false,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (result) {
                },
                error: function (result) {
                }
            });
        }
    }
    // Attach the event click for all links in the page
    $("a").bind("click", function () {
        validNavigation = 1;
    });

    // Attach the event submit for all forms in the page
    $("form").bind("submit", function () {
        validNavigation = 1;
    });

    // Attach the event click for all inputs in the page
    $("input[type=submit]").bind("click", function () {
        validNavigation = 1;
    });
    $("input[type=image]").bind("click", function () {        
        validNavigation = 1;
    });
    $("input[type=radio]").bind("click", function () {
        validNavigation = 1;
    });
    $("select option").bind("click", function () {
        validNavigation = 1;
    });

    window.onbeforeunload = function (e) {
        if (event) {            
            if (validNavigation == 0 && checkAddressBarClick == 0) {               
                $.ajax({
                    url: "Logout.aspx/KillLoggedInSession",
                    type: "POST",
                    data: "{}",
                    cache: false,
                    async: false,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (result) {                        
                    },
                    error: function (result) {                        
                    }
                });
            }
        }
    };
});