﻿var gtec = (function () {
    return {
        cockpit: {
            blockUI: function () {
                $.blockUI({
                    css: {
                        border: 'none',
                        backgroundColor: 'transparent',
                        width: '100%',
                        left: '0px'
                    },
                    message: '<center><div class="ui-widget-content ui-corner-all ui-gtec-loader">Loading...</div></center>'
                });
            },
            unblockUI: function () {
                $.unblockUI();
            },
            block: function (selector) {
                $(selector).block({
                    css: {
                        border: 'none',
                        backgroundColor: 'transparent',
                        width: '100%',
                        left: '0px'
                    },
                    message: '<center><div class="ui-widget-content ui-corner-all ui-gtec-loader">Loading...</div></center>'
                });
            },
            unblock: function (selector) {
                $(selector).unblock();
            },
            confirmDelete: function () {
                return confirm('Are you sure you want to delete record?');
            }
        }
    };
})();