﻿
//Description : function for hide and showing Div Content Areas based on parameters
//usage : commonly used on all report pages.
function HideNShow(hideID, showID) {
    document.getElementById(hideID).style.display = 'block';
    document.getElementById(showID).style.display = 'none';
}



//function ValidateListView() {
//    var txt = lstView.FindControl("txtLevel2").val(); 
//    alert(txtLevel2.value);

//    alert("txt = " + txtLevel2);
//    if (txtLevel2.value == 0) {
//        alert("Job Description Cannot Be Blank...!");
//        
//        return false;
//    }
//    else {
//        return true;
//    } 

//}
//Description : function used to validate Edit Mode text boxes for gridview
//usage : commonly used in all gridview where edit mode is applicable
function ValidateText(controlID) {
    //alert(controlID);
    var strInput = document.aspnetForm[controlID].value;
    if (strInput == '') {
        alert("The name should not be empty");
        document.aspnetForm[controlID].focus();
        return false;
    }
    return true;
}
//Description : function used to validate Edit Mode text boxes for gridview
//usage : commonly used in all gridview where edit mode is applicable
function PrintContent() {
    var sOption = "toolbar=no,location=no,directories=no,menubar=yes,scrollbars=yes,width=750,height=700,left =100,top=25";
    var sWinHTML = document.getElementById('divPrintContent').innerHTML;
    var winprint = window.open("../test/WebForm2.aspx", "summarReportPrint", sOption);
    var strMsg = '<meta http-equiv="Content-Type" content="application/vnd.ms-excel;charset=utf-8" >';
    strMsg = strMsg + sWinHTML;
    strMsg = strMsg + "</form>";
    strMsg = strMsg + "</body></HTML>";
    winprint.document.open();
    winprint.document.write(strMsg);
    winprint.focus();
}

//used in source pages for custom asp.net validator
//1.checking for any characters other than numerics and '.'
function validateSourceInput(sender, args) {
    var inputValue = args.Value;
    if (isNaN(inputValue)) {
        args.IsValid = false;
        return;
    }
    args.IsValid = true;
}
//Removing all options from selectbox
function removeAllOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        //selectbox.options.remove(i);
        selectbox.remove(i);
    }
}
//Add one new option to selectBox(ie dropdown box)
function addOption(selectbox, value, text) {
    var optn = document.createElement("OPTION");
    optn.text = text;
    optn.value = value;
    selectbox.options.add(optn);
}

//Date Popup box
function DatePopup(txtBoxID) {
    window.open("../DatePopup.aspx?txtdateID=" + txtBoxID + "&formid=aspnetForm&nc=" + Math.random(), 'DateRAG', 'height=245,width=210,left=650,top=200,menubars=no,scrollbars=no,resizable=no');
}
//Ajax Function
function ajaxFunction() {
    var xmlHttp;
    try {
        // Firefox, Opera 8.0+, Safari  
        xmlHttp = new XMLHttpRequest();
    }
    catch (e) {  // Internet Explorer  
        try {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            try {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                alert("Your browser does not support AJAX!, Contact Application support");
                return false;
            }
        }
    }
}

/* Prevent window from closing */
//function onBeforeUnloadAction()
//{
//    var flag = window.confirm("You are closing the window. do you want to continue. Click 'Ok' to close or click 'Cancel' to stay back");
//    if(flag) 
//    { 
//        alert("bye");
//        return true;
//    } 
//    else 
//    { 
//        return false;
//    }
//}
//window.onbeforeunload = function(){if((window.event.clientX<0) || (window.event.clientY<0)){return onBeforeUnloadAction();}}

/*-------------------------------*/
