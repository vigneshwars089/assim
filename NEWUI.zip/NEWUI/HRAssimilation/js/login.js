﻿function validateLoginControls() {
    if ($('#ContentBody_txtbox_UserID').val() == "" || $('#ContentBody_txtbox_Password').val() == "") {
        $('#ContentBody_dvError').html("The user id or password you entered isn't correct. Try entering it again.");
        $('#ContentBody_dvError').addClass('alert-box error');
        $('#ContentBody_dvUserMessage').hide();
        return false;
    }
    return true;
}