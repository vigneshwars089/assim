﻿
namespace HRAssimilation.Entity
{
    public class AssociateDetails
    {
        public string AssociateID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }        
        public string EmailID { get; set; }
        public string LocationCode { get; set; }
        public string DepartmentID { get; set; }
        public string VerticalID { get; set; }
        public string AccountID { get; set; }
        public string ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string DepartmentName { get; set; }
        public string AssociateName { get; set; }
        public string LocationID { get; set; }
        public string Location { get; set; }
        public string SubLocationCode { get; set; }
        public string HireDate { get; set; }
        public string SupervisorID { get; set; }
        public string Designation { get; set; }
        public string DesignationatHire { get; set; }
        public string SupervisorName { get; set; }
        public string DateOfBirth { get; set; }
        public string SubLocation { get; set; }
        public string AccountName { get; set; }
        public string VerticalName { get; set; }
        public string Tenure { get; set; }
        public string LastResignationDate { get; set; }
        public string LastResignationWithdrawlDate { get; set; }
        public string LastJARaisedDate { get; set; }
        public string LastResignationReason { get; set; }
        public string LastResignationWithdrawlReason { get; set; }
        public string LastJAReason { get; set; }
        public string DetailedReasonforResignation { get; set; }
        public string DiscussionwithManager { get; set;}
        public string RetentionDiscussionwithAssociate {get; set;}
        public string LastWorkingDate {get; set;}
        public string LastWorkingDayUpdatedinSystem {get; set;}
        public string DetailedReasonforJA {get; set;}
        public string JARevoked  {get; set;}
        public string JARevokedDate {get; set;}
        public string OverrideHCM { get; set; }
        public string status { get; set; }
        public string Level { get; set; }
        public string TerminataionStatus { get; set; }
        public string ResignataionReport { get; set; }
        public string EWSStatus { get; set; }
        public string TMPOC { get; set; }
        public string LastMetDate { get; set; }
        public string Message { get; set; }
        public string ResignationWithdrawalStatus { get; set; }
        public string JobCodeDescription { get; set; }

        }
   }
   

