﻿namespace HRAssimilation.Entity
{
    public class Constant
    {
        public readonly string POCConnectSP = "SP_GetConnectAndEwsDtls";
        public readonly string SP_GetStatus = "SP_GETStatusDetail";
    }
}
