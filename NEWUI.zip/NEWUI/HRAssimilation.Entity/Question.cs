﻿
namespace HRAssimilation.Entity
{
    public class Question
    {
        public string QuestionID { get; set; }
        public string QuestionDescription { get; set; }
        public string Weightage { get; set; }
        public string CreatedBy { get; set; }
    }
}
