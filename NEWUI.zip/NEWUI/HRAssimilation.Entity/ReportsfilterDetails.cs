﻿
namespace HRAssimilation.Entity
{
    public class ReportsfilterDetails
    {
        public string Year { get; set; }
        public string Month { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string Location { get; set; }
        public string Facility { get; set; }
        public string Department { get; set; }
        public string Vertical { get; set; }
        public string Account { get; set; }
        public string Reason { get; set; }
        public string Designation { get; set; }
        public string Tenure { get; set; }
        public string Status { get; set; }
        public string TalentMAnager { get; set; }
        public string Role { get; set; }
        public string TMPOC { get; set; }
        public bool IncludeNewJoiners { get; set; }
        public string ConnectType { get; set; }
        public string ActionType { get; set; }
    }
}
