﻿
namespace HRAssimilation.Entity
{
    public class UserLocationMappingDetails
    {
        public string User_Location { get; set; }
        public string Location { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }
}
