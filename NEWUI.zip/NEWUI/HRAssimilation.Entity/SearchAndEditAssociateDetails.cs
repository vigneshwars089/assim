﻿
namespace HRAssimilation.Entity
{
    /// <summary>
    /// SearchAndEditAssociateDetails will help in getting the user and user's location details and edit them
    /// </summary>
    public class SearchAndEditAssociateDetails
    {
        public string AssociateID { get; set; }
        public string Location { get; set; }
        public string SubLocation { get; set; }
        public string Account { get; set; }
        public string AccountName { get; set; }
        public string Vertical { get; set; }
        public string ProjectID { get; set; }
        public string SupervisorID { get; set; }
        public string SupervisorName { get; set; }
        public string LastResignationReason { get; set; }
        public string LastWithdrawlReason { get; set; }
        public string LastJAReason { get; set; }
        public string DetailedReasonforResignation { get; set; }
        public string DiscussionwithManager { get; set; }
        public string RetentionDiscussionwithAssociate { get; set; }
        public string LastWorkingDay { get; set; }
        public string LastWorkingDayUpdatedinSystem { get; set; }
        public string DetailedReasonforJA { get; set; }
        public string JARevoked { get; set; }
        public string JARevokedDate { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string JArevokedDate { get; set; }
        public string LastworkingDayUpdatedinSystem { get; set; }
        public string Facility { get; set; }
        public string LastResignationWithdrawlReason { get; set; }

        public string DepartmentID { get; set; }
        public string OverrideHCM { get; set; }
    }
}
