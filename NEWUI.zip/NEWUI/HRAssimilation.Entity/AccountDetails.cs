﻿
namespace HRAssimilation.Entity
{
    public class AccountDetails
    {
        public string ID { get; set; }
        public string AccountID { get; set; }
        public string AccountName { get; set; }
        public string VerticalID { get; set; }
        public string VerticalName { get; set; }
        public string DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public string CreatedBy { get; set; }
        public string PrevAccountID { get; set; }
    }

    public class FacilityDtls
    {
        public string FacilityCode { get; set; }
        public string FacilityName { get; set; }
        public string FacilityID { get; set; }
        public string PrevFacilityCode { get; set; }
    }
    public class ProjectDetails
    {
        public string Action { get; set; }
        public string ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string VerticalID { get; set; }
        public string RowID { get; set; }
        public string UserID { get; set; }
    }
    public class ConnectDetails
    {

        public string Action { get; set; }
        public string ConnectName { get; set; }
    }
}
