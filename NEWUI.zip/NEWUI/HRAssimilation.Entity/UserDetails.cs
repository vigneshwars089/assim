﻿
namespace HRAssimilation.Entity
{
    public class UserDetails
    {
        public string UserID { get; set; }
        public string Password { get; set; }
        public string CognizantID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailID { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string IsActive { get; set; }
        public string Error_msg { get; set; }
        
    }
    public class TrackUsers
    {
        public string UserID { get; set; }
        public string SessionID { get; set; }
        public string Action { get; set; }
    }
}
