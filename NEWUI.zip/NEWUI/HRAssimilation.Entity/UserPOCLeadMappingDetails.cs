﻿
namespace HRAssimilation.Entity
{
    public class UserPOCLeadMappingDetails
    {
        public string TMPOCs { get; set; }
        public string TMLead { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }

    public class TMPOCDetails
    {
        public string TMPOCs { get; set; }
        public string Location { get; set; }
        public string AccountCode { get; set; }
        public string AccountId { get; set; }
        public string FacilityCode { get; set; }
        public string ProjectID { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string VerticalID { get; set; }
    }



    public class TmpocConnectTrackMaping
    {
        public string AssociateID { get; set; }
        public string AssociateName { get; set; }
        public string TLEWSStatus { get; set; }
        public string EWSStatus { get; set; }
        public string SubmittedBy { get; set; }
        public int IsSubmitted { get; set; }        
        public string TMPOCComment { get; set; }
        public string ConnectDate { get; set; }

    }

    public class TmpocEwsstatusindetail
    {
        public string SubmittedBy { get; set; }
        public string Description { get; set; }
        public int QuestionID { get; set; }
        public int Weightage { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
    }

    public class ConnectTypedtls
    {
        public string AssociateID { get; set; }
        public string AssociateName { get; set; }
        public string SelConnectType { get; set; }
        public string SubmittedBy { get; set; }
        public string Comments { get; set; }
        public string ConnectDate { get; set; }
        public string EWS { get; set; }
        public string Email { get; set; }
    }

    public class ConnectEWSDetails
    {   
        public string AssociateID { get; set; }
        public string SubmittedBy { get; set; }
        public string SubittedDate { get; set; }
        public string Comments { get; set; }
        public string sEwsstatus { get; set; }
        public string TLEWSStatus { get; set; }
        public string RecentDate { get; set; }
        public string ConnectType { get; set; }
        public string EWSStatus1 { get; set; }
        public string EWSStatus2 { get; set; }
        public string EWSStatus3 { get; set; }

    }
    public class ConnectEWSDetailsTracker
    {
        public string AssociateID { get; set; }
        public string SubmittedBy { get; set; }
        public string SubittedDate { get; set; }
        public string Comments { get; set; }
        public string sEwsstatus { get; set; }
        public string TLEWSStatus { get; set; }
        public string RecentDate { get; set; }
        public string ConnectType { get; set; }
        public string EWSStatus1 { get; set; }
        public string EWSStatus2 { get; set; }
        public string EWSStatus3 { get; set; }

    }

    public class InsertorupdateinResignation
    {
        public string AssociateID { get; set; }
        public string DetailedReasonforResignation { get; set; }
        public string DiscussionwithManager { get; set; }
        public string RetentionDiscussionwithAssociate { get; set; }
        public string LastWorkingDate { get; set; }
        public string LastworkingDayUpdatedinSystem { get; set; }
        public string DetailedReasonforJA { get; set; }
        public string Jarevoked { get; set; }
        public string JARevokedDate { get; set;}
        public string CreatedBy { get; set; }
    }
}
