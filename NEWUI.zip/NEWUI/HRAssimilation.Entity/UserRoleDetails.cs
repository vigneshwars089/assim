﻿
namespace HRAssimilation.Entity
{
    public class UserRoleDetails
    {
        public string Users_Role { get; set; }
        public string Roles { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string ErrorMsg { get; set; }
    }
}
