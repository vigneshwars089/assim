﻿
namespace HRAssimilation.Entity
{
    public class TMPOCAccount
    {
        public string AssociateID { get; set; }
        public string LocationCode { get; set; }
        public string AccountID { get; set; }
        public string CreatedBy { get; set; }
        public string IsActive { get; set; }
        public string ModifiedBy { get; set; }
        public string VerticalID { get; set; }
        public string ProjectID { get; set; }
    }
}
