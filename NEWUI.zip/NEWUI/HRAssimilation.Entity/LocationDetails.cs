﻿
namespace HRAssimilation.Entity
{
     public class LocationDetails
    {
         public string Location { get; set; }
         public string CreatedBy { get; set; }
         public string Description { get; set; }
         public string LocationCode { get; set; }         
    }
}
