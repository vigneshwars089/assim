﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Web.UI.WebControls;


namespace HRAssimilation.Data
{
    public static class Excel_Read
    {
        public static DataSet Read_ExcelData(FileUpload fuUpload, string FilePath)
        {
            DataSet ds = new DataSet();
            System.Data.DataTable dtSheetError = new System.Data.DataTable();



            string strConn = string.Empty;

            if (Directory.Exists(HttpContext.Current.Server.MapPath("Uploadfiles") + "\\" + FilePath))
            {

            }
            else
            {
                Directory.CreateDirectory(HttpContext.Current.Server.MapPath("Uploadfiles") + "\\" + FilePath);
            }

            fuUpload.PostedFile.SaveAs(HttpContext.Current.Server.MapPath("Uploadfiles") + "\\" + FilePath + "\\" + Path.GetFileName(fuUpload.PostedFile.FileName));



            string fileName = HttpContext.Current.Server.MapPath("Uploadfiles") + "\\" + FilePath + "\\" + Path.GetFileName(fuUpload.PostedFile.FileName);
            //  string fileName = Path.GetFileName(fuUpload.PostedFile.FileName);
            // OleDbConnection oledbConn = new OleDbConnection(fileName);

            string excelConstring = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + @";Extended Properties=" +
             Convert.ToChar(34).ToString() + @"Excel 12.0 Xml;IMEX=1;HDR=YES;" + Convert.ToChar(34).ToString();

            //string excelConstring = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties=\"Excel 12.0 Xml;HDR=YES;\"";

            OleDbConnection oledbConn = new OleDbConnection(excelConstring);

            oledbConn.Open();
            System.Data.DataTable dt = new System.Data.DataTable();
            dt = oledbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            oledbConn.Close();


            dtSheetError.Columns.Add(new DataColumn("Error"));
            dtSheetError.AcceptChanges();



            try
            {
                if (dt.Rows[0][2].ToString() == "Sheet1$")
                {
                    OleDbCommand cmd = new OleDbCommand("select * from [Sheet1$]", oledbConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                else
                {
                    DataRow dr = dtSheetError.NewRow();
                    dr[0] = "SHEET NAME ERROR";
                    dtSheetError.Rows.Add(dr);
                    ds.Tables.Add(dtSheetError);
                    return ds;
                }

            }
            catch (Exception ex1)
            {
                if (dt.Rows[0][2].ToString() == "Sheet1$")
                {
                    OleDbCommand cmd = new OleDbCommand("select * from [Sheet1$]", oledbConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                else
                {
                    DataRow dr = dtSheetError.NewRow();
                    dr[0] = "SHEET NAME ERROR";
                    dtSheetError.Rows.Add(dr);
                    ds.Tables.Add(dtSheetError);
                    return ds;
                }
            }
        }

        public static string GenerateExcelReport(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();
            int columncount = _result.Columns.Count;

            strResult.Append(@"<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'><head><title>Time</title>");
            strResult.Append(@"<body lang=EN-US style='mso-element:header' id=h1><span style='mso--code:DATE'></span><div class=Section1>");
            strResult.Append("<DIV  style='font-size:12px;'>");
            strResult.Append("<table cellspacing='0' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("            <tr  align='Center' style='color:White ; background-color: #535250; border-width: 1px; border-style: Solid; font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < columncount; i++)
            {
                strResult.Append("                <td> ");
                strResult.Append("                    " + _result.Columns[i].Caption + " </td> ");
            }

            strResult.Append("            </tr> ");
            int j = 0;


            for (j = 0; j < _result.Rows.Count; j++)
            {
                if (Math.IEEERemainder(j, 2) == 0)
                    strResult.Append("            <tr align='left' valign='middle' style='color: #333333; border-color: #C5D5E7; border-width: 1px; border-style: Solid; font-family: Arial; font-size: 12px; font-weight: normal ;height: 18px;'> ");
                else
                    strResult.Append("            <tr align='left' valign='middle' style='height: 18px; font-weight: normal; font-size: 12px; font-family: Arial;color: #333333; border-width: 1px; border-style: Solid; border-color: #C5D5E7;'> ");

                for (int k = 0; k < columncount; k++)
                {

                    strResult.Append("                <td align='Center' valign='middle'> ");
                    strResult.Append("                    " + _result.Rows[j][k].ToString() + "  ");
                }
            }
            strResult.Append("        </table> ");

            strResult.Append("</div></body></html>");

            return strResult.ToString();
        }

        public static string GenerateExcelReportVertical(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();

            DataTable dt = _result;
            int columnCount = dt.Columns.Count;
            int Rowscount = dt.Rows.Count;

            var VerticalRow = from row in dt.AsEnumerable()
                              group row by row.Field<string>("Vertical") into vertical
                              orderby vertical.Key
                              select new
                              {
                                  Name = vertical.Key,
                                  CountOfVertical = vertical.Count()
                              };
            var MonthRow = from row in dt.AsEnumerable()
                           group row by row.Field<string>("Month") into month
                           select new
                           {
                               Name = month.Key,
                               CountOfVertical = month.Count()
                           };
            // #region start
            strResult.Append("<table cellspacing='0' rules='all' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");

            strResult.Append("                <th rowspan='2' bgcolor='#999'>" + "Month" + "</th> ");

            foreach (var item in VerticalRow)
            {
                strResult.Append("                <th colspan='2' bgcolor='#999'>" + item.Name + "</th> ");
            }

            strResult.Append("                <th rowspan='2' bgcolor='#999'>" + "Total" + "</th> ");

            //Appendig subheaders
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < VerticalRow.Count(); i++)
            {
                strResult.Append("                <th bgcolor='#999'>No of Resignation</th>");
                strResult.Append("                <th bgcolor='#999'>No of JA</th> ");

            }

            strResult.Append("            </tr> ");
            strResult.Append("            </tr> ");

            //--- Data

            DataRow[] dr = null;
            DataRow[] drlocn = null;


            DataView viw = new DataView(dt);
            DataTable distinctMonths = viw.ToTable(true, "Month");
            DataTable da = null;
            DataTable di = null;
            //Adding rows
            
            foreach (DataRow drm in distinctMonths.Rows)
            {

                da = FilterRows(dt,"Month = '" + drm["Month"] + "'").CopyToDataTable();

                strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                strResult.Append("                <td>" + drm["Month"].ToString() + "</td>");
                int tot = 0;
                foreach (var items in VerticalRow)
                {
                    if (FilterRows(da, "Vertical = '" + items.Name + "'").Count() > 0)
                    {
                        di = FilterRows(da, "Vertical = '" + items.Name + "'").CopyToDataTable();

                        if (di.Rows.Count > 0)
                        {
                            foreach (DataRow drv in di.Rows)
                            {
                                strResult.Append("                <td>" + drv["Number of Resignation"].ToString() + "</td>");
                                strResult.Append("                <td>" + drv["Number of JA"].ToString() + "</td>");
                                tot = tot + Convert.ToInt32(drv["Number of Resignation"]) + Convert.ToInt32(drv["Number of JA"]);
                            }
                        }
                        else
                        {
                            strResult.Append("                <td>0</td>");
                            strResult.Append("                <td>0</td>");
                        }
                    }
                    else
                    {
                        strResult.Append("                <td>0</td>");
                        strResult.Append("                <td>0</td>");
                    }
                }
                strResult.Append("                <td>" + tot + "  </td>");
                strResult.Append("            </tr> ");
            }


            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <td> Total </td>");

            DataView view = new DataView(dt);
            DataTable distinctVerticals = view.ToTable(true, "Vertical");

            int finalTotal = 0;
            int R, j;
            DataTable dv = null;
            for (int i = 0; i < distinctVerticals.Rows.Count; i++)
            {
                dv = FilterRows(dt, "Vertical ='" + distinctVerticals.Rows[i]["Vertical"] + "'").CopyToDataTable();
                R = Convert.ToInt32(dv.Compute("SUM([Number of Resignation])", string.Empty));
                j = Convert.ToInt32(dv.Compute("SUM([Number of JA])", string.Empty));
                strResult.Append("                <td>" + R + "</td>");
                strResult.Append("                <td>" + j + "</td>");
                finalTotal = finalTotal + R + j;
            }
            strResult.Append("                <td>" + finalTotal + "</td>");
            strResult.Append("            </tr> ");

            //---
            strResult.Append("        </table> ");
            return strResult.ToString();
        }
        public static string GenerateExcelAttritionrepReport(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();

            DataTable dt = _result;
            int columnCount = dt.Columns.Count;
            int Rowscount = dt.Rows.Count;
            var iLocationCount = from row in dt.AsEnumerable()
                                 group row by row.Field<string>("Location") into Location
                                 orderby Location.Key
                                 select new
                                 {
                                     Name = Location.Key,
                                     CountOfVertical = Location.Count(),
                                 };

            var VerticalRow = from row in dt.AsEnumerable()
                              group row by row.Field<string>("Vertical") into vertical
                              orderby vertical.Key
                              select new
                              {
                                  Name = vertical.Key,
                                  CountOfVertical = vertical.Count()
                              };

            // #region start
            strResult.Append("<table cellspacing='0' rules='all' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < columnCount - 3; i++)
            {

                strResult.Append("                <th rowspan='2' bgcolor='#999'>" + dt.Columns[i].Caption.ToString() + "</th> ");
            }
            foreach (var item in iLocationCount)
            {
                strResult.Append("                <th colspan='2' bgcolor='#999'>" + item.Name + "</th> ");
            }
            strResult.Append("            </tr> ");

            //Appendig subheaders
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < iLocationCount.Count(); i++)
            {
                strResult.Append("                <th bgcolor='#999'>No of Resignation</th>");
                strResult.Append("                <th bgcolor='#999'>No of JA</th> ");

            }
            strResult.Append("            </tr> ");

            DataRow[] dr = null;
            DataRow[] drlocn = null;
            DataTable dta = null;
            //DataView viw = null;
            DataTable distinctAccounts;
            //Adding rows

            foreach (var item in VerticalRow)
            {
                List<string> accounts = new List<string>();
                dr = dt.Select("Vertical = '" + item.Name.ToString() + "'");

                dta = dt.Select("Vertical = '" + item.Name.ToString() + "'").CopyToDataTable();
                       
                //viw = new DataView(dta);
                distinctAccounts = dta.DefaultView.ToTable(true, "Account Name");

                strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                strResult.Append("                <td rowspan=" + distinctAccounts.Rows.Count + ">" + item.Name + "</td>");

                for (int k = 0; k < dr.Count(); k++)
                {
                    if (!accounts.Contains(dr[k]["Account Name"].ToString()))
                    {
                        if (k > 0)
                        {
                            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                        }

                        strResult.Append("                <td>" + dr[k]["Account Name"].ToString() + "</td>");
                        accounts.Add(dr[k]["Account Name"].ToString());
                        drlocn = dt.Select("Vertical = '" + item.Name.ToString() + "' and [Account Name] = '" + dr[k]["Account Name"].ToString() + "'").OrderBy(u => u["Location"]).ToArray();

                        // for (int i = 0; i < drlocn.Count(); i++) 
                        {
                            foreach (var items in iLocationCount)
                            {
                                var sdata = drlocn.Where(r => r.Field<string>("Location").ToLower().Equals(items.Name.ToLower()));

                                if (sdata.Count() > 0)
                                {
                                    foreach (var slocn in sdata)
                                    {
                                        strResult.Append("                <td>" + slocn["Number of Resignation"].ToString() + "</td>");
                                        strResult.Append("                <td>" + slocn["Number of JA"].ToString() + "</td>");
                                    }
                                }
                                else
                                {
                                    strResult.Append("                <td> </td>");
                                    strResult.Append("                <td> </td>");
                                }
                            }
                        }

                        strResult.Append("            </tr> ");
                    }
                }

            }
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <td colspan=2> Total </td>");

            DataView view = new DataView(dt);
            view.Sort = "Location Asc";
            DataTable distinctLocations = view.ToTable(true, "Location");

            int R, j;
            DataTable dl = null;
            for (int i = 0; i < Convert.ToInt32(iLocationCount.Count() * 1); i++)
            {
                dl = dt.Select("Location='" + distinctLocations.Rows[i]["Location"] + "'").CopyToDataTable();
                R = Convert.ToInt32(dl.Compute("SUM([Number of Resignation])", string.Empty));
                j = Convert.ToInt32(dl.Compute("SUM([Number of JA])", string.Empty));
                strResult.Append("                <td>" + R + "</td>");
                strResult.Append("                <td>" + j + "</td>");
            }
            strResult.Append("            </tr> ");
            //Include total


            strResult.Append("        </table> ");
            return strResult.ToString();
        }
        public static string GenerateExcelReportRetention(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();

            DataTable dt = _result;
            int columnCount = dt.Columns.Count;
            int Rowscount = dt.Rows.Count;
            var iLocationCount = from row in dt.AsEnumerable()
                                 group row by row.Field<string>("TMPOC") into Location
                                 orderby Location.Key
                                 select new
                                 {
                                     Name = Location.Key,
                                     CountOfVertical = Location.Count(),
                                 };

            var VerticalRow = from row in dt.AsEnumerable()
                              group row by row.Field<string>("Vertical") into vertical
                              orderby vertical.Key
                              select new
                              {
                                  Name = vertical.Key,
                                  CountOfVertical = vertical.Count()
                              };

            // #region start
            strResult.Append("<table cellspacing='0' rules='all' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < columnCount - 3; i++)
            {

                strResult.Append("                <th rowspan='2' bgcolor='#999'>" + dt.Columns[i].Caption.ToString() + "</th> ");
            }
            foreach (var item in iLocationCount)
            {
                strResult.Append("                <th colspan='2' bgcolor='#999'>" + item.Name + "</th> ");
            }
            strResult.Append("            </tr> ");

            //Appendig subheaders
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < iLocationCount.Count(); i++)
            {
                strResult.Append("                <th bgcolor='#999'>No. of ResignationWithdrawal</th>");
                strResult.Append("                <th bgcolor='#999'>No. of JA Revoked</th> ");

            }
            strResult.Append("            </tr> ");

            DataRow[] dr = null;
            DataRow[] drlocn = null;
            DataTable dta = null;
            //DataView viw = null;
            DataTable distinctAccounts = null;
            //Adding rows
            List<string> accounts = new List<string>();
            foreach (var item in VerticalRow)
            {
                
                dr = FilterRows(dt,"Vertical = '" + item.Name.ToString() + "'");

                dta = FilterRows(dt,"Vertical = '" + item.Name.ToString() + "'").CopyToDataTable();
                //viw = new DataView(dta);
                distinctAccounts = dta.DefaultView.ToTable(true, "Account Name");

                strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                strResult.Append("                <td rowspan=" + distinctAccounts.Rows.Count + ">" + item.Name + "</td>");

                for (int k = 0; k < dr.Count(); k++)
                {
                    if (!accounts.Contains(dr[k]["Account Name"].ToString()))
                    {
                        if (k > 0)
                        {
                            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                        }

                        strResult.Append("                <td>" + dr[k]["Account Name"].ToString() + "</td>");
                        accounts.Add(dr[k]["Account Name"].ToString());
                        drlocn = FilterRows(dt,"Vertical = '" + item.Name.ToString() + "' and [Account Name] = '" + dr[k]["Account Name"].ToString() + "'").OrderBy(u => u["TMPOC"]).ToArray();

                        // for (int i = 0; i < drlocn.Count(); i++) 
                        {
                            foreach (var items in iLocationCount)
                            {
                                var sdata = drlocn.Where(r => r.Field<string>("TMPOC").ToLower().Equals(items.Name.ToLower()));

                                if (sdata.Count() > 0)
                                {
                                    foreach (var slocn in sdata)
                                    {
                                        strResult.Append("                <td>" + slocn["No. of ResignationWithdrawal"].ToString() + "</td>");
                                        strResult.Append("                <td>" + slocn["No. of JA Revoked"].ToString() + "</td>");
                                    }
                                }
                                else
                                {
                                    strResult.Append("                <td> </td>");
                                    strResult.Append("                <td> </td>");
                                }
                            }
                        }

                        strResult.Append("            </tr> ");
                    }
                }

            }
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <td colspan=2> Total </td>");

            DataView view = new DataView(dt);
            view.Sort = "TMPOC Asc";
            DataTable distinctLocations = view.ToTable(true, "TMPOC");

            int R, j;
            DataTable dl = null;
            for (int i = 0; i < Convert.ToInt32(iLocationCount.Count() * 1); i++)
            {
                dl = FilterRows(dt,"TMPOC='" + distinctLocations.Rows[i]["TMPOC"] + "'").CopyToDataTable();
                R = Convert.ToInt32(dl.Compute("SUM([No. of ResignationWithdrawal])", string.Empty));
                j = Convert.ToInt32(dl.Compute("SUM([No. of JA Revoked])", string.Empty));
                strResult.Append("                <td>" + R + "</td>");
                strResult.Append("                <td>" + j + "</td>");
            }
            strResult.Append("            </tr> ");
            //Include total


            strResult.Append("        </table> ");
            return strResult.ToString();
        }
        public static string GenerateExcelReportTenure(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();
            _result.DefaultView.Sort = "Tenure asc";
            DataTable dt = _result;

            DataView view1 = new DataView(dt);
            view1.Sort = "Tenure Asc";
            DataTable distinctLocations1 = view1.ToTable(true, "Tenure");


            int columnCount = dt.Columns.Count;
            int Rowscount = dt.Rows.Count;
            var iLocationCount = from row in dt.AsEnumerable()
                                 group row by row.Field<string>("Tenure") into Location
                                 orderby Convert.ToInt32(Location.Key.Split('-')[0])
                                 select new
                                 {
                                     Name = Location.Key,
                                     CountOfVertical = Location.Count(),
                                 };

            var VerticalRow = from row in dt.AsEnumerable()
                              group row by row.Field<string>("Vertical") into vertical
                              orderby vertical.Key
                              select new
                              {
                                  Name = vertical.Key,
                                  CountOfVertical = vertical.Count()
                              };

            // #region start
            strResult.Append("<table cellspacing='0' rules='all' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < columnCount - 3; i++)
            {

                strResult.Append("                <th rowspan='2' bgcolor='#999'>" + dt.Columns[i].Caption.ToString() + "</th> ");
            }
            foreach (var item in iLocationCount)
            {
                strResult.Append("                <th colspan='2' bgcolor='#999'>" + item.Name + "</th> ");
            }
            strResult.Append("            </tr> ");

            //Appendig subheaders
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            for (int i = 0; i < iLocationCount.Count(); i++)
            {
                strResult.Append("                <th bgcolor='#999'>No of Resignation</th>");
                strResult.Append("                <th bgcolor='#999'>No of JA</th> ");

            }
            strResult.Append("            </tr> ");

            //...
            DataRow[] dr = null;
            DataRow[] drlocn = null;
            DataTable dta = null;
            //DataView viw = null;
            DataTable distinctAccounts = null;
            List<string> accounts = new List<string>();
            //Adding rows

            foreach (var item in VerticalRow)
            {
                
                dr = FilterRows( dt,"Vertical = '" + item.Name.ToString() + "'");
                
                dta = FilterRows(dt, "Vertical = '" + item.Name.ToString() + "'").CopyToDataTable();
                //viw = new DataView(dta);
                //distinctAccounts = dta["Account"]; //viw.ToTable(true, "AccountName");
                distinctAccounts = dta.DefaultView.ToTable(true, "AccountName");

                strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                strResult.Append("                <td rowspan=" + distinctAccounts.Rows.Count + ">" + item.Name + "</td>");

                for (int k = 0; k < dr.Count(); k++)
                {
                    if (!accounts.Contains(dr[k]["AccountName"].ToString()))
                    {
                        if (k > 0)
                        {
                            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                        }

                        strResult.Append("                <td>" + dr[k]["AccountName"].ToString() + "</td>");
                        accounts.Add(dr[k]["AccountName"].ToString());
                        drlocn = FilterRows(dt, "Vertical = '" + item.Name.ToString() + "' and [AccountName] = '" + dr[k]["AccountName"].ToString() + "'").OrderBy(u => u["Tenure"]).ToArray();

                        // for (int i = 0; i < drlocn.Count(); i++) 
                        {
                            foreach (var items in iLocationCount)
                            {
                                var sdata = drlocn.Where(r => r.Field<string>("Tenure").ToLower().Equals(items.Name.ToLower()));

                                if (sdata.Count() > 0)
                                {
                                    foreach (var slocn in sdata)
                                    {
                                        strResult.Append("                <td>" + slocn["Number of Resignation"].ToString() + "</td>");
                                        strResult.Append("                <td>" + slocn["Number of JA"].ToString() + "</td>");
                                    }
                                }
                                else
                                {
                                    strResult.Append("                <td> </td>");
                                    strResult.Append("                <td> </td>");
                                }
                            }
                        }

                        strResult.Append("            </tr> ");
                    }
                }
                accounts.Clear();
            }
            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <td colspan=2> Total </td>");


            DataTable distinctLocations = new DataTable();
            distinctLocations.Columns.Add("Tenure");
            DataRow drt;
            foreach (var item in iLocationCount)
            {
                drt = distinctLocations.NewRow();
                drt["Tenure"] = item.Name;
                distinctLocations.Rows.Add(drt);
            }
            DataTable dl = null;
            int R = 0;
            int j = 0;
            for (int i = 0; i < Convert.ToInt32(iLocationCount.Count() * 1); i++)
            {
                dl = FilterRows(dt, "Tenure='" + distinctLocations.Rows[i]["Tenure"] + "'").CopyToDataTable();
                R = Convert.ToInt32(dl.Compute("SUM([Number of Resignation])", string.Empty));
                j = Convert.ToInt32(dl.Compute("SUM([Number of JA])", string.Empty));
                strResult.Append("                <td>" + R + "</td>");
                strResult.Append("                <td>" + j + "</td>");
            }
            strResult.Append("            </tr> ");
            //Include total
            //...


            strResult.Append("        </table> ");
            return strResult.ToString();
        }
        public static string GenerateExcelReportEWS(string ReportName, DataTable _result)
        {
            StringBuilder strResult = new StringBuilder();

            DataTable dt = _result;
            int columnCount = dt.Columns.Count;
            int Rowscount = dt.Rows.Count;

            var iLocationCount = from row in dt.AsEnumerable()
                                 group row by row.Field<string>("Location") into Location
                                 orderby Location.Key
                                 select new
                                 {
                                     Name = Location.Key,
                                     CountOfVertical = Location.Count(),
                                 };

            var VerticalRow = from row in dt.AsEnumerable()
                              group row by row.Field<string>("Vertical") into vertical
                              orderby vertical.Key
                              select new
                              {
                                  Name = vertical.Key,
                                  CountOfVertical = vertical.Count()
                              };

            // #region start
            strResult.Append("<table cellspacing='0' rules='all' border='1' style='border-color: #C9D8EA; border-width: 1px; border-style: Solid; width: 50%; border-collapse: collapse;'");




            // Headings
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");

            strResult.Append("                <th rowspan='2' bgcolor='#999'>" + "Vertical" + "</th> ");
            strResult.Append("                <th rowspan='2' bgcolor='#999'>" + "Location" + "</th> ");
            strResult.Append("                <th rowspan='2' bgcolor='#999'>" + "Account Name" + "</th> ");
            strResult.Append("                <th colspan='3' bgcolor='#999'>" + "EWS Status" + "</th> ");
            strResult.Append("            </tr> ");
            strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <th  bgcolor='#999'>" + "Red" + "</th> ");
            strResult.Append("                <th  bgcolor='#999'>" + "Amber" + "</th> ");
            strResult.Append("                <th  bgcolor='#999'>" + "Green" + "</th> ");
            strResult.Append("            </tr> ");


            //--- Data

            DataRow[] dr = null;
            DataRow[] dracn = null;
            DataTable dtac = null;
            //DataView viw1 = null;
            DataTable distinctAccounts = null;
            DataRow drEWS = null;
            DataTable dta = null;
            //DataView viw = null;
            DataTable distinctlocations = null;
            List<string> location = new List<string>();
            //Adding rows

            foreach (var item in VerticalRow)
            {
                
                //dr = dt.Select("Vertical = '" + item.Name.ToString() + "'");
                dr = FilterRows(dt, "Vertical = '" + item.Name.ToString() + "'");
                //dta = dt.Select("Vertical = '" + item.Name.ToString() + "'").CopyToDataTable();
                dta =(FilterRows(dt,"Vertical = '" + item.Name.ToString() + "'")).CopyToDataTable();
                //viw = new DataView(dta);
                //distinctlocations = viw.ToTable(true, "Location");
                distinctlocations = dta.DefaultView.ToTable(true, "Location");
                strResult.Append("   <tr  align='Center' style=' font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                strResult.Append("                <td rowspan=" + dta.Rows.Count + ">" + item.Name + "</td>");

                int k = 0;
                foreach (DataRow drl in distinctlocations.Rows)
                {
                    dracn = FilterRows(dt, "Vertical = '" + item.Name.ToString() + "' and [Location] = '" + drl["Location"].ToString() + "'").OrderBy(u => u["Account Name"]).ToArray();
                    //dracn = dt.Select("Vertical = '" + item.Name.ToString() + "' and [Location] = '" + drl["Location"].ToString() + "'").OrderBy(u => u["Account Name"]).ToArray();

                    if (k > 0)
                    {
                        strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                    }

                    strResult.Append("                <td rowspan=" + dracn.Count() + ">" + drl["Location"].ToString() + "</td>");

                    dtac = dracn.CopyToDataTable();
                    //viw1 = new DataView(dtac);
                    distinctAccounts = dtac.DefaultView.ToTable(true, "Account Name");

                    int i = 0;
                    foreach (DataRow dra in distinctAccounts.Rows)
                    {
                        if (i > 0)
                        {
                            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
                        }

                        strResult.Append("                <td>" + dra["Account Name"].ToString() + "</td>");
                        drEWS = FilterRows(dt, "Vertical = '" + item.Name.ToString() + "' and [Location] = '" + drl["Location"].ToString() + "' and [Account Name] = '" + dra["Account Name"].ToString() + "'").OrderBy(u => u["Account Name"]).First();

                        strResult.Append("                <td>" + drEWS["Red"].ToString() + "</td>");
                        strResult.Append("                <td>" + drEWS["Amber"].ToString() + "</td>");
                        strResult.Append("                <td>" + drEWS["Green"].ToString() + "</td>");

                        i++;
                    }
                    strResult.Append("            </tr> ");
                    k++;
                }

                strResult.Append("            </tr> ");
            }



            strResult.Append("            <tr  align='Center' style='font-family: Helvetica; font-size: 12px;font-weight: bold; height: 20px;'> ");
            strResult.Append("                <td colspan=3> Total </td>");

            DataView view = new DataView(dt);
            view.Sort = "Location Asc";
            DataTable distinctLocations = view.ToTable(true, "Location");


            int r = Convert.ToInt32(dt.Compute("SUM([Red])", string.Empty));
            int a = Convert.ToInt32(dt.Compute("SUM([Amber])", string.Empty));
            int g = Convert.ToInt32(dt.Compute("SUM([Green])", string.Empty));

            strResult.Append("                <td>" + r + "</td>");
            strResult.Append("                <td>" + a + "</td>");
            strResult.Append("                <td>" + g + "</td>");

            strResult.Append("            </tr> ");
            //Include total
            strResult.Append("        </table> ");
            return strResult.ToString();
        }

        private static DataRow[] FilterRows(DataTable dt,string query)
        {
            return dt.Select(query);
        }
    }
}
