﻿using System;
using HRAssimilation.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace HRAssimilation.Data
{
    public class MasterSettingConfigDAL
    {
        string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
        Logger.Logger log = new Logger.Logger();
        public string DepartmentAddition(AccountDetails accountdet)
        {

            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_Insert_tbl_DepartmentMaster", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DepartmentName", accountdet.DepartmentName);
                    cmd.Parameters.AddWithValue("@DepartmentID", accountdet.DepartmentID);
                    cmd.Parameters.AddWithValue("@CreatedBy", accountdet.CreatedBy);
                    string result = null;
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string VerticalAddition(AccountDetails accountdet)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_Insert_tbl_VerticalMaster", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@VerticalName", accountdet.VerticalName);
                    cmd.Parameters.AddWithValue("@VerticalID", accountdet.VerticalID);
                    cmd.Parameters.AddWithValue("@CreatedBy", accountdet.CreatedBy);
                    string result = null;
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string Accountmapping(AccountDetails accountdet)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_InsertAccountDetails", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DepartmentID", accountdet.DepartmentID);
                    cmd.Parameters.AddWithValue("@VerticalID", accountdet.VerticalID);
                    cmd.Parameters.AddWithValue("@AccountID", accountdet.AccountID);
                    cmd.Parameters.AddWithValue("@AccountName", accountdet.AccountName);
                    cmd.Parameters.AddWithValue("@CreatedBy", accountdet.CreatedBy);
                    connection.Open();
                    string result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet BindDepartment()
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select D.DepartmentID, D.DepartmentName+ ' - '+ D.DepartmentId as DepartmentName from tbl_HR_DepartmentMaster D";
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet BindVertical()
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select V.VerticalID, V.verticalName + ' - ' +v.verticalID as VerticalName from tbl_HR_VerticalMaster V";
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet BindAccountDetails()
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_GetAccountDetails", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    connection.Close();
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataTable BindLocations()
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select ID,Location from tbl_HR_locationmaster";
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string InsertNewLocation(LocationDetails locdetails)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                string result = null;
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_InsertNewLocation", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Location", locdetails.Location);
                    cmd.Parameters.AddWithValue("@CreatedBy", locdetails.CreatedBy);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar()).ToString();
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string InsertNewFacilityMapping(LocationDetails locdetails)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                string result = null;
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_InsertNewFacilityMapping", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Facility", locdetails.Description);
                    cmd.Parameters.AddWithValue("@LocationID", locdetails.Location);
                    cmd.Parameters.AddWithValue("@Code", locdetails.LocationCode);
                    cmd.Parameters.AddWithValue("@CreatedBy", locdetails.CreatedBy);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar()).ToString();
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string InsertQuestion(Question objQuestion)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_InsertNewQuestion", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Description", objQuestion.QuestionDescription);
                    cmd.Parameters.AddWithValue("@Weightage", objQuestion.Weightage);
                    cmd.Parameters.AddWithValue("@CreatedBy", objQuestion.CreatedBy);
                    string result = null;
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public bool DeleteQuestion(Question objQuestion)
        {
            try
            {
                string command = "update tbl_HR_QuestionConfigDraft set IsActive = 'N',ModifiedBy='" + objQuestion.CreatedBy + "',ModifiedDate=GETDATE() where QuestionID = '" + objQuestion.QuestionID + "' ";
                DBHelper.ExecuteScalar(con, CommandType.Text, command);
                return true;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return false;
            }
        }

        public DataSet GetMasterQuestions()
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "SP_GetMasterQuestions";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;
                    connection.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    connection.Close();
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
            }
        }

        public string ManageQuestionConfig(DataTable dt, string CreatedBy)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                string result = null;
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_ManageQuestionWeightage", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@datatable", dt);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string UpdateAccountdetails(AccountDetails objAccount)
        {

            DatabaseConnection db = new DatabaseConnection();
            int rst = 0;
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] parms = { new SqlParameter("@AccountID", objAccount.AccountID),
                                            new SqlParameter("@AccountName", objAccount.AccountName),
                                           new SqlParameter("@DeptID", objAccount.DepartmentID),
                                           new SqlParameter("@VerticalID", objAccount.VerticalID),
                                           new SqlParameter("@SeqID", objAccount.ID),
                                           new SqlParameter("@PrevAccountID", objAccount.PrevAccountID),
                                           new SqlParameter("@createdBy", objAccount.CreatedBy)};
                    rst = DBHelper.ExecuteNonQuery(connection, CommandType.StoredProcedure, "SP_UpdateAccountdtls", parms);
                    if (rst > 0)
                    {
                        return "success;Updated Sucessfully";
                    }
                    else return "error;Not Updated";
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string UpdateFacilitydetails(FacilityDtls objFacility)
        {

            DatabaseConnection db = new DatabaseConnection();
            int rst = 0;
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] parms = { new SqlParameter("@FacilityCode", objFacility.FacilityCode),
                                            new SqlParameter("@FacilityName", objFacility.FacilityName),
                                           new SqlParameter("@SeqID", objFacility.FacilityID),
                                           new SqlParameter("@PrevFacilityCode", objFacility.PrevFacilityCode)};
                    rst = DBHelper.ExecuteNonQuery(connection, CommandType.StoredProcedure, "SP_UpdateFicilitydtls", parms);
                    if (rst > 0)
                    {
                        return "success;Updated Sucessfully";
                    }
                    else return "error;Not Updated";
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
    }
}
