﻿using HRAssimilation.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HRAssimilation.Data
{
    public class MyDataRowComparer : IEqualityComparer<DataRow>
    {
        public bool Equals(DataRow x, DataRow y)
        {
            for (int i = 0; i < x.Table.Columns.Count; i++)
            {
                if (x[i].ToString() != y[i].ToString())
                {
                    return false;
                }

            }
            return true;
        }

        public int GetHashCode(DataRow obj)
        {
            return obj.ToString().GetHashCode();
        }
    }
    public class ReportDAL
    {
        Logger.Logger log = new Logger.Logger();
        DatabaseConnection db = new DatabaseConnection();
        public DataSet BindReportlist()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    ds = DBHelper.ExecuteDataset(connection, CommandType.Text, "Select * from tbl_HR_GetReportNames where IsActive='Y' order by ReportName");
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        public DataSet BindLocationDtls()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    ds = DBHelper.ExecuteDataset(connection, CommandType.Text, "select Location from tbl_HR_LocationMaster");
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }

        public bool UsersUnderTMPOC(string TMPOC)
        {
            using (SqlConnection connection = db.CreateConnection())
            {
               // DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] parm = { new SqlParameter("@TMPOC", TMPOC) };
                    int count = Convert.ToInt16(DBHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "sp_CheckAssociateCount", parm));
                    //string command = "select count(Associateid) from tbl_HR_associateDetails where TMPOC = " + TMPOC;
                    //int count = Convert.ToInt16(DBHelper.ExecuteScalar(connection, CommandType.Text, command));
                    if (count > 0)
                        return true;
                    else
                        return false;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return false;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }

        public DataSet BindaFilterdata(string sroleid, string associateid)
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] parm = { new SqlParameter("@role", sroleid), new SqlParameter("@associateID", associateid) };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_BindFilterData", parm);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }
        public string Addsinlequtes(string sInput)
        {
            if (sInput.Length > 0)
            {
                return sInput = "'" + sInput + "'";
            }
            return sInput;
        }
        #region YTDreport
        public DataSet GenerateYTDReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {   
                             new SqlParameter("@FacilityCode", objData.Facility),                             
                             new SqlParameter("@AccountID", objData.Account),
                             new SqlParameter("@Reason", objData.Reason),
                             new SqlParameter("@year", objData.Year),
                             new SqlParameter("@vertical",objData.Vertical)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_Get_YTDAttritionReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }


        #endregion
        #region AttritionReport
        public DataSet GenerateAttritionReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),
                             new SqlParameter("@facility ", objData.Facility),                             
                             new SqlParameter("@account ", objData.Account),
                             new SqlParameter("@Reason", objData.Reason),
                             new SqlParameter("@vertical",objData.Vertical), 
                             new SqlParameter("@Designation", objData.Designation),
                             new SqlParameter("@Tenure", objData.Tenure),
                             new SqlParameter("@role", objData.Role),
                             new SqlParameter("@userID", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetAttritionReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }
        #endregion
        #region Attrition Count Report/Location wise attrition count report
        public DataSet GenerateAttritionCountReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                            new SqlParameter("@enddate", objData.ToDate),                             
                            new SqlParameter("@facility", objData.Facility),
                            new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetAttritionCountReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }
        public DataSet GenerateLocationWiseAttritionCountReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                            new SqlParameter("@enddate", objData.ToDate),                             
                            new SqlParameter("@facility", objData.Facility),
                            new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetLocaitonWiseAttritionCountReport ", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }
        #endregion
        #region VerticalwiseReport
        public DataSet GenerateVerticalwiseReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),
                             new SqlParameter("@department", objData.Department),
                             new SqlParameter("@vertical", objData.Vertical),
                              new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                            
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetVerticalwiseAttritionCountReport", param);

                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        #endregion
        #region TenurewisecountReport
        public DataSet GenerateTenurewiseReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),
                             new SqlParameter("@tenure", objData.Tenure),
                              new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetTenurewiseAttritionCountReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        #endregion
        #region RetentionOrEWSReport
        public DataSet GenerateRetentionReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),                             
                             new SqlParameter("@account", objData.Account),
                             new SqlParameter("@vertical",objData.Vertical), 
                              new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetRetentionDetails", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        public DataSet GetRetentionDetailsReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),                             
                             new SqlParameter("@account", objData.Account),
                             new SqlParameter("@vertical",objData.Vertical), 
                              new SqlParameter("@role", objData.Role),
                             new SqlParameter("@TMPOC", objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetRetentionDetailsReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        
        public DataSet GenerateEWSReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),                             
                             new SqlParameter("@account", objData.Account),
                             new SqlParameter("@role",objData.Role),
                             new SqlParameter("@vertical",objData.Vertical), 
                             new SqlParameter("@TMPOC",objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetEWSReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        #endregion

        #region ConnectsReport
        public DataSet GenerateConnectsReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        { 
                             new SqlParameter("@year", objData.Year),
                             new SqlParameter("@month", objData.Month),
                             new SqlParameter("@location", objData.Location),
                             new SqlParameter("@tmpoc", objData.TalentMAnager)                             
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetConnectsSummary", param);

                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        public DataSet GenerateEWSAccuracyReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        { 
                             new SqlParameter("@year", objData.Year),
                             new SqlParameter("@month", objData.Month),
                             new SqlParameter("@location", objData.Location),
                             new SqlParameter("@tmpoc", objData.TalentMAnager)                             
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetTMPOCAccuracyReport", param);

                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }        
        public DataSet GenerateAssociateDetailsReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    if (objData.IncludeNewJoiners)
                    {
                        SqlParameter[] param = 
                        { 
                             new SqlParameter("@year", objData.Year),
                             new SqlParameter("@month", objData.Month),
                             new SqlParameter("@location", objData.Location),
                             new SqlParameter("@tmpoc", objData.TalentMAnager),  
                             new SqlParameter("@includenewjoiners", objData.IncludeNewJoiners)
                        };
                        ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetALLAssociateDetailsUnderTMPOC", param);
                        return MergeAssociateDetails(ds);
                    }
                    else
                    {
                        SqlParameter[] param = 
                        { 
                             new SqlParameter("@year", objData.Year),
                             new SqlParameter("@month", objData.Month),
                             new SqlParameter("@location", objData.Location),
                             new SqlParameter("@tmpoc", objData.TalentMAnager)                             
                        };
                        ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetAssociateDetailsUnderTMPOC", param);
                    }
                    
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        private DataSet MergeAssociateDetails(DataSet ds)
        {
            try
            {
                DataSet dsFinal=new DataSet();
                DataTable dtTargets = ds.Tables[2];
                DataTable dtNewJoiners = ds.Tables[3];
                DataTable dtResult = null;// dtNewJoiners.AsEnumerable().Except(dtTargets.AsEnumerable(), DataRowComparer.Default).CopyToDataTable();
                var result = dtNewJoiners.AsEnumerable().Except(dtTargets.AsEnumerable(), DataRowComparer.Default);
                if (null != result && result.Count() > 0)
                {
                    dtResult = result.CopyToDataTable();


                    // DataTable checkDuplicates = dtResult.Copy();

                    for (int i = 0; i < dtResult.Rows.Count; )
                    {
                        string associateid = dtResult.Rows[i]["Associate ID"].ToString();
                        DataRow drd = dtResult.Rows[i];
                        DataRow[] rows = dtTargets.Select("[Associate ID]='" + associateid + "'");
                        if (rows.Length > 0)
                        {
                            dtResult.Rows.Remove(drd); dtResult.AcceptChanges();
                        }
                        else
                            i++;
                    }
                    //foreach (DataRow dr in checkDuplicates.Rows)
                    //{
                    //    string associateid = dr["Associate ID"].ToString();
                    //    DataRow[] rows = dtTargets.Select("[Associate ID]='" + associateid  + "'");
                    //    if (rows.Length > 0) { dtResult.Rows.Remove(dr); dtResult.AcceptChanges(); }
                    //}
                    foreach (DataRow dr in dtResult.Rows)
                    {
                        dr["Month"] = "New Hire";
                        dtResult.AcceptChanges();
                    }

                    dtTargets.Merge(dtResult);
                    dtTargets.AcceptChanges();
                }
                DataTable final = dtTargets.Copy();

                dsFinal.Tables.Add(final);
                
                return dsFinal;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }
        public DataSet GeneratePortalUsageReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {

                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@UserID", objData.TMPOC),
                             new SqlParameter("@RoleID", objData.Role), 
                             new SqlParameter("@FromDate", objData.FromDate),
                             new SqlParameter("@ToDate", objData.ToDate)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetportalusageReport", param);

                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        #endregion
        #region EngagementDetailsReport
        public DataSet GenerateEngagementActivityDetailsReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();
            try
            {
                using (SqlConnection connection = db.CreateConnection())
                {
                    SqlParameter[] param = { 
                                           new SqlParameter("@year",objData.Year),
                                           new SqlParameter("@month",objData.Month),
                                           new SqlParameter("@ConnectType",objData.ConnectType),
                                           new SqlParameter("@TMPOC",objData.TMPOC)
                                           };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetEngagementActivityDetailsReport", param);
                }
            }
            catch(Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
            }
            return ds;
        }
        #endregion
        #region StatuswisecountReport
        public DataSet GenerateStatuswiseReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),                             
                             new SqlParameter("@location", objData.Location),
                             new SqlParameter("@tmpoc", objData.TalentMAnager)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetStatusWiseReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        #endregion
        #region JAandResignationReport
        public DataSet GenerateJAandResignationReport(ReportsfilterDetails objData)
        {
            DataSet ds = new DataSet();

            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] param = 
                        {       
                            new SqlParameter("@startdate", objData.FromDate),
                             new SqlParameter("@enddate", objData.ToDate),                             
                             new SqlParameter("@actiontype", objData.ActionType),
                             new SqlParameter("@TMPOC",objData.TMPOC)
                        };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "GetJAandResignationDetailsReport", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        #endregion
    }
}
