﻿using System.Data.SqlClient;
using System.Configuration;


namespace HRAssimilation.Data
{
    public class DatabaseConnection
    {
        public SqlConnection CreateConnection()
        {
            string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
            return new SqlConnection(con);
        }
        public SqlConnection CreateArhiveDBConnection()
        {
            string con = ConfigurationManager.ConnectionStrings["ArchiveDBconnection"].ToString();
            return new SqlConnection(con);
        }        
    }
}
