﻿using System;
using System.Collections.Generic;
using HRAssimilation.Entity;
using System.Data;
using System.Data.SqlClient;

namespace HRAssimilation.Data
{
    public class UserConfigurationDAL
    {
        Logger.Logger log = new Logger.Logger();
        DatabaseConnection db = new DatabaseConnection();
        public string ManageUser(UserDetails UsrDetails, string flag)
        {

            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    string result = null;
                    SqlCommand cmd = new SqlCommand("sp_useraddition", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@associateID", UsrDetails.CognizantID);
                    cmd.Parameters.AddWithValue("@FirstName", UsrDetails.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", UsrDetails.LastName);
                    cmd.Parameters.AddWithValue("@EmailID", UsrDetails.EmailID);
                    cmd.Parameters.AddWithValue("@CreatedBy", UsrDetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@ModifiedBy", UsrDetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@IsActive", UsrDetails.IsActive);
                    cmd.Parameters.AddWithValue("@flag", @flag);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;

                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
        }


        public string RoleMapping(UserRoleDetails roledetails, string flag)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    string result = null;
                    SqlCommand cmd = new SqlCommand("SP_ManageUserRoleMapping", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Users_role", roledetails.Users_Role);
                    cmd.Parameters.AddWithValue("@Roles", roledetails.Roles);
                    cmd.Parameters.AddWithValue("@CreatedBy", roledetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@ModifiedBy", roledetails.ModifiedBy);
                    cmd.Parameters.AddWithValue("@flag", flag);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
        }


        public string POCLeadMapping(UserPOCLeadMappingDetails leadmappingdetails, string action)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_ManagePOC_LeadMapping", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@TMPOC", leadmappingdetails.TMPOCs);
                    cmd.Parameters.AddWithValue("@TMLead", leadmappingdetails.TMLead);
                    cmd.Parameters.AddWithValue("@CreatedBy", leadmappingdetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@ModifiedBy", leadmappingdetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@action", action);
                    connection.Open();
                    string result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
        }


        public string LocationMapping(UserLocationMappingDetails usrlocdetails, string action)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_ManageUserLocMapping", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Users", usrlocdetails.User_Location);
                    cmd.Parameters.AddWithValue("@LocationID", usrlocdetails.Location);
                    cmd.Parameters.AddWithValue("@CreatedBy", usrlocdetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@ModifiedBy", usrlocdetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@action", action);
                    connection.Open();
                    string result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
        }


        //public DataSet BindUserDetails()
        //{
        //    using (SqlConnection connection = db.CreateConnection())
        //    {
        //        DataSet ds = new DataSet();
        //        try
        //        {
        //            ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "BindUserDetails");
        //            return ds;
        //        }
        //        catch (Exception ex)
        //        {
        //            log.logError(ex.Message);
        //            return null;
        //        }
        //    }

        //}



        //public DataSet GetUnmappedUsers()
        //{           
        //    using (SqlConnection connection = db.CreateConnection())
        //    {
        //        DataSet ds = new DataSet();
        //        try
        //        {
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.CommandText = "GETUnmappedUsers";
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Connection = connection;
        //            connection.Open();
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(ds);
        //            connection.Close();
        //            return ds;
        //        }
        //        catch (Exception ex)
        //        {
        //            log.logError(ex.Message);
        //            return null;
        //        }
        //    }
        //}


        public DataSet bindlocations()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {

                    {
                        SqlCommand cmd = new SqlCommand("select ID,Location from tbl_HR_LocationMaster", connection);
                        cmd.CommandType = CommandType.Text;
                        //connection.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        //connection.Close();
                        return ds;
                    }
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }


        public DataSet BindRoles()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand("select * from tbl_HR_RoleMaster", connection);
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }


        public DataSet userrolesgridbind()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand("GetUserRoleMappingDetails", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }


        public DataSet GetUserRoles(string userid)
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "SP_GetUserRoles";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AssociateID", userid);
                    cmd.Connection = connection;
                    connection.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    connection.Close();
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }


        public DataSet POCLeadMappingGrdBind()
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_GetTMPOCLeadMappingDetails", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet POCGetQuestionConfig(string sUserid)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] param = { new SqlParameter("@AssociateID", sUserid) };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GetQuestionConfig", param);
                    //SqlCommand cmd = new SqlCommand("SP_GetQuestionConfig", connection);
                    //cmd.CommandType = CommandType.StoredProcedure;
                    //SqlDataAdapter da = new SqlDataAdapter(cmd);
                    //da.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string POCInsertEWSTrack(TmpocConnectTrackMaping oTracking)
        {
            DatabaseConnection db = new DatabaseConnection();
            string result = null;
            using (SqlConnection connection = db.CreateConnection())
            {
                //DataSet ds = new DataSet();
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_InsertTmpocEWSStatus", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AssociateID", oTracking.AssociateID);
                    cmd.Parameters.AddWithValue("@AssociateName", oTracking.AssociateName);
                    cmd.Parameters.AddWithValue("@TLEWS", oTracking.TLEWSStatus);
                    cmd.Parameters.AddWithValue("@EWSStatus", oTracking.EWSStatus);
                    cmd.Parameters.AddWithValue("@Submittedby", oTracking.SubmittedBy);
                    cmd.Parameters.AddWithValue("@IsSubmitted", oTracking.IsSubmitted);
                    cmd.Parameters.AddWithValue("@Comment", oTracking.TMPOCComment);
                    cmd.Parameters.AddWithValue("@ConnectDate", oTracking.ConnectDate);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }

        public string POCUpdateComments(TmpocConnectTrackMaping oTracking)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    string result;
                    SqlCommand cmd = new SqlCommand("UpdateComments_TMPOC", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AssociateID", oTracking.AssociateID);
                    cmd.Parameters.AddWithValue("@Submittedby", oTracking.SubmittedBy);
                    cmd.Parameters.AddWithValue("@Comments", oTracking.TMPOCComment);
                    connection.Open();
                    result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }
        public string POCInsertQuesTrack(List<TmpocEwsstatusindetail> objStatus, string sAssociateID)
        {
            DatabaseConnection db = new DatabaseConnection();
            string result = null;
            int rst = 0;
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    var param= new SqlParameter[7];
                    param[0] = new SqlParameter();
                    param[1] = new SqlParameter();
                    param[2] = new SqlParameter();
                    param[3] = new SqlParameter();
                    param[4] = new SqlParameter();
                    param[5] = new SqlParameter();
                    param[6] = new SqlParameter();

                    foreach (var item in objStatus)
                    {
                        param[0].ParameterName = "@Submittedby";
                        param[1].ParameterName = "@Description";
                        param[2].ParameterName = "@QuestionID";
                        param[3].ParameterName = "@Weightage";
                        param[4].ParameterName = "@Status";
                        param[5].ParameterName = "@Comment";
                        param[6].ParameterName = "@AssociateID";

                        param[0].SqlDbType = SqlDbType.NVarChar;
                        param[1].SqlDbType = SqlDbType.NVarChar;
                        param[2].SqlDbType = SqlDbType.NVarChar;
                        param[3].SqlDbType = SqlDbType.NVarChar;
                        param[4].SqlDbType = SqlDbType.NVarChar;
                        param[5].SqlDbType = SqlDbType.NVarChar;
                        param[6].SqlDbType = SqlDbType.NVarChar;

                        param[0].Value = item.SubmittedBy;
                        param[1].Value = item.Description;
                        param[2].Value = item.QuestionID;
                        param[3].Value = item.Weightage;
                        param[4].Value = item.Status;
                        param[5].Value = item.Comments;
                        param[6].Value = sAssociateID;
                        
                        rst = DBHelper.ExecuteNonQuery(connection, CommandType.StoredProcedure, "SP_InsertQuenEWSStatus", param);
                    }
                    if (rst > 0)
                    {
                        result = "success;Updated Successfully";
                    }
                    else
                    {
                        result = "error;Not Updated";
                    }
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet GetConnectTypedtls()
        {

            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    string sqlText = "select * from tbl_HR_ConnectTypes";
                    ds = DBHelper.ExecuteDataset(connection, CommandType.Text, sqlText);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string POCInsertConnectTypedtls(List<ConnectTypedtls> lstConnecttypedtls)
        {
            DatabaseConnection db = new DatabaseConnection();
            string result = null;
            int rst = 0;

            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {   
                    SqlParameter[] param=new SqlParameter[7];
                    param[0] = new SqlParameter();
                    param[1] = new SqlParameter();
                    param[2] = new SqlParameter();
                    param[3] = new SqlParameter();
                    param[4] = new SqlParameter();
                    param[5] = new SqlParameter();
                    param[6] = new SqlParameter();

                    foreach (var item in lstConnecttypedtls)
                    {
                        param[0].ParameterName = "@AssociateID";
                        param[1].ParameterName = "@AssociateName";
                        param[2].ParameterName = "@ConnectType";
                        param[3].ParameterName = "@SubmittedBy";
                        param[4].ParameterName = "@comments";
                        param[5].ParameterName = "@connectdate";
                        param[6].ParameterName = "@EWS";

                        param[0].SqlDbType = SqlDbType.NVarChar;
                        param[1].SqlDbType = SqlDbType.NVarChar;
                        param[2].SqlDbType = SqlDbType.NVarChar;
                        param[3].SqlDbType = SqlDbType.NVarChar;
                        param[4].SqlDbType = SqlDbType.NVarChar;
                        param[5].SqlDbType = SqlDbType.NVarChar;
                        param[6].SqlDbType = SqlDbType.NVarChar;

                        param[0].Value = item.AssociateID;
                        param[1].Value = item.AssociateName;
                        param[2].Value = item.SelConnectType;
                        param[3].Value = item.SubmittedBy;
                        param[4].Value = item.Comments;
                        param[5].Value = item.ConnectDate;
                        param[6].Value = item.EWS;
                       
                        rst = DBHelper.ExecuteNonQuery(connection, CommandType.StoredProcedure, "SP_InsertPOCConnectGroup", param);
                        if (rst > 0)
                        {
                            result = "sucess";
                        }
                    }
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataTable BindUserRoleGrid(string sloginid, string additionalFilter = "0")
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataTable dt = new DataTable();
                try
                {
                    //@LOGGEDINUSERID
                    SqlParameter[] parms = { new SqlParameter("@LOGGEDINUSERID", sloginid),
                                           new SqlParameter("@additionalFilter",additionalFilter)};
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "SP_GetMappedAssociatesDetails", parms);
                    //dt = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GetMappedAssociatesDetails", parms);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataTable BindOtherConnectUsers(string sloginid, string connecttype, string additionalFilter = "0")
        {
            using (SqlConnection connection = db.CreateConnection())
            {
                DataTable dt = new DataTable();
                try
                {
                    //@LOGGEDINUSERID
                    SqlParameter[] parms = { new SqlParameter("@LOGGEDINUSERID", sloginid),
                                           new SqlParameter("@ConnectType",connecttype),
                                           new SqlParameter("@additionalFilter",additionalFilter)};
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "SP_GetMappedAssociatesDetails_Group", parms);
                    //dt = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GetMappedAssociatesDetails", parms);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string TMPOCDetails(TMPOCDetails usrTMPOCDetails, string action)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    SqlCommand cmd = new SqlCommand("ManageTMPOCAccountMapping", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@AssociateID", usrTMPOCDetails.TMPOCs);
                   // cmd.Parameters.AddWithValue("@TMLead", usrTMPOCDetails.TMLead);
                    cmd.Parameters.AddWithValue("@LocationCode", usrTMPOCDetails.Location);
                    cmd.Parameters.AddWithValue("@AccountID", usrTMPOCDetails.AccountCode);
                    cmd.Parameters.AddWithValue("@AccountCode", usrTMPOCDetails.AccountId);
                    cmd.Parameters.AddWithValue("@FacilityCode", usrTMPOCDetails.FacilityCode);
                    cmd.Parameters.AddWithValue("@VerticalID", usrTMPOCDetails.VerticalID);
                    cmd.Parameters.AddWithValue("@projectID", usrTMPOCDetails.ProjectID);
                    cmd.Parameters.AddWithValue("@IsActive", "Y");
                    cmd.Parameters.AddWithValue("@CreatedBy", usrTMPOCDetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@ModifiedBy", usrTMPOCDetails.CreatedBy);
                    cmd.Parameters.AddWithValue("@Flag", action);
                    connection.Open();
                    string result = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
        }

    }
        
        
    
}
