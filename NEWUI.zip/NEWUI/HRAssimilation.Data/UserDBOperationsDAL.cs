﻿using System;
using System.Data;
using System.Data.SqlClient;
using HRAssimilation.Entity;


namespace HRAssimilation.Data
{
    public class UserDBOperationsDAL
    {
        Logger.Logger log = new Logger.Logger();
        public string checkifuserexists(string userID)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {                
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "SP_Authentication";
                    cmd.Parameters.AddWithValue("@ASSOCIATEID", userID);
                    cmd.Connection = connection;
                    connection.Open();
                    object o=cmd.ExecuteScalar();                    
                    connection.Close();
                    return o.ToString();
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message+ex.StackTrace);
                    return "Unauthorized."+ex.Message;
                }                
            }
        }       
        public DataTable GetUserDetails(string associateid)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "SP_GETSearchDetails";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AssociateID", associateid);
                    cmd.Connection = connection;
                    connection.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    connection.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
            }
        }

        public string userlocation(string userID)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                string location = null;
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select LocationID from tbl_HR_UserLocationMapping where AssociateID=@AssociateID";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@AssociateID", userID);
                    cmd.Connection = connection;
                    connection.Open();
                    location = Convert.ToString(cmd.ExecuteScalar());
                    connection.Close();
                    return location;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }
        public DataSet GetSelectedUserDetails(string associateid)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] param = { new SqlParameter("@AssociateID", associateid) };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GetMappedUserDetails", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet GetSearchedUserDetails(string associateid)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] param = { new SqlParameter("@AssociateID", associateid) };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GetAssociateDtlsForJA", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public DataSet GetJARevokeDetails(string associateid)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] param = { new SqlParameter("@AssociateID", associateid) };
                    ds = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "SP_GETSearchDetails", param);
                    return ds;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
            }
        }

        public string InsertOrUpdateResignationDtls(InsertorupdateinResignation objLst,string updatetype)
        {
            DatabaseConnection db = new DatabaseConnection();
            string result = null;
           

            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {   
                    SqlParameter[] param = 
                    {       
                        new SqlParameter("@AssociateID",objLst.AssociateID), 
                        new SqlParameter("@DetailedReasonforResignation",objLst.DetailedReasonforResignation),
                        new SqlParameter("@DiscussionwithManager",objLst.DiscussionwithManager),
                        new SqlParameter("@RetentionDiscussionwithAssociate",objLst.RetentionDiscussionwithAssociate),
                        new SqlParameter("@LastWorkingDate", objLst.LastWorkingDate),
                        new SqlParameter("@LastworkingDayUpdatedinSystem",objLst.LastworkingDayUpdatedinSystem),
                        new SqlParameter("@DetailedReasonforJA",objLst.DetailedReasonforJA),
                        new SqlParameter("@Jarevoked",objLst.Jarevoked),
                        new SqlParameter("@JARevokedDate",objLst.JARevokedDate),
                        new SqlParameter("@CreatedBy",objLst.CreatedBy),
                        new SqlParameter("@updatetype",updatetype)
                        
                    };
                    object o = DBHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "SP_InsertOrUpdateResignationdtl", param);
                 result = Convert.ToString(o);
                 return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return result;
                }
            }
        }

        public string TrackUser(TrackUsers tu)
        {
            DatabaseConnection db = new DatabaseConnection();
            string result = null;
            using (SqlConnection connection = db.CreateConnection())
            {
                DataSet ds = new DataSet();
                try
                {
                    SqlParameter[] param = 
                    {       
                        new SqlParameter("@UserID",tu.UserID), 
                        new SqlParameter("@SessionID",tu.SessionID),
                        new SqlParameter("@Action",tu.Action)                                              
                    };
                    object o = DBHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "LoginLogoutTime", param);
                    result = Convert.ToString(o);
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return result;
                }
            }
        }
    }
}
