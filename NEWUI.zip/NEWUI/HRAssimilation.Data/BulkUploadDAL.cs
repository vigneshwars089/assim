﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace HRAssimilation.Data
{
    public class BulkUploadDAL
    {
        DatabaseConnection db = new DatabaseConnection();
        //public DataTable upload(DataTable dt)
        //{
        //    DataTable dtreturn = new DataTable();
        //    DatabaseConnection db = new DatabaseConnection();
        //    using (SqlConnection con = db.CreateConnection())
        //        try
        //        {
        //            SqlCommand cmd = new SqlCommand("SP_InsertUpdateHeadCountReportDetails", con);                   
        //            //SqlCommand cmd = new SqlCommand("SP_InsertUpdateNewHireReportDetails", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@dt", dt);
        //            cmd.Parameters.AddWithValue("@createdby", "393391");                    
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(dtreturn);
        //            return dtreturn;        
        //        }
        //        catch (Exception e)
        //        {
        //            return null;
        //        }
        //}

        Logger.Logger log = new Logger.Logger();


        public DataSet BulkUpload(string storedprocedure, DataTable dt, string UserID)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    SqlParameter param = new SqlParameter();
                    param.Value = UserID;
                    param.SqlDbType = SqlDbType.VarChar;
                    param.ParameterName = "CREATEDBY";

                    SqlParameter paramDt = new SqlParameter();
                    paramDt.Value = dt;
                    paramDt.SqlDbType = SqlDbType.Structured;
                    paramDt.ParameterName = "DT";

                    SqlParameter[] commandparam = new SqlParameter[] { param, paramDt };

                    DataSet dtreturn = new DataSet();
                    dtreturn = DBHelper.ExecuteDataset(connection, CommandType.StoredProcedure, storedprocedure, commandparam);
                    //dtreturn = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, storedprocedure, commandparam);
                    return dtreturn;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }

        }

        public DataTable GetResignationJADetails()
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    DataTable dtreturn = new DataTable();
                    dtreturn = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "ResignationJADetails", null);
                    return dtreturn;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
        }
        public DataTable GetResignationJADetailsForMail(string ids)
        {
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    SqlParameter param = new SqlParameter();                    
                    param.SqlDbType = SqlDbType.VarChar;
                    param.ParameterName = "associateIDs";
                    param.Value = ids;
                    DataTable dtreturn = new DataTable();
                    dtreturn = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "ResignationJADetails_Mail", param);
                    return dtreturn;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
        }


    }

}
