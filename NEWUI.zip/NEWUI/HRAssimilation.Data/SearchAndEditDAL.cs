﻿using System;
using HRAssimilation.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HRAssimilation.Data
{
    /// <summary>
    /// SearchAndEditDAL will help in getting the user and user's location details
    /// </summary>
   public class SearchAndEditDAL
    {
       Logger.Logger log = new Logger.Logger();
       DatabaseConnection db = new DatabaseConnection();
       string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
       /// <summary>
       /// GetAssociateDetails is used to get the details of users
       /// </summary>
       /// <param name="associateid"></param>
       /// <returns></returns>
       public DataTable GetAssociateDetails(string associateid)
       {
           DatabaseConnection db = new DatabaseConnection();
           using (SqlConnection connection = db.CreateConnection())
           {
               DataTable dt = new DataTable();

               try
               {
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "SP_GetSearchDetails";
                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.Parameters.AddWithValue("@AssociateID", associateid);
                   cmd.Connection = connection;
                   connection.Open();
                   SqlDataAdapter da = new SqlDataAdapter(cmd);
                   da.Fill(dt);
                   connection.Close();
                   return dt;
               }
               catch (Exception ex)
               {
                   log.logError(ex.Message);
                   return null;
               }

           }

       }
       /// <summary>
       /// UpdateAssociateDetails is used to edit the user details
       /// </summary>
       /// <param name="SearchDetails"></param>
       /// <returns></returns>
        public string UpdateAssociateDetails(SearchAndEditAssociateDetails SearchDetails)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                string result = null;
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "SP_Update_Search";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AssociateID", SearchDetails.AssociateID);
                    cmd.Parameters.AddWithValue("@Location", SearchDetails.Location);
                    cmd.Parameters.AddWithValue("@SubLocation", SearchDetails.SubLocation);
                    cmd.Parameters.AddWithValue("@AccountID", SearchDetails.Account);
                    cmd.Parameters.AddWithValue("@AccountName", SearchDetails.AccountName);
                    cmd.Parameters.AddWithValue("@VerticalID", SearchDetails.Vertical);
                    cmd.Parameters.AddWithValue("@projectID", SearchDetails.ProjectID);
                    cmd.Parameters.AddWithValue("@Facility", SearchDetails.Facility);
                    cmd.Parameters.AddWithValue("@SupervisorID", SearchDetails.SupervisorID);
                    cmd.Parameters.AddWithValue("@SupervisorName", SearchDetails.SupervisorName);
                    cmd.Parameters.AddWithValue("@DepartmentID", SearchDetails.DepartmentID);                    
                    cmd.Parameters.AddWithValue("@ModifiedBy", SearchDetails.ModifiedBy);
                    cmd.Parameters.AddWithValue("@OverrideHCM", SearchDetails.OverrideHCM);
                    cmd.Connection = connection;
                    connection.Open();
                    result = Convert.ToString (cmd.ExecuteScalar());
                    connection.Close();
                    return result;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }

            }

        }
       /// <summary>
        /// GetSubLocationDetails is used to fetch sublocation details of user
       /// </summary>
       /// <param name="LocationID"></param>
       /// <returns></returns>
        public DataTable GetSubLocationDetails(string LocationID)
        {
            DatabaseConnection db = new DatabaseConnection();
            using (SqlConnection connection = db.CreateConnection())
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = new SqlCommand("select Code,FacilityName from tbl_HR_FacilityMaster where LocationID=" + LocationID, connection);
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
            }

        }

       

    }
}
