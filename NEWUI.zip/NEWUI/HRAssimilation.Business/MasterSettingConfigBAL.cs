﻿using System;
using HRAssimilation.Data;
using HRAssimilation.Entity;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace HRAssimilation.Business
{
    public class MasterSettingConfigBAL
    {
        MasterSettingConfigDAL mastersettingdal = new MasterSettingConfigDAL();
        string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
        Logger.Logger log = new Logger.Logger();
        public string DepartmentAddition(AccountDetails accountdet)
        {
            string result = null;
            result = mastersettingdal.DepartmentAddition(accountdet);
            return result;
        }

        public string VerticalAddition(AccountDetails accountdet)
        {
            string result = null;
            try
            {
                result = mastersettingdal.VerticalAddition(accountdet);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }

        public string AccountMapping(AccountDetails accountdet)
        {
            string result = null;
            result = mastersettingdal.Accountmapping(accountdet);
            return result;
        }

        public DataSet BindDepartment()
        {
            DataSet ds = new DataSet();
            try
            {
                ds = mastersettingdal.BindDepartment();
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet BindVertical()
        {
            DataSet ds = new DataSet();
            try
            {
                ds = mastersettingdal.BindVertical();
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet BindAccountDetails()
        {
            try
            {
                DataSet ds = mastersettingdal.BindAccountDetails();
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }
        public DataSet GetFacilityMapping()
        {
            try
            {
                DataSet ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetFacilityMappingDetails");
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }
        public DataSet GetProjectDetails()
        {
            try
            {
                DataSet ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetProjectDetails");
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }
        public string ManageProjectDetails(ProjectDetails prj)
        {
            try
            {
                SqlParameter[] param =  {new SqlParameter("@action",prj.Action),
                                        new SqlParameter("projectID",prj.ProjectID),
                                        new SqlParameter("@projectName ",prj.ProjectName),
                                        new SqlParameter("@verticalID",prj.VerticalID),
                                        new SqlParameter("@rowID",prj.RowID),
                                        new SqlParameter("@userID",prj.UserID)};
                //int i = DBHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "ManageProjectDetails",param);
                string result = Convert.ToString(DBHelper.ExecuteScalar(con, CommandType.StoredProcedure, "ManageProjectDetails", param));
                return result;
            }
            catch (Exception ex)
            {
                log.logError("Page : Master Setting --> Method : ManageProjectDetails");
                log.logError("Message : " + ex.Message + " Stack trace : " + ex.StackTrace);
                return "failure";
            }
        }

        public DataSet GetConnectDetails()
        {
            try
            {
                DataSet ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetConnectDetails");
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }
        public string ManageConnectDetails(ConnectDetails conn)
        {
            try
            {
                SqlParameter[] param =  {new SqlParameter("@action",conn.Action),
                                        new SqlParameter("@ConnectName",conn.ConnectName)};
                //int i = DBHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "ManageProjectDetails",param);
                string result = Convert.ToString(DBHelper.ExecuteScalar(con, CommandType.StoredProcedure, "ManageConnectDetails", param));
                return result;
            }
            catch (Exception ex)
            {
                log.logError("Page : Master Setting --> Method : ManageConnectDetails");
                log.logError("Message : " + ex.Message + " Stack trace : " + ex.StackTrace);
                return "failure";
            }
        }

        public DataTable BindLocations()
        {
            DataTable dt = mastersettingdal.BindLocations();
            return dt;
        }

        public string InsertNewLocation(LocationDetails locdetails)
        {
            try
            {
                string result = mastersettingdal.InsertNewLocation(locdetails);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string InsertNewFacilityMapping(LocationDetails locdetails)
        {
            string result;
            try
            {
                result = mastersettingdal.InsertNewFacilityMapping(locdetails);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string InsertQuestion(Question objQuestion)
        {
            try
            {
                return (mastersettingdal.InsertQuestion(objQuestion));
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet GetMasterQuestions()
        {
            DataSet ds = new DataSet();
            try
            {
                ds = mastersettingdal.GetMasterQuestions();
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string DeleteQuestion(Question objQuestion)
        {
            if (mastersettingdal.DeleteQuestion(objQuestion))
            {
                return "success;Question Deleted successfully";
            }
            else
            {
                return "error;update failed";
            }
        }

        public string ManageQuestionConfig(DataTable dt, string createdby)
        {
            string result = null;
            try
            {
                result = mastersettingdal.ManageQuestionConfig(dt, createdby);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string UpdateAccountdtls(AccountDetails objAccount)
        {
            string result = null;
            try
            {
                result = mastersettingdal.UpdateAccountdetails(objAccount);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        public string UpdateFacilitydtls(FacilityDtls objFacilitydtl)
        {
            string result = null;
            try
            {
                result = mastersettingdal.UpdateFacilitydetails(objFacilitydtl);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
    }
}
