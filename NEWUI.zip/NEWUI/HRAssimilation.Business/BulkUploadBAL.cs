﻿using System.Data;
using HRAssimilation.Data;

namespace HRAssimilation.Business
{
    public class BulkUploadBAL
    {
        BulkUploadDAL bu = new BulkUploadDAL();
        public DataTable NewHireReportUpload(DataTable dtexcel,string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("NewHireUploadSP", dtexcel, UserID);
            return dtreturn.Tables[0];
        }

        public DataTable HeadCountReport(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("HeadCountReportSP", dtexcel, UserID);
            return dtreturn.Tables[0];
        }

        public DataTable AttritionReport(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("AttritionReportsUploadSP", dtexcel, UserID);
            return dtreturn.Tables[0];
        }
        public DataTable ResignationSubmissionReport(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("ResignationSubmissionUpload", dtexcel, UserID);
            return dtreturn.Tables[0];
        }
        public DataTable JobAbandonment(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("JobAbandonmentDetailsUPload", dtexcel, UserID);
            return dtreturn.Tables[0];
        }
        public DataTable ResignationWithdrawal(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("ResignationWithdrawalDetailsUpload", dtexcel, UserID);
            return dtreturn.Tables[0];
        }
        public DataTable GetResignationJADetails()
        {
            return bu.GetResignationJADetails();
        }
        public DataTable GetResignationJADetailsForMail(string ids)
        {
            return bu.GetResignationJADetailsForMail(ids);
        }
        public DataSet GroupConnectUpload(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("GroupConnectUpload", dtexcel, UserID);
            return dtreturn;
        }
        public DataSet TMPOCMappingUpload(DataTable dtexcel, string UserID)
        {
            DataSet dtreturn = bu.BulkUpload("TMPOCMappingUpload", dtexcel, UserID);
            return dtreturn;
        }
        
    }
}
