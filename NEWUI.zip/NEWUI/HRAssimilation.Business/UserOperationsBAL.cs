﻿using System;
using HRAssimilation.Entity;
using HRAssimilation.Data;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace HRAssimilation.Business
{
    public class UserOperationsBAL
    {
        string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
        Logger.Logger log = new Logger.Logger();
        public AssociateDetails GetUserDetails(string associateID)
        {
            AssociateDetails objAssociateDetails = new AssociateDetails();
            try
            {
                DataTable dsUserdetails = new DataTable();
                UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
                dsUserdetails = objUserDAL.GetUserDetails(associateID);
                DataRow dr = dsUserdetails.Rows[0];

                //AssociateDetails
                objAssociateDetails.AssociateID = Convert.ToString(dr["AssociateID"]);
                objAssociateDetails.AssociateName = Convert.ToString(dr["AssociateName"]);
                objAssociateDetails.Designation = Convert.ToString(dr["Designation"].ToString());
                objAssociateDetails.Gender = dr["Gender"].ToString();
                string DOB = (dr["DateofBirth"] != null) ? (dr["DateofBirth"]).ToString() : "";
                if (!string.IsNullOrEmpty(DOB))
                {
                    DateTime objDOB = DateTime.Parse(DOB, System.Globalization.CultureInfo.InvariantCulture);
                    DOB = objDOB.ToString("MM/dd/yyyy");
                    objAssociateDetails.DateOfBirth = DOB;
                }
                objAssociateDetails.status = Convert.ToString(dr["status"]);
                objAssociateDetails.LocationID = Convert.ToString(dr["LocationID"]);
                objAssociateDetails.Location = Convert.ToString(dr["Location"]);
                objAssociateDetails.SubLocationCode = Convert.ToString(dr["LocationCode"]);
                objAssociateDetails.DepartmentID = Convert.ToString(dr["DepartmentID"]);
                objAssociateDetails.VerticalID = Convert.ToString(dr["VerticalID"].ToString());
                objAssociateDetails.AccountID = Convert.ToString(dr["AccountID"].ToString());
                objAssociateDetails.ProjectID = Convert.ToString(dr["ProjectID"]);
                objAssociateDetails.ProjectName = Convert.ToString(dr["Project"]);
                objAssociateDetails.SupervisorID = Convert.ToString(dr["SupervisorID"].ToString());
                objAssociateDetails.SupervisorName = Convert.ToString(dr["SupervisorName"].ToString());
                string hireDate = (dr["HireDate"] != null) ? (dr["HireDate"]).ToString() : "";
                if (!string.IsNullOrEmpty(hireDate))
                {
                    DateTime objSelecteddate = DateTime.Parse(hireDate, System.Globalization.CultureInfo.InvariantCulture);
                    hireDate = objSelecteddate.ToString("MM/dd/yyyy");
                    objAssociateDetails.HireDate = hireDate;
                }
                objAssociateDetails.Tenure = Convert.ToString(dr["Tenure"]);


                //Resignation Details

                string LastResignationDate = (!string.IsNullOrEmpty(Convert.ToString(dr["ResignationDateAAD"]))) ? dr["ResignationDateAAD"].ToString() : (!string.IsNullOrEmpty(Convert.ToString(dr["ResignationDateARD"]))) ? dr["ResignationDateARD"].ToString() : "";
                if (!string.IsNullOrEmpty(LastResignationDate))
                {
                    DateTime objLRD = DateTime.Parse(LastResignationDate, System.Globalization.CultureInfo.InvariantCulture);
                    LastResignationDate = objLRD.ToString("MM/dd/yyyy");
                    objAssociateDetails.LastResignationDate = LastResignationDate;
                }
                objAssociateDetails.LastResignationReason = (!string.IsNullOrEmpty(Convert.ToString( dr["ResignationReasonAAD"]))) ? dr["ResignationReasonAAD"].ToString() : (!string.IsNullOrEmpty(Convert.ToString(dr["ResignationReasonARD"]))) ? dr["ResignationReasonARD"].ToString() : "";


                string LastResignationWithdrawalDate =  (!string.IsNullOrEmpty(Convert.ToString(dr["LastResignationWithdrawalDate"]))) ? (dr["LastResignationWithdrawalDate"]).ToString() : "";
                if (!string.IsNullOrEmpty(LastResignationWithdrawalDate))
                {
                    DateTime objLRWD = DateTime.Parse(LastResignationWithdrawalDate, System.Globalization.CultureInfo.InvariantCulture);
                    LastResignationWithdrawalDate = objLRWD.ToString("MM/dd/yyyy");
                    objAssociateDetails.LastResignationWithdrawlDate = LastResignationWithdrawalDate;
                }    
                objAssociateDetails.LastResignationWithdrawlReason = (!string.IsNullOrEmpty(Convert.ToString(dr["ResignationWithdrawlReason"]))) ? dr["ResignationWithdrawlReason"].ToString() : "";


                //JA Details

                objAssociateDetails.LastJAReason = (!string.IsNullOrEmpty(Convert.ToString(dr["LastJAReason"]))) ? dr["LastJAReason"].ToString() : "";
                string LastJARaisedDate = (!string.IsNullOrEmpty(Convert.ToString(dr["LastJARaisedDate"]))) ? (dr["LastJARaisedDate"]).ToString() : "";
                if (!string.IsNullOrEmpty(LastJARaisedDate))
                {
                    DateTime objLReD = DateTime.Parse(LastJARaisedDate, System.Globalization.CultureInfo.InvariantCulture);
                    LastJARaisedDate = objLReD.ToString("MM/dd/yyyy");
                    objAssociateDetails.LastJARaisedDate = LastJARaisedDate;
                }
                objAssociateDetails.DetailedReasonforJA = (!string.IsNullOrEmpty(Convert.ToString(dr["DetailedReasonforJA"]))) ? dr["DetailedReasonforJA"].ToString() : "";
                objAssociateDetails.JARevoked = (!string.IsNullOrEmpty(Convert.ToString(dr["JARevoked"]))) ? dr["JARevoked"].ToString() : "";
                string JARevokedDate = (!string.IsNullOrEmpty(Convert.ToString(dr["JARevokedDate"]))) ? (dr["JARevokedDate"]).ToString() : "";                
                if (!string.IsNullOrEmpty(JARevokedDate))
                {
                    DateTime objJARD = DateTime.Parse(JARevokedDate, System.Globalization.CultureInfo.InvariantCulture);
                    JARevokedDate = objJARD.ToString("MM/dd/yyyy");
                    objAssociateDetails.JARevokedDate = JARevokedDate;
                }

                //Resignation Discussion Details

                objAssociateDetails.DetailedReasonforResignation = (!string.IsNullOrEmpty(Convert.ToString(dr["DetailedReasonforResignation"]))) ? dr["DetailedReasonforResignation"].ToString() : "";
                objAssociateDetails.DiscussionwithManager = (!string.IsNullOrEmpty(Convert.ToString(dr["DiscussionwithManager"])))  ? dr["DiscussionwithManager"].ToString() : "";

                objAssociateDetails.RetentionDiscussionwithAssociate = (!string.IsNullOrEmpty(Convert.ToString(dr["RetentionDiscussionwithAssociate"]))) ? dr["RetentionDiscussionwithAssociate"].ToString() : "";
                objAssociateDetails.LastWorkingDayUpdatedinSystem = (!string.IsNullOrEmpty(Convert.ToString(dr["LastWorkingDayUpdatedinSystem"])))  ? dr["LastWorkingDayUpdatedinSystem"].ToString() : "";

                string LastWorkingDate = (!string.IsNullOrEmpty(Convert.ToString(dr["LastWorkingDate"])))  ? (dr["LastWorkingDate"]).ToString() : "";
                if (!string.IsNullOrEmpty(LastWorkingDate))
                {
                    DateTime objLWD = DateTime.Parse(LastWorkingDate, System.Globalization.CultureInfo.InvariantCulture);
                    LastWorkingDate = objLWD.ToString("MM/dd/yyyy");
                    objAssociateDetails.LastWorkingDate = LastWorkingDate;
                }
                objAssociateDetails.OverrideHCM = Convert.ToString(dr["OverrideHCM"]) == "1" ? dr["OverrideHCM"].ToString() : "";
                
                //TMPOC SHOULD BE EXCLUDED
                objAssociateDetails.TMPOC = Convert.ToString(dr["TMPOC"]);
                return objAssociateDetails;

            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }

        }

        public AssociateDetails GetSelUserDetails(string associateID)
        {
            AssociateDetails objAssociateDetails = new AssociateDetails();
            try
            {
                DataSet dsUserdetails = new DataSet();
                UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
                dsUserdetails = objUserDAL.GetSelectedUserDetails(associateID);
                DataRow dr = dsUserdetails.Tables[0].Rows[0];

                objAssociateDetails.AssociateID = dr["AssociateID"].ToString();
                objAssociateDetails.AssociateName = dr["AssociateName"].ToString();
                objAssociateDetails.Designation = dr["JobCodeDescription"].ToString();
                objAssociateDetails.Gender = dr["Gender"].ToString();
                objAssociateDetails.Location = dr["Location"].ToString();
                objAssociateDetails.SubLocation = dr["Facility"].ToString();
                objAssociateDetails.AccountName = dr["AccountName"].ToString();
                objAssociateDetails.VerticalName = dr["VerticalName"].ToString();
                objAssociateDetails.SupervisorID = dr["SupervisorID"].ToString();
                objAssociateDetails.SupervisorName = dr["SupervisorName"].ToString();
                objAssociateDetails.Tenure = dr["Tenure"].ToString();

                string hireDate = (dr["HireDate"] != null) ? (dr["HireDate"]).ToString() : "";
                if (!string.IsNullOrEmpty(hireDate))
                {
                    DateTime objSelecteddate = DateTime.Parse(hireDate, System.Globalization.CultureInfo.InvariantCulture);
                    hireDate = objSelecteddate.ToString("MM/dd/yyyy");
                    objAssociateDetails.HireDate = hireDate;
                }

                string DOB = (dr["DateofBirth"] != null) ? (dr["DateofBirth"]).ToString() : "";

                if (!string.IsNullOrEmpty(DOB))
                {
                    DateTime objDOB = DateTime.Parse(DOB, System.Globalization.CultureInfo.InvariantCulture);
                    DOB = objDOB.ToString("MM/dd/yyyy");
                    objAssociateDetails.DateOfBirth = DOB;
                }              

                objAssociateDetails.status = dr["Status"].ToString();

                return objAssociateDetails;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return objAssociateDetails;
            }

        }

        public DataSet GetDashboardDetails(string userid, string roleid)
        {
            DataSet ds = new DataSet();
            try
            {
                //parameter creation
                SqlParameter paramKeyValue = new SqlParameter();
                paramKeyValue.SqlDbType = SqlDbType.VarChar;
                paramKeyValue.ParameterName = "@AssociateID";
                paramKeyValue.Value = userid;

                SqlParameter paramKeyValue1 = new SqlParameter();
                paramKeyValue1.SqlDbType = SqlDbType.VarChar;
                paramKeyValue1.ParameterName = "@RoleID";
                paramKeyValue1.Value = roleid;

                SqlParameter[] commandParameters = new SqlParameter[] { paramKeyValue, paramKeyValue1 };


                return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetDashboardDetails", commandParameters);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet GetDashboardChartsData()
        {
            DataSet ds = new DataSet();
            try
            {               
                SqlParameter[] commandParameters = new SqlParameter[] { };
                return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetChartData", commandParameters);                
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }       

        public AssociateDetails GetSearchUserDetails(string associateID)
        {
            AssociateDetails objSrchAssociatedtl = new AssociateDetails();
            DataSet dsUserdetails = new DataSet();
            UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
            dsUserdetails = objUserDAL.GetSearchedUserDetails(associateID);            
            DataRow dr = null;
            DataRow drEwsStatus = null;
            DataRow drLastmetdate = null;
            if (dsUserdetails.Tables.Count == 3)
            {
                dr = dsUserdetails.Tables[0].Rows[0];
                if(dsUserdetails.Tables[1]!=null&&dsUserdetails.Tables[1].Rows.Count>0)
                    drEwsStatus = dsUserdetails.Tables[1].Rows[0];
                    if(dsUserdetails.Tables[2]!=null&&dsUserdetails.Tables[2].Rows.Count>0)                        
                drLastmetdate = dsUserdetails.Tables[2].Rows[0];


                if (dr != null)
                {
                    objSrchAssociatedtl.AssociateID = dr["AssociateID"].ToString();
                    objSrchAssociatedtl.AssociateName = dr["AssociateName"].ToString();
                    objSrchAssociatedtl.JobCodeDescription = dr["JobCodeDescription"].ToString();
                    objSrchAssociatedtl.Gender = dr["Gender"].ToString();
                    //Date of joining
                    string sJoiningDate = dr["HireDate"].ToString();
                    if (!(String.IsNullOrEmpty(sJoiningDate)))
                    {
                        DateTime objJoinDate = DateTime.Parse(sJoiningDate, System.Globalization.CultureInfo.InvariantCulture);
                        sJoiningDate = objJoinDate.ToString("MM/dd/yyyy");
                    }
                    objSrchAssociatedtl.HireDate = sJoiningDate;

                    //ResignationDate
                    string sResignationDate = dr["ResignationDate"].ToString();
                    if (!(String.IsNullOrEmpty(sResignationDate)))
                    {
                        DateTime objResignDate = DateTime.Parse(sResignationDate, System.Globalization.CultureInfo.InvariantCulture);
                        sResignationDate = objResignDate.ToString("MM/dd/yyyy");
                    }
                    objSrchAssociatedtl.LastResignationDate = sResignationDate;

                    //LastReportdate
                    string sReportDate = dr["LastReportedDate"].ToString();
                    if (!(String.IsNullOrEmpty(sReportDate)))
                    {
                        DateTime objReportDate = DateTime.Parse(sReportDate, System.Globalization.CultureInfo.InvariantCulture);
                        sReportDate = objReportDate.ToString("MM/dd/yyyy");
                    }
                    objSrchAssociatedtl.LastJARaisedDate = sReportDate;

                    objSrchAssociatedtl.TerminataionStatus = dr["TerminationStatus"].ToString();
                    objSrchAssociatedtl.LastResignationWithdrawlReason = dr["ResignationWithdrawlReason"].ToString();
                    objSrchAssociatedtl.ResignationWithdrawalStatus = dr["ResignationWithdrawalStatus"].ToString();
                    //Effective date
                    string sEffectivetDate = dr["ResignationWithdrawalDate"].ToString();
                    if (!(String.IsNullOrEmpty(sEffectivetDate)))
                    {
                        DateTime objRecentDate = DateTime.Parse(sEffectivetDate, System.Globalization.CultureInfo.InvariantCulture);
                        sEffectivetDate = objRecentDate.ToString("MM/dd/yyyy");
                    }
                    objSrchAssociatedtl.LastResignationWithdrawlDate = sEffectivetDate;

                    objSrchAssociatedtl.Location = dr["Location"].ToString();
                    objSrchAssociatedtl.SupervisorID = dr["SupervisorID"].ToString();
                    objSrchAssociatedtl.SupervisorName = dr["SupervisorName"].ToString();
                    objSrchAssociatedtl.VerticalName = dr["VerticalName"].ToString();
                    objSrchAssociatedtl.AccountName = dr["AccountName"].ToString();                    
                    if (!string.IsNullOrEmpty(objSrchAssociatedtl.LastResignationDate))
                    {
                        objSrchAssociatedtl.ResignataionReport = "Yes";
                    }
                    else
                    {
                        objSrchAssociatedtl.ResignataionReport = "No";
                    }
                    objSrchAssociatedtl.TMPOC = dr["TMPOC"].ToString();
                    objSrchAssociatedtl.Tenure = dr["Tenure"].ToString();
                }

                if (drEwsStatus != null)
                {
                    objSrchAssociatedtl.EWSStatus = drEwsStatus["EWsStatus"].ToString();
                }
                if (drLastmetdate != null)
                {
                    string sRecentDate = drLastmetdate["RecentDate"].ToString();
                    if (!(string.IsNullOrEmpty(sRecentDate)))
                    {
                        DateTime objRecentDate = DateTime.Parse(sRecentDate, System.Globalization.CultureInfo.InvariantCulture);
                        sRecentDate = objRecentDate.ToString("MM/dd/yyyy");
                    }
                    objSrchAssociatedtl.LastMetDate = sRecentDate;
                }
            }
            else
            {
                DataRow drmsg = null;
                drmsg = dsUserdetails.Tables[0].Rows[0];
                objSrchAssociatedtl.Message = drmsg["Message"].ToString();
            }
            return objSrchAssociatedtl;
        }

        public AssociateDetails GetJAdttails(string AssociateID)
        {
            AssociateDetails objUsrdtl = new AssociateDetails();
            DataSet ds = new DataSet();
            UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
            ds = objUserDAL.GetJARevokeDetails(AssociateID);
            DataRow dr = ds.Tables[0].Rows[0];
            objUsrdtl.DetailedReasonforResignation = dr["DetailedReasonforResignation"].ToString();
            objUsrdtl.DiscussionwithManager = dr["DiscussionwithManager"].ToString();
            objUsrdtl.RetentionDiscussionwithAssociate = dr["RetentionDiscussionwithAssociate"].ToString();
            objUsrdtl.JARevoked = dr["JARevoked"].ToString();

            string sLastWorkingDate = dr["LastWorkingDate"].ToString();
            if (!(String.IsNullOrEmpty(sLastWorkingDate)))
            {
                DateTime objLastWorkingDate = DateTime.Parse(sLastWorkingDate, System.Globalization.CultureInfo.InvariantCulture);
                sLastWorkingDate = objLastWorkingDate.ToString("MM/dd/yyyy");
                objUsrdtl.LastWorkingDate = sLastWorkingDate;
            }
            objUsrdtl.LastWorkingDayUpdatedinSystem = dr["LastWorkingDayUpdatedinSystem"].ToString();
            objUsrdtl.DetailedReasonforJA = dr["DetailedReasonforJA"].ToString();
            string sJARevokedDate = dr["JARevokedDate"].ToString();
            if (sJARevokedDate.Contains("1900")) sJARevokedDate = "";
            if (!(String.IsNullOrEmpty(sJARevokedDate)))
            {
                DateTime objJARevokedDate = DateTime.Parse(sJARevokedDate, System.Globalization.CultureInfo.InvariantCulture);
                sJARevokedDate = objJARevokedDate.ToString("MM/dd/yyyy");
                objUsrdtl.JARevokedDate = sJARevokedDate;
            }
            return objUsrdtl;
        }

        public string InsertOrUpdateResignationDtls(InsertorupdateinResignation objrec,string updatetype)
        {
            UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
            string rslt = objUserDAL.InsertOrUpdateResignationDtls(objrec,updatetype);
            return rslt;
        }

        public DataSet CheckIfUserExists(string userid, string doj)
        {
            try
            {
                SqlParameter param1 = new SqlParameter();
                param1.ParameterName = "associateID";
                param1.SqlDbType = SqlDbType.VarChar;
                param1.Value = userid;

                SqlParameter param2 = new SqlParameter();
                param2.ParameterName = "DOJ";
                param2.SqlDbType = SqlDbType.VarChar;
                param2.Value = doj;

                SqlParameter[] parameters = new SqlParameter[] { param1, param2 };

                DataSet result = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GETSearchDetailsWithDOJ", parameters);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }
        public void TrackUser(TrackUsers tu)
        {
            try
            {
                UserDBOperationsDAL objUserDAL = new UserDBOperationsDAL();
                string result=objUserDAL.TrackUser(tu);
                log.logInfo(result);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
        }
    }
}
