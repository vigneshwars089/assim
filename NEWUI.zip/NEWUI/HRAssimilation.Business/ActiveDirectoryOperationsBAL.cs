﻿using System;
using HRAssimilation.Entity;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;



namespace HRAssimilation.Business
{
    public class ActiveDirectoryOperationsBAL
    {
        Logger.Logger log = new Logger.Logger();
        public bool isADAuthenticated(UserDetails UsrDetails)
        {
            // create a "principal context" - e.g. your domain (could be machine, too)
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain))
            {
                // validate the credentials
                try
                {
                    bool isValid = pc.ValidateCredentials(UsrDetails.UserID, UsrDetails.Password);
                    return isValid;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return false;
                }
            }
        }

        public UserDetails getuserdetails(string CTSID)
        {
            UserDetails user = new UserDetails();
            if (string.IsNullOrEmpty(CTSID))
            {                
                user.Error_msg = "error; Please enter CognizantID";
                return user;
            }
            else
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain,"cts"))
                {
                    try
                    {
                        UserPrincipal up = UserPrincipal.FindByIdentity(pc, CTSID);
                        if (up != null)
                        {
                            DirectoryEntry entry = up.GetUnderlyingObject() as DirectoryEntry;
                            user.FirstName = entry.Properties["givenName"].Value.ToString();
                            user.LastName = entry.Properties["sn"].Value.ToString();
                            user.EmailID = entry.Properties["mail"].Value.ToString();
                            return user;
                        }
                        else
                        {
                            user.Error_msg = "User details do not exist in Cognizant Directory. Please enter valid CognizantID.";
                            return user;
                        }
                    }
                    catch (Exception ex)
                    {
                        log.logError(ex.Message);
                        return null;
                    }
                }
            }
        }
    }
}