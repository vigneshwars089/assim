﻿using System;
using System.Collections.Generic;
using HRAssimilation.Entity;
using HRAssimilation.Data;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace HRAssimilation.Business
{
    public class UserConfigurationBAL
    {
        UserConfigurationDAL usrconfigDAL = new UserConfigurationDAL();
        ActiveDirectoryOperationsBAL AD = new ActiveDirectoryOperationsBAL();
        UserDetails UD = new UserDetails();
        DatabaseConnection db = new DatabaseConnection();
        string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
        Logger.Logger log = new Logger.Logger();

        public string Manageuser(UserDetails usrdetails, string flag)
        {
            if (flag != "edit")
            {
                UD = AD.getuserdetails(usrdetails.CognizantID);
                if (string.IsNullOrEmpty(usrdetails.FirstName) || string.IsNullOrEmpty(usrdetails.LastName) ||
                    string.IsNullOrEmpty(usrdetails.EmailID))
                {
                    usrdetails.Error_msg = "Please search the user details before adding";
                    return usrdetails.Error_msg;
                }
                else
                    if (usrdetails.FirstName != UD.FirstName)
                    {
                        usrdetails.Error_msg = "Please search the user details before adding";
                        return usrdetails.Error_msg;
                    }
                    else
                    {
                        string message = usrconfigDAL.ManageUser(usrdetails, flag);
                        return message;
                    }
            }
            else
            {
                string message = usrconfigDAL.ManageUser(usrdetails, flag);
                return message;
            }
        }

        public string RoleMapping(UserRoleDetails roledetails, string flag)
        {
            try
            {
                string message = null;
                if (string.IsNullOrEmpty(roledetails.Roles) || string.IsNullOrEmpty(roledetails.Users_Role))
                {
                    message = "error;Please select both Users and Roles for Mapping";
                    return message;
                }
               
                    else
                        if (roledetails.Users_Role.Contains(roledetails.CreatedBy))
                        {
                            message = "error;Self role mapping cannot be done.";
                            return message;
                        }
                        else
                        {
                            message = usrconfigDAL.RoleMapping(roledetails, flag);
                            return message;
                        }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return "error:";
            }
        }

        public string POCLeadMapping(UserPOCLeadMappingDetails usrPOCLeadmappingdetails, string action)
        {
            try
            {
                string message = null;
                if (string.IsNullOrEmpty(usrPOCLeadmappingdetails.TMPOCs))
                {
                    message = "error;Please select TM POC for mapping";
                    return message;
                }
                else
                    if (usrPOCLeadmappingdetails.TMPOCs.Contains(usrPOCLeadmappingdetails.TMLead))
                    {
                        message = "error;TM POC and Lead cannot be the same person";
                        return message;
                    }
                    else
                    {
                        message = usrconfigDAL.POCLeadMapping(usrPOCLeadmappingdetails, action);
                        return message;
                    }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }


        public string TMPOCDetailsUpdate(TMPOCDetails usrTMPOCDetails, string action)
        {
            try
            {
                string message = null;
                if (string.IsNullOrEmpty(usrTMPOCDetails.TMPOCs))
                {
                    message = "error;Please select TM POC for mapping";
                    return message;
                }
                else 
                    {
                        message = usrconfigDAL.TMPOCDetails(usrTMPOCDetails, action);
                        return message;
                    }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string LocationMapping(UserLocationMappingDetails usrlocdetails, string action)
        {
            string message = null;
            if (string.IsNullOrEmpty(usrlocdetails.User_Location) || string.IsNullOrEmpty(usrlocdetails.Location))
            {
                message = "error;Please select Users and Location for Location Mapping";                
            }            
                else
                {
                    message = usrconfigDAL.LocationMapping(usrlocdetails, action);                
                }
            return message;
        }       

        public DataTable BindUserDetails()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "BindUserDetails", (SqlParameter[])null);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
        }

        public DataSet GetUnmappedUsers(string loggedinuserid)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@loggedinuserID";
                param.SqlDbType = SqlDbType.VarChar;
                param.Value = loggedinuserid;
                SqlParameter[] commandParameters = new SqlParameter[] { param };
                ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetUnmappedUsers", commandParameters);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }

        public DataSet GetTMPOC(string loggedinuserid,string facilityCode)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@loggedinuserID";
                param.SqlDbType = SqlDbType.VarChar;
                param.Value = loggedinuserid;
                SqlParameter param1 = new SqlParameter();
                param1.ParameterName = "@facilityCode";
                param1.SqlDbType = SqlDbType.VarChar;
                param1.Value = facilityCode;
                SqlParameter[] commandParameters = new SqlParameter[] { param,param1 };
                ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetTMPOCSDetails", commandParameters);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }

        public DataTable BindAcccountsunderTMPOC(string TMPOC)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    SqlParameter[] param = { new SqlParameter("@TMPOC", TMPOC) };
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "GetTMPOCMappedAccounts", param);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message + ex.StackTrace);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
            }
        }


        public DataSet bindlocations()
        {
            DataSet ds = new DataSet();
            ds = usrconfigDAL.bindlocations();
            return ds;
        }

        public DataSet userrolesgridbind()
        {
            DataSet ds = new DataSet();
            ds = usrconfigDAL.userrolesgridbind();
            return ds;
        }

        public DataSet GetUserRoles(string userid)
        {
            DataSet dsRoles = new DataSet();
            try
            {
                dsRoles = usrconfigDAL.GetUserRoles(userid);
                return dsRoles;
            }
            catch (Exception ex)
            {
                return dsRoles;
            }
        }

        public DataTable BindRoles()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = db.CreateConnection())
                try
                {
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.Text, "select * from tbl_HR_RoleMaster", (SqlParameter[])null);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
        }

        public DataSet POCLeadMappingGrdBind()
        {
            DataSet ds = new DataSet();
            try
            {
                ds = usrconfigDAL.POCLeadMappingGrdBind();
                return ds;
            }
            catch (Exception ex)
            {
                return ds;
            }
        }

        public string Checkuserstatus(string userID)
        {
            try
            {
                string command = "select IsActive from tbl_HR_userloginmaster where AssociateID = '" + userID + "'";
                string message = Convert.ToString(DBHelper.ExecuteScalar(con, CommandType.Text, command));
                return message;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataTable GetDistinctUserStatus(string query)
        {
            try
            {
                SqlConnection connection = new SqlConnection(con);
                DataTable dt = new DataTable();
                dt = DBHelper.ExecuteDataTable(connection, CommandType.Text, query, (SqlParameter[])null);
                return dt;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet GetPagesACL()
        {
            try
            {
                DataSet dsACL = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetAccessiblePages");
                return dsACL;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }

        }

        public DataSet POCGetQuestionconfig(string sUserid)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = usrconfigDAL.POCGetQuestionConfig(sUserid);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return ds;
            }
        }

        public string POCInsertEWSStatusTrack(TmpocConnectTrackMaping oTracking)
        {
            string result = "";
            try
            {
                result = usrconfigDAL.POCInsertEWSTrack(oTracking);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return result;
            }
        }

        public string POCUpdateComments(TmpocConnectTrackMaping oTracking)
        {
            string result = "";
            try
            {
                result = usrconfigDAL.POCUpdateComments(oTracking);
                return result;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return result;
            }
        }

        public string POCInsertQuestionStatus(List<TmpocEwsstatusindetail> oTracking, string sAssociateID)
        {
            string result = "";
            try
            {
                result = usrconfigDAL.POCInsertQuesTrack(oTracking, sAssociateID);
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

        public DataSet POCGetConnectTypedtls()
        {
            DataSet ds = new DataSet();
            try
            {
                ds = usrconfigDAL.GetConnectTypedtls();
                return ds;
            }
            catch (Exception ex)
            {
                return ds;
            }
        }

        public string InsertConnectTypedtls(List<ConnectTypedtls> lstConnecttypedtls)
        {
            string sresult = "";
            try
            {
                sresult = usrconfigDAL.POCInsertConnectTypedtls(lstConnecttypedtls);
                return sresult;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return sresult;
            }

        }

        public DataSet GetPOCconnectdtls(string Associateid, string spNmae)
        {
            try
            {
                DataSet ds = new DataSet();
                SqlParameter[] param = { new SqlParameter("@AssociateID", Associateid) };
                ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, spNmae, param);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }

        public DataTable BindUserRoleGrid(string sloginid,string additionalFilter = "0")
        {
            DataTable dt = new DataTable();
            dt = usrconfigDAL.BindUserRoleGrid(sloginid,additionalFilter);
            return dt;
        }

        public DataTable BindOtherConnectUsers(string sloginid, string connecttype, string additionalFilter = "0")
        {
            DataTable dt = new DataTable();
            dt = usrconfigDAL.BindOtherConnectUsers(sloginid, connecttype,additionalFilter);
            return dt;
        }
        public DataSet GetTMPOCDetails()
        {
            try
            {
                return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetTMPOCS");
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataSet GetTMPOCLocations(string tmpocuserid)
        {
            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@AssociateID";
                param.Value = tmpocuserid;
                return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetTMPOCLocations", param);
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public string ManageTMPOCLocationMapping(TMPOCAccount tmpocAccount,string flag)
        {
            SqlParameter AssociateID = new SqlParameter();
            AssociateID.SqlDbType = SqlDbType.VarChar;
            AssociateID.ParameterName = "AssociateID";
            AssociateID.Value = tmpocAccount.AssociateID;

            SqlParameter LocationCode = new SqlParameter();
            LocationCode.SqlDbType = SqlDbType.VarChar;
            LocationCode.ParameterName = "LocationCode";
            LocationCode.Value = tmpocAccount.LocationCode;

            SqlParameter AccountID = new SqlParameter();
            AccountID.SqlDbType = SqlDbType.VarChar;
            AccountID.ParameterName = "AccountID";
            AccountID.Value = tmpocAccount.AccountID;

            SqlParameter CreatedBy = new SqlParameter();
            CreatedBy.SqlDbType = SqlDbType.VarChar;
            CreatedBy.ParameterName = "CreatedBy";
            CreatedBy.Value = tmpocAccount.CreatedBy;

            SqlParameter VerticalID = new SqlParameter();
            VerticalID.SqlDbType = SqlDbType.VarChar;
            VerticalID.ParameterName = "VerticalID";
            VerticalID.Value = tmpocAccount.VerticalID;

            SqlParameter ProjectID = new SqlParameter();
            ProjectID.SqlDbType = SqlDbType.VarChar;
            ProjectID.ParameterName = "ProjectID";
            ProjectID.Value = tmpocAccount.ProjectID;

            SqlParameter IsActive = new SqlParameter();
            IsActive.SqlDbType = SqlDbType.VarChar;
            IsActive.ParameterName = "IsActive";
            IsActive.Value = tmpocAccount.IsActive;

            SqlParameter ModifiedBy = new SqlParameter();
            ModifiedBy.SqlDbType = SqlDbType.VarChar;
            ModifiedBy.ParameterName = "ModifiedBy";
            ModifiedBy.Value = tmpocAccount.ModifiedBy;

            SqlParameter flagpoc = new SqlParameter();
            flagpoc.SqlDbType = SqlDbType.VarChar;
            flagpoc.ParameterName = "flag";
            flagpoc.Value = flag;


            SqlParameter[] parameters = new SqlParameter[] { AssociateID, LocationCode, VerticalID, AccountID, ProjectID, CreatedBy, IsActive, ModifiedBy,flagpoc };
            Object result = DBHelper.ExecuteScalar(con, CommandType.StoredProcedure, "ManageTMPOCAccountMapping", parameters);
            return result.ToString();


        }

        public DataSet GetTMPPOCMappingDetails()
        {
            try
            {
                return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetTMPOCAccountMappingDetails");
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
        }

        public DataTable SearchUnmappedUsers(string associateid, string searchtype)
        {
            using (SqlConnection connection = db.CreateConnection())
            try
            {   
                SqlParameter AssociateID = new SqlParameter();
                AssociateID.SqlDbType = SqlDbType.VarChar;
                AssociateID.ParameterName = "id";
                AssociateID.Value = associateid;

                SqlParameter SearchType = new SqlParameter();
                SearchType.SqlDbType = SqlDbType.VarChar;
                SearchType.ParameterName = "searchtype";
                SearchType.Value = searchtype;

                SqlParameter[] parameters = new SqlParameter[] { AssociateID, SearchType };

                return DBHelper.ExecuteDataTable(connection,CommandType.StoredProcedure,"SearchUnmappedUsers",parameters);  
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
                return null;
            }
            finally
                {
                    if (connection.State != ConnectionState.Closed)
                        connection.Close();
                }
        }

        public DataTable BindUserLocationMappingDetails()
        { 
            DataTable dt = new DataTable();
            using (SqlConnection connection = db.CreateConnection())
            {
                try
                {
                    dt = DBHelper.ExecuteDataTable(connection, CommandType.StoredProcedure, "GetUserLocationMappingDetails", (SqlParameter[])null);
                    return dt;
                }
                catch (Exception ex)
                {
                    log.logError(ex.Message);
                    return null;
                }
                finally
                {
                    if (connection.State != ConnectionState.Closed)
                    { connection.Close(); }
                }
            }
        }
    }
}
