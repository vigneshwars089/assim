﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace HRAssimilation.Business
{
    public class GridOperationsBAL
    {
        public DataTable FilterGridRecords(DataTable actualDt,string columnName,string value,string searchType)
        {
            DataTable resultDt = new DataTable();
            try
            {
                var values = value.Split(',');                
                switch (searchType)
                {
                    case "INT":
                        string query = "[" + columnName + "]" + " in (" +formatInput(value) + ")";
                        resultDt = actualDt.Select(query).CopyToDataTable();
                        break;
                    case "STRING":
                        resultDt = actualDt.AsEnumerable().Where(x => x.Field<string>(columnName).ToLower().Contains(value.ToLower().Trim())).CopyToDataTable();
                        break;
                    default: break;
                }
                return resultDt;
            }
            catch (InvalidExpressionException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        protected string formatInput(string value)
        {
            string[] inputArray = value.Split(',');
            StringBuilder sb = new StringBuilder();
            foreach (string a in inputArray)
            {
                sb.Append("'");
                sb.Append(a);
                sb.Append("'");
                sb.Append(',');
            }
            return sb.ToString();
        }
    }
}
