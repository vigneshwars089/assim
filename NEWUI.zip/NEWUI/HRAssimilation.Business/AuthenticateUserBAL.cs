﻿using HRAssimilation.Data;



namespace HRAssimilation.Business
{
    public class AuthenticateUserBAL 
    {
        UserDBOperationsDAL usrDBOperations = new UserDBOperationsDAL();
        public string AuthenticateUserID(string usrID)
        { 
           
            string message = usrDBOperations.checkifuserexists(usrID);
            return message;
        }

        public string userlocation(string userID)
        {
            string location = usrDBOperations.userlocation(userID);
            return location;
        }
        
    }
}
