﻿using System;
using System.Data;
using System.Data.SqlClient;
using HRAssimilation.Data;
using HRAssimilation.Entity;
using System.Configuration;

namespace HRAssimilation.Business
{
    /// <summary>
    /// SearchAndEditBAL will help in getting the user and user's location details.
    /// </summary>
    public class SearchAndEditBAL
    {
        DatabaseConnection db = new DatabaseConnection();
        SearchAndEditDAL SearchDAL = new SearchAndEditDAL();
        MasterSettingConfigDAL mastersettingdal = new MasterSettingConfigDAL();
        Logger.Logger log = new Logger.Logger();
        string con = ConfigurationManager.ConnectionStrings["connection"].ToString();
        /// <summary>
        /// GetAssociateDetails is used to get the details of users.
        /// </summary>
        /// <param name="associateid"></param>
        /// <returns></returns>
        public DataTable GetAssociateDetails(string associateid)
        {
            DataTable dt = new DataTable();
            dt = SearchDAL.GetAssociateDetails(associateid);
            return dt;
        }
        /// <summary>
        /// UpdateAssociateDetails is used to edit the user details
        /// </summary>
        /// <param name="SearchDetails"></param>
        /// <returns></returns>
        public string UpdateAssociateDetails(SearchAndEditAssociateDetails SearchDetails)
        {

            string result = SearchDAL.UpdateAssociateDetails(SearchDetails);
            return result;
        }
        /// <summary>
        /// BindLocations is used to get location details
        /// </summary>
        /// <returns></returns>
        public DataTable BindLocations()
        {
            DataTable dt = mastersettingdal.BindLocations();
            return dt;
        }
        /// <summary>
        /// GetSubLocationDetails is used to get sub Location details of the users
        /// </summary>
        /// <param name="LocationID"></param>
        /// <returns></returns>
        public DataTable GetSubLocationDetails(string LocationID)
        {
            DataTable dt = SearchDAL.GetSubLocationDetails(LocationID);
            return dt;
        }
        /// <summary>
        /// ValidateloggedinuserLocation is used to validate the user trying login.
        /// </summary>
        /// <param name="loggedinuserid"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public bool ValidateloggedinuserLocation(string loggedinuserid, string userid)
        {
            string command = "select AssociateID from tbl_HR_UserLocationMapping WHERE AssociateID = '"+loggedinuserid+"' AND LocationID in (select LM.ID from tbl_HR_Associatelocationdetails ALD join tbl_HR_LocationMaster LM ON ALD.Location = LM.Location WHERE ALD.AssociateID = '"+userid+"') AND IsActive = 'Y'";
            string ID = Convert.ToString(DBHelper.ExecuteScalar(con, CommandType.Text, command)) ;
            if (ID == loggedinuserid)
                return true;
            else 
                return false;
        }
        /// <summary>
        /// GetUsersDetails is used to get user details
        /// </summary>
        /// <param name="hiredate"></param>
        /// <returns></returns>
        public DataSet GetUsersDetails(string hiredate,int role, string loggedinUserID)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlParameter HireDate_P = new SqlParameter();
                HireDate_P.ParameterName = "@HireDate";
                HireDate_P.SqlDbType = SqlDbType.VarChar;
                HireDate_P.Value = hiredate;
                SqlParameter Role_P = new SqlParameter();
                Role_P.ParameterName = "@role";
                Role_P.SqlDbType = SqlDbType.Int;
                Role_P.Value = role;
                SqlParameter UserID_P = new SqlParameter();
                UserID_P.ParameterName = "@loggedinuserID";
                UserID_P.SqlDbType = SqlDbType.VarChar;
                UserID_P.Value = loggedinUserID;
                SqlParameter[] commandParameters = new SqlParameter[] { HireDate_P, Role_P, UserID_P };
                ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUsersDetails", commandParameters);
                return ds;
            }
            catch (Exception ex)
            {
                log.logError(ex.Message + ex.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// BindAccount is used to get the account details.
        /// </summary>
        /// <param name="DeptID"></param>
        /// <param name="VerticalID"></param>
        /// <returns></returns>
        public DataSet BindAccount(string DeptID, string VerticalID)
        {
            DataSet ds = new DataSet();
            try
            {
                using (SqlConnection con = db.CreateConnection())
                {
                    try
                    {
                        SqlParameter[] param = new SqlParameter[]{
                        new SqlParameter("@departmentID",DeptID),
                        new SqlParameter("@verticalID",VerticalID)
                        };

                        ds = DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "GetAccountandProjectDetails", param);
                        //string command = "select AccountID,AccountName +' - '+AccountID [AccountName] from [tbl_HR_AccountMaster] where DepartmentID='" + DeptID + "' and VerticalID='" + VerticalID + "'";
                        //DataSet ds = HRAssimilation.Data.DBHelper.ExecuteDataTable(con, CommandType.Text, command, (SqlParameter[])null);
                        //return dt;
                    }
                    catch (Exception ex)
                    {
                        log.logError(ex.Message);
                        //return ds;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                log.logError(ex.Message);
            }
            return ds;       

        }
        /// <summary>
        /// GetEWSData is used to get EWS details
        /// </summary>
        /// <param name="AssociateID"></param>
        /// <returns></returns>
        public DataSet GetEWSData(string AssociateID)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "AssociateId";
            param.Value = AssociateID;
            return DBHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetConnectDetails", param);
        }

    }
}




