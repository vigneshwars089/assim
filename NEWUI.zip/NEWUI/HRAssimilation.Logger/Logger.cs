﻿using log4net;
namespace HRAssimilation.Logger
{
    public class Logger
    {
        ILog logger = log4net.LogManager.GetLogger(typeof(Logger));
        public void logDebug(string message)
        {
            logger.Debug(message);
        }
        public void logInfo(string message)
        {
            logger.Info(message);
        }
        public void logError(string message)
        {
            logger.Error(message);
        }
    }
}
